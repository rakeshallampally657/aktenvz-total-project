/*akteId=1*/
insert into AKTE(  stadt_bezirk,kenn_ziffer,akten_beginn,letzte_heftnummer,
                   neue_heftnummer,almosen_kasten,betreff,in_papier_korb,sonstige_anmerkungen,ist_ausgeliehen)
values (1,11,'2020-01-07',0,1, true,'first akten',false,'Detailed info of 1st akten',false );

/*For akteId=1 the aenderung table is inserted with 'angelegt'*/
insert into aenderung(aktion,datum,akte_fk,nutzer_fk)
VALUES ('angelegt', CURRENT_TIMESTAMP(),(select akte_id from AkTE WHERE akte_id=1),
        (select nutzer_id from nutzer where nutzer_id=1));

insert into akte_versionierung(  stadt_bezirk,kenn_ziffer,akten_beginn,letzte_heftnummer,
                   neue_heftnummer,almosen_kasten,betreff,in_papier_korb,sonstige_anmerkungen,ist_ausgeliehen,aenderung_fk)
values (1,11,'2020-01-07',0,1, true,'first akten',false,'Detailed info of 1st akten',false ,
        (select aenderung_id from aenderung where aenderung_id=1));

/* Updating akteId=1*/
update AKTE set stadt_bezirk=100,kenn_ziffer=110 where akte_id=1;

/* the aenderung table is inserted with 'aktualisiert' as akte table is updated */
insert into aenderung(aktion,datum,akte_fk,nutzer_fk)
VALUES ('aktualisiert', CURRENT_TIMESTAMP(),(select akte_id from AkTE WHERE akte_id=1),
        (select nutzer_id from nutzer where nutzer_id=1));

insert into akte_versionierung(  stadt_bezirk,kenn_ziffer,akten_beginn,letzte_heftnummer,
                                 neue_heftnummer,almosen_kasten,betreff,in_papier_korb,sonstige_anmerkungen,ist_ausgeliehen,aenderung_fk)
values (100,110,'2020-01-07',0,1, true,'first akten',false,'Detailed info of 1st akten',false ,
        (select aenderung_id from aenderung where aenderung_id=2));

