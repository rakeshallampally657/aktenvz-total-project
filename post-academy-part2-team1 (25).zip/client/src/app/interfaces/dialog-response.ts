export interface DialogResponse {
    res: boolean;
    action: string;
}
