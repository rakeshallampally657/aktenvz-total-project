//package com.softwareone.postacademy.unit;
//
//import com.fasterxml.jackson.databind.ObjectMapper;
//import com.softwareone.postacademy.controller.MeldungController;
//import com.softwareone.postacademy.dto.*;
//import com.softwareone.postacademy.exceptions.SaveToDatabaseException;
//import com.softwareone.postacademy.model.Meldung;
//import com.softwareone.postacademy.service.MeldungService;
//import org.hamcrest.Matchers;
//import org.junit.Test;
//import org.junit.runner.RunWith;
//import org.mockito.Mockito;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
//import org.springframework.boot.test.mock.mockito.MockBean;
//import org.springframework.http.MediaType;
//import org.springframework.test.context.junit4.SpringRunner;
//import org.springframework.test.web.servlet.MockMvc;
//import org.springframework.test.web.servlet.request.MockHttpServletRequestBuilder;
//import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
//
//import javax.persistence.EntityNotFoundException;
//import java.time.LocalDateTime;
//import java.util.ArrayList;
//import java.util.Date;
//import java.util.List;
//
//import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
//import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;
//
//@RunWith(SpringRunner.class)
//@WebMvcTest(value = MeldungController.class)
//public class MeldungControllerUnitTest {
//
//    @MockBean
//    private MeldungService meldungService;
//
//
//    @Autowired
//    private MockMvc mockMvc;
//    @Autowired
//    private ObjectMapper jsonSerializer;
//
//    private static final String baseURL = "/api";
//
//    //Meldung erstellen
//    @Test
//    public void createANewMeldungForAkteSuccessful() throws Exception {
//        MeldungErstellenDTO meldungErstellenDTO = new MeldungErstellenDTO(0L, "Meldung erstellt", "bereich1");
//        MeldungDTO meldungDTO = new MeldungDTO();
//        meldungDTO.setAkteId(1L);
//        meldungDTO.setBereich("bereich1");
//        meldungDTO.setZustand(1);
//        meldungDTO.setNachricht("Meldung erstellt");
//        MockHttpServletRequestBuilder postRequest = MockMvcRequestBuilders.post(baseURL+"/akte/1/melden")
//                .contentType(MediaType.APPLICATION_JSON)
//                .content(jsonSerializer.writeValueAsString(meldungErstellenDTO));
//        Mockito.when(meldungService.meldungErstellen(meldungErstellenDTO, 1L))
//                .thenReturn(meldungDTO);
//        mockMvc.perform(postRequest).andExpect(status().isCreated())
//                .andExpect(jsonPath("$.data").value(meldungDTO))
//                .andExpect(jsonPath("$.message").value("Akte notification created"));
//    }
//
//    @Test
//    public void createANewMeldungForAkteFail() throws Exception {
//        MeldungErstellenDTO meldungErstellenDTO = new MeldungErstellenDTO(0L, "Meldung erstellt", "bereich1");
//        Mockito.when(meldungService.meldungErstellen(meldungErstellenDTO, 1L))
//                .thenThrow(new SaveToDatabaseException("AKTE NOTIFICATION CREATION FAILED ::: 1"));
//        MockHttpServletRequestBuilder postRequest = MockMvcRequestBuilders.post(baseURL+"/akte/1/melden")
//                .contentType(MediaType.APPLICATION_JSON)
//                .content(jsonSerializer.writeValueAsString(meldungErstellenDTO));
//        mockMvc.perform(postRequest).andExpect(status().is5xxServerError())
//                .andExpect(jsonPath("$.message").value("AKTE NOTIFICATION CREATION FAILED ::: 1"))
//                .andExpect(jsonPath("$.data").doesNotExist());
//    }
//
//    //Meldung oeffnen
//    @Test
//    public void openAnExistingMeldungSuccessful() throws Exception {
//        MeldungOeffnenResponse meldungOeffnenResponse = new MeldungOeffnenResponse();
//        meldungOeffnenResponse.setGemeldetVon("Bearbeiter");
//        Mockito.when(meldungService.meldungOeffnen(1L)).thenReturn(meldungOeffnenResponse);
//        MockHttpServletRequestBuilder patchRequest = MockMvcRequestBuilders.patch(baseURL+"/akte/meldungen/1/oeffnen")
//                .contentType(MediaType.APPLICATION_JSON)
//                .content(jsonSerializer.writeValueAsString());
//        mockMvc.perform(patchRequest).andExpect(status().isOk())
//                .andExpect(jsonPath("$.data").value(meldungOeffnenResponse))
//                .andExpect(jsonPath("$.message").value("The Meldung is opened"));
//    }
//
//    @Test
//    public void openAnExistingMeldungFail() throws Exception {
//
//        Mockito.when(meldungService.meldungOeffnen( 1L))
//                .thenThrow(new EntityNotFoundException("MELDUNG ID NOT FOUND ::: 1"));
//        MockHttpServletRequestBuilder patchRequest = MockMvcRequestBuilders.patch(baseURL+"/akte/meldungen/1/oeffnen")
//                .contentType(MediaType.APPLICATION_JSON)
//                .content(jsonSerializer.writeValueAsString());
//        mockMvc.perform(patchRequest).andExpect(status().is4xxClientError())
//                .andExpect(jsonPath("$.data").doesNotExist())
//                .andExpect(jsonPath("$.message").value("MELDUNG ID NOT FOUND ::: 1"));
//    }
//
//    //Meldung abbrechen
//    @Test
//    public void cancelCreatingAMeldungSuccessful() throws Exception {
//        Mockito.when(meldungService.meldungAbbrechen(1L))
//                .thenReturn("Meldung abbrechen successful");
//        MockHttpServletRequestBuilder patchRequest = MockMvcRequestBuilders.patch(baseURL+"/akte/meldungen/1/schliessen");
//        mockMvc.perform(patchRequest).andExpect(status().isOk())
//                .andExpect(jsonPath("$.message").value("Meldung abbrechen successful"))
//                .andExpect(jsonPath("$.data").doesNotExist());
//    }
//
//    @Test
//    public void cancelCreatingAMeldungFail() throws Exception {
//        Mockito.when(meldungService.meldungAbbrechen(1L))
//                .thenThrow(new SaveToDatabaseException("Meldung abbrechen failed"));
//        MockHttpServletRequestBuilder patchRequest = MockMvcRequestBuilders.patch(baseURL+"/akte/meldungen/1/schliessen");
//        mockMvc.perform(patchRequest).andExpect(status().is5xxServerError())
//                .andExpect(jsonPath("$.data").doesNotExist())
//                .andExpect(jsonPath("$.message").value("Meldung abbrechen failed"));
//    }
//
//    //Meldung schliessen
//    @Test
//    public void closeAMeldungSuccessful() throws Exception {
//        MeldungAbschliessenDTO meldungAbschliessenDTO = new MeldungAbschliessenDTO("ilya");
//        Mockito.when(meldungService.meldungAbschliessen(meldungAbschliessenDTO, 1L))
//                .thenReturn("Meldung erfolgreich abgeschlossen");
//        MockHttpServletRequestBuilder patchRequest = MockMvcRequestBuilders.patch(baseURL+"/akte/meldungen/1/abschliessen")
//                .contentType(MediaType.APPLICATION_JSON)
//                .content(jsonSerializer.writeValueAsString(meldungAbschliessenDTO));
//        mockMvc.perform(patchRequest).andExpect(status().isOk())
//                .andExpect(jsonPath("$.message").value("Meldung erfolgreich abgeschlossen"))
//                .andExpect(jsonPath("$.data").doesNotExist());
//    }
//
//    @Test
//    public void closeAMeldungFail() throws Exception {
//        MeldungAbschliessenDTO meldungAbschliessenDTO = new MeldungAbschliessenDTO("ilya");
//        Mockito.when(meldungService.meldungAbschliessen(meldungAbschliessenDTO, 1L))
//                .thenThrow(new SaveToDatabaseException("Meldung abschliessen failed"));
//        MockHttpServletRequestBuilder patchRequest = MockMvcRequestBuilders.patch(baseURL+"/akte/meldungen/1/abschliessen")
//                .contentType(MediaType.APPLICATION_JSON)
//                .content(jsonSerializer.writeValueAsString(meldungAbschliessenDTO));
//        mockMvc.perform(patchRequest).andExpect(status().is5xxServerError())
//                .andExpect(jsonPath("$.data").doesNotExist())
//                .andExpect(jsonPath("$.message").value("Meldung abschliessen failed"));
//    }
//
//    //TODO: get all Meldungen for all Akten
//    @Test
//    public void getAllMeldungenForAllAktenSuccessful() throws Exception {
//        MeldungDTO meldungDTO = new MeldungDTO();
//        meldungDTO.setMeldungId(2L);
//        meldungDTO.setZustand(1);
//        List<MeldungDTO> meldungDTOList = new ArrayList<>();
//        meldungDTOList.add(meldungDTO);
//        Mockito.when(meldungService.getMeldungenOfAllAkten()).thenReturn(meldungDTOList);
//        MockHttpServletRequestBuilder getRequest = MockMvcRequestBuilders.get(baseURL+"/akte/meldungen");
//        mockMvc.perform(getRequest).andExpect(status().isOk())
//                .andExpect(jsonPath("$.message").value("The list of all meldungen of all akten"))
//                .andExpect(jsonPath("$.data", Matchers.hasSize(1)))
//                .andExpect(jsonPath("$.data[0]").value(meldungDTO));
//    }
//    //TODO: get all Meldungen for one Akte
//
//    //TODO: get all open Meldungen
//
//    //TODO: get open Meldungen for one Akte
//}
