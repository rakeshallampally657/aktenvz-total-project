/*akteId=1*/
insert into AKTE(  stadt_bezirk,kenn_ziffer,akten_beginn,letzte_heftnummer,
                   neue_heftnummer,almosen_kasten,betreff,in_papier_korb,sonstige_anmerkungen,ist_ausgeliehen)
                   values (1,11,'2020-01-07',0,1, true,'first akten',false,'Detailed info of 1st akten',false );

insert into aufenthaltsort_aenderungen(datum,rueckgabe_datum,ausgeliehen_an,ausgeliehen_an_email,
                                       ist_ausgeliehen, anmerkung_aufenthaltsort,akte_fk)
       VALUES (CURRENT_TIMESTAMP(),null,'rakesh','rakesh@gmail.com',true,'free text',(select akte_id from AkTE WHERE akte_id=1));

insert into aufenthaltsort_aenderungen(datum,rueckgabe_datum,ausgeliehen_an,ausgeliehen_an_email,
                                       ist_ausgeliehen, anmerkung_aufenthaltsort,akte_fk)
    VALUES (CURRENT_TIMESTAMP(),null,'rakesh','rakesh@gmail.com',false ,'free text',(select akte_id from AkTE WHERE akte_id=1));


/*akteId=2*/
insert into AKTE(   stadt_bezirk,kenn_ziffer,akten_beginn,letzte_heftnummer,
                   neue_heftnummer,almosen_kasten,betreff,in_papier_korb,sonstige_anmerkungen,ist_ausgeliehen) values ( 2,12,'2015-01-09',1,2,
                   true,'second akten',false,'Detailed info of 2nd akten',true );

insert into aufenthaltsort_aenderungen(datum,rueckgabe_datum,ausgeliehen_an,ausgeliehen_an_email,
                                       ist_ausgeliehen, anmerkung_aufenthaltsort,akte_fk)
VALUES (CURRENT_TIMESTAMP(),null,'rakesh','rakesh@gmail.com',true,'free text',(select akte_id from AkTE WHERE akte_id=2));


/*akteId=3*/
insert into AKTE(  stadt_bezirk,kenn_ziffer,akten_beginn,letzte_heftnummer,
                   neue_heftnummer,almosen_kasten,betreff,in_papier_korb,sonstige_anmerkungen,ist_ausgeliehen) values (3,13,'2015-01-09',2,3,
                                                                                                                       true,'third akten',false,'Detailed info of 3rd akten',false );


/*akteId=4*/
insert into AKTE(   stadt_bezirk,kenn_ziffer,akten_beginn,letzte_heftnummer,
                    neue_heftnummer,almosen_kasten,betreff,in_papier_korb,sonstige_anmerkungen,ist_ausgeliehen) values ( 4,12,'2015-01-09',1,2,
                                                                                                                         true,'fourth akte borrowed',false,'Detailed info of 4th akte',true );
/*akteId=5*/
insert into AKTE(  stadt_bezirk,kenn_ziffer,akten_beginn,letzte_heftnummer,
                   neue_heftnummer,almosen_kasten,betreff,in_papier_korb,sonstige_anmerkungen,ist_ausgeliehen) values (5,13,'2015-01-09',2,3,
                                                                                                                       true,'fifth akte',false,'this akte is in archive',false );
