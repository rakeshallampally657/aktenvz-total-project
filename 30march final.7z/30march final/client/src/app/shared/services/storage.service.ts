import { Injectable } from '@angular/core';
import { Akte } from 'src/app/interfaces/Akte.interface';
import { MapperService } from './mapper.service';
import { SuchFelder } from 'src/app/interfaces/SuchFelder.interface';
import { AkteService } from "./akte.service";

@Injectable({
  providedIn: 'root',
})
export class StorageService {
  prefix: string = 'aktenvz-';
  constructor(private mapperS: MapperService, private akteS: AkteService) {}

  saveAkte(key: string, akte: Akte): void {
    if (typeof akte.aktenBeginn !== 'string')
      akte.aktenBeginn = this.mapperS.convertDateToString(akte.aktenBeginn);
    localStorage.setItem(this.prefix + key, JSON.stringify(akte));
  }

  saveSearch(key: string, suchFelder: SuchFelder): void {
    localStorage.setItem(this.prefix + key, JSON.stringify(suchFelder));
  }

  getSavedSearch(key: string): SuchFelder {
    let search: SuchFelder = {};
    const value = localStorage.getItem(this.prefix + key);
    if (value) search = JSON.parse(value);
    return search;
  }

  getSavedAkte = (key: string): Akte => {
    let akte: Akte = this.akteS.getDefaultAkte();
    const value = localStorage.getItem(this.prefix + key);
    if (value) akte = JSON.parse(value);
    akte.aktenBeginn = this.mapperS.convertStringToDate(akte.aktenBeginn);
    return akte;
  };
  removeSavedAkte(key: string): void {
    localStorage.removeItem(this.prefix + key);
  }
}
