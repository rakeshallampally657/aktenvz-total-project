export interface User {
  nutzerId: number;
  vorName: string;
  name: string;
  password: string;
  benutzerName: string;
  deleted: boolean;
  email: string;
  rechte: number[];
}
