package com.softwareone.postacademy.controller;

import com.softwareone.postacademy.dto.AkteAusleihenDTO;
import com.softwareone.postacademy.dto.AufenthaltsortDTO;
import com.softwareone.postacademy.dto.AusgelieheneAkteDTO;
import com.softwareone.postacademy.dto.ResponseDTO;
import com.softwareone.postacademy.service.AufenthaltsortAenderungenService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@CrossOrigin(origins = "http://localhost:4200",allowCredentials = "true")
@RequestMapping("/api")
public class AufenthaltsortAenderungenController {

    @Autowired
    private AufenthaltsortAenderungenService aufenthaltsortAenderungenService;

    @GetMapping(value = "/akte/{akteId}/aufenthaltsort", produces = {MediaType.APPLICATION_JSON_VALUE, MediaType.APPLICATION_XML_VALUE})
    public ResponseEntity<ResponseDTO> getAllAufenthaltsortenOfAkte(@PathVariable("akteId") Long akteId) {
            List<AufenthaltsortDTO> aufenthaltsortDTOList = aufenthaltsortAenderungenService.getAllAufenthaltsortenOfAkte(akteId);
            return new ResponseEntity<>(new ResponseDTO("The history of all aufenthaltsorten ", aufenthaltsortDTOList), HttpStatus.OK); //200 for sucess
    }

    @GetMapping(value = "/akte/ausgeliehen", produces = {MediaType.APPLICATION_JSON_VALUE, MediaType.APPLICATION_XML_VALUE})
    public ResponseEntity<ResponseDTO> getLatestAufenthaltsortOfAllBorrowedAkten() {
            List<AusgelieheneAkteDTO> ausgelieheneAkteDTOList = aufenthaltsortAenderungenService.getLatestAufenthaltsortOfAllBorrowedAkten();
            return new ResponseEntity<>(new ResponseDTO("The list of all ausgeliehn akten", ausgelieheneAkteDTOList), HttpStatus.OK); //200 for sucess
    }

    @PostMapping(value = "akte/{akteId}/ausleihen", produces = {MediaType.APPLICATION_JSON_VALUE, MediaType.APPLICATION_XML_VALUE},
            consumes = {MediaType.APPLICATION_JSON_VALUE, MediaType.APPLICATION_XML_VALUE})
    public ResponseEntity<ResponseDTO> ausleihenAkte(@RequestBody AkteAusleihenDTO akteAusleihenDTO, @PathVariable("akteId") Long akteId) {
            AusgelieheneAkteDTO ausgelieheneAkteDTO=aufenthaltsortAenderungenService.ausleihenAkte(akteAusleihenDTO, akteId);
            return new ResponseEntity<>(new ResponseDTO("Akte lended", ausgelieheneAkteDTO),
                    HttpStatus.CREATED); //201 content created successfully
    }

    @PostMapping(value = "akte/zurueckgeben", produces = {MediaType.APPLICATION_JSON_VALUE, MediaType.APPLICATION_XML_VALUE},
            consumes = {MediaType.APPLICATION_JSON_VALUE, MediaType.APPLICATION_XML_VALUE})
    public ResponseEntity<ResponseDTO> zurueckgebenAkte(@RequestBody List<Long> akteIdList) {
            List<Long> akteIdNotFoundList = aufenthaltsortAenderungenService.zurueckgebenAkten(akteIdList);
            if (akteIdNotFoundList != null) {
                return new ResponseEntity<>(
                        new ResponseDTO("at least 1 akte was not borrowed or not found", akteIdNotFoundList),
                        HttpStatus.INTERNAL_SERVER_ERROR); //500 error
            }
            return new ResponseEntity<>(new ResponseDTO("Akte returned scussesfully", null),
                    HttpStatus.CREATED); //201 content created successfully
    }
}