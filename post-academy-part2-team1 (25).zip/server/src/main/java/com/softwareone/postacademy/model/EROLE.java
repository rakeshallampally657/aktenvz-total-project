package com.softwareone.postacademy.model;

import java.util.Arrays;

public enum EROLE {
    ADMIN("0"),
    USER("1"),
    AKTE_BEARBEITEN("2"),
    AKTE_AUSLEIHEN("3"),
    AKTE_LOESCHEN("4"),
    AKTE_MELDUNGEN_VERFASSEN("5"),
    AKTE_DRUCKEN("6"),
    EXCEL_EXPORT("7");

    private final String index;

    EROLE(String index){
        this.index = index;
    }

    public String index() { return index; }
    public static EROLE get(String index) {
        return Arrays.stream(EROLE.values())
                .filter(env -> env.index.equals(index))
                .findFirst().orElse(null);
    }
}