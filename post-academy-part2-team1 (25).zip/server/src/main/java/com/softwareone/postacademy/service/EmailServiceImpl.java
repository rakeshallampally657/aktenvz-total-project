package com.softwareone.postacademy.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.stereotype.Service;

@Service
public class EmailServiceImpl implements EmailService{
    @Autowired
    private JavaMailSender mailSender;

    @Override
    public void sendSimpleMessage(String to, String subject, String name, String link){
        SimpleMailMessage message = templateSimpleMessage();
        message.setFrom("noreply@aktenvz-swo-irs.de");  //optional, but some SMTP servers would reject it if not set
        message.setSubject(subject);
        message.setTo(to);
        message.setText(String.format(message.getText(), new String[]{name, link, name, link}));
        mailSender.send(message);
    }

    private SimpleMailMessage templateSimpleMessage(){
        SimpleMailMessage message = new SimpleMailMessage();
        StringBuilder sb = new StringBuilder();
        sb.append("***english version below***\n\nHallo %s,\n\nDu hast kürzlich eine Anfrage gesendet,")
           .append(" dein AktenVZ-Passwort zurückzusetzen. Klicke folgenden Link zum fortfahren.\n\n%s\n\n")
           .append("Solltest du kein neues Passwort angefragt haben, ignoriere diese Email bitte. Der Link zum ")
           .append("zurücksetzen ist die nächsten 30 Minuten gültig.\n\ndas AktenVZ-Team\n\n\n***english version***\n\n")
           .append("Hi %s,\n\nYou recently requested to reset the password for your AktenVZ account. Click the link ")
           .append("below to proceed.\n\n%s\n\nIf you did not request a password reset, please ignore this email. ")
           .append("This password reset link is only valid for the next 30 minutes.\n\nthe AktenVZ team\n\n");
        message.setText(sb.toString());
        return message;
    }
}