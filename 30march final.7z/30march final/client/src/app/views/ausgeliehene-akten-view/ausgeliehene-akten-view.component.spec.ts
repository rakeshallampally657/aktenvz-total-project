import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AusgelieheneAktenViewComponent } from './ausgeliehene-akten-view.component';

describe('AusgelieheneAktenViewComponent', () => {
  let component: AusgelieheneAktenViewComponent;
  let fixture: ComponentFixture<AusgelieheneAktenViewComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AusgelieheneAktenViewComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(AusgelieheneAktenViewComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
