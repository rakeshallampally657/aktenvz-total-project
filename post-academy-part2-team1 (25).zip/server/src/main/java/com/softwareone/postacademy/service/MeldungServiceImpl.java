package com.softwareone.postacademy.service;

import com.softwareone.postacademy.dto.*;
import com.softwareone.postacademy.exceptions.SaveToDatabaseException;
import com.softwareone.postacademy.model.Akte;
import com.softwareone.postacademy.model.Meldung;
import com.softwareone.postacademy.model.Nutzer;
import com.softwareone.postacademy.repository.AkteRepository;
import com.softwareone.postacademy.repository.MeldungRepository;
import com.softwareone.postacademy.repository.NutzerRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;

import javax.persistence.EntityNotFoundException;
import java.time.Instant;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@Service
public class MeldungServiceImpl implements MeldungService {
    @Autowired
    private NutzerRepository nutzerRepository;
    @Autowired
    private MeldungRepository meldungRepository;
    @Autowired
    private AkteRepository akteRepository;

    private MeldungDTO convertModelToDTO(Meldung meldung){
        return new MeldungDTO(meldung);
    }

    private MeldungOeffnenResponse convertModelToDTOMeldungOeffnen(Meldung meldung){
        return new MeldungOeffnenResponse(meldung);
    }

    private Meldung convertDTOTOModel(MeldungErstellenDTO meldungErstellenDTO){
        Meldung meldung= new Meldung();
        meldung.setNachricht(meldungErstellenDTO.getNachricht());
        meldung.setBereich(meldungErstellenDTO.getBereich());
        return meldung;
    }

    @Override
    public MeldungDTO meldungErstellen(MeldungErstellenDTO meldungErstellenDTO, Long akteId) throws SaveToDatabaseException {

        Meldung meldung = convertDTOTOModel(meldungErstellenDTO);
        Optional<Akte> possibleAkte = akteRepository.findAkteBasedOnId(akteId);
        Optional<Nutzer> gemeldetVon = nutzerRepository.findByBenutzerNameAndDeleted(SecurityContextHolder.getContext().getAuthentication().getName(), false);

        if(possibleAkte.isPresent() && gemeldetVon.isPresent() && !possibleAkte.get().isIstAusgeliehen()){
            meldung.setAkte(possibleAkte.get());
            meldung.setZustand(1);// setting red for the creation
            meldung.setGemeldetAm(Instant.now());
            meldung.setGemeldetVon(gemeldetVon.get());
            return convertModelToDTO(meldungRepository.save(meldung));
        }
        else {
            throw new SaveToDatabaseException("AKTE NOTIFICATION CREATION FAILED ::: " + akteId);
        }
    }

    @Override
    public List<MeldungDTO> getAllMeldungenOfAkte(Long akteId) throws EntityNotFoundException {
        Akte obtainedAkte = akteRepository.findByAkteId(akteId);
        List<MeldungDTO> meldungDTOList = new ArrayList<>();

        if(obtainedAkte != null){
            List<Meldung> meldungList= meldungRepository.findAllMeldugenOfAkte(akteId);
            for (Meldung meldung: meldungList) {
                meldungDTOList.add(convertModelToDTO(meldung));
            }
            return meldungDTOList;
        }
        else {
            throw new EntityNotFoundException("AKTE ID NOT FOUND EXCEPTION :::  "+ akteId);
        }
    }

    @Override
    public List<MeldungDTO> getMeldungenOfAllAkten(){
        List<MeldungDTO> meldungDTOList = new ArrayList<>();
        List<Meldung> meldungList = meldungRepository.fetchAllMeldungenOfAllAkten();

        for (Meldung meldung: meldungList) {
            meldungDTOList.add(convertModelToDTO(meldung));
        }
        return meldungDTOList;
    }

    @Override
    public MeldungOeffnenResponse meldungOeffnen(Long meldungId) throws EntityNotFoundException {
        Optional<Nutzer> inBearbeitungVon = nutzerRepository.findByBenutzerNameAndDeleted(SecurityContextHolder.getContext().getAuthentication().getName(), false);
        Optional<Meldung> meldungObtained = meldungRepository.findById(meldungId);
        if(meldungObtained.isPresent() && inBearbeitungVon.isPresent()){
            Meldung meldung = meldungObtained.get();
            meldung.setInBearbeitungVon(inBearbeitungVon.get());
            if(meldung.getZustand() == 1){
                meldung.setZustand(2);
            }
            return convertModelToDTOMeldungOeffnen(meldungRepository.save(meldung));
        }
        else {
            throw new EntityNotFoundException("MELDUNG ID NOT FOUND ::: "+ meldungId);
        }
    }

    @Override
    public String meldungAbbrechen(Long meldungId) throws SaveToDatabaseException {
        Optional<Meldung> meldungObtained = meldungRepository.findById(meldungId);
        if(meldungObtained.isPresent()){
            Meldung meldung = meldungObtained.get();
            if(meldung.getZustand() == 2){
                meldung.setZustand(1);
            }
            meldung.setInBearbeitungVon(null);
            meldungRepository.save(meldung);
            return "Meldung abbrechen successful";
        }
        else {
            throw new SaveToDatabaseException("Meldung abbrechen failed");
        }
    }

    @Override
    public String meldungAbschliessen( Long meldungId) throws SaveToDatabaseException {
        Optional<Nutzer> bearbeitetDurch= nutzerRepository.findByBenutzerNameAndDeleted(SecurityContextHolder.getContext().getAuthentication().getName(), false);
        Optional<Meldung> meldungObtained = meldungRepository.findById(meldungId);
        if(meldungObtained.isPresent() && bearbeitetDurch.isPresent()){
            Meldung meldung = meldungObtained.get();
            meldung.setZustand(3);
            meldung.setBearbeitetDurch(bearbeitetDurch.get());
            meldung.setInBearbeitungVon(null);
            meldungRepository.save(meldung);
            return "Meldung abschliessen successful";
        }
        else {
            throw new SaveToDatabaseException("Meldung abschliessen failed");
        }
    }

    @Override
    public List<MeldungDTO> getAllOpenMeldungenOfAkte(Long akteId) throws EntityNotFoundException{
        Akte obtainedAkte = akteRepository.findByAkteId(akteId);
        List<MeldungDTO> meldungDTOList= new ArrayList<>();
        if(obtainedAkte != null){
            List<Meldung> meldungList=meldungRepository.fetchAllOpenMeldungenOfAkte(akteId);
            for (Meldung meldung: meldungList) {
                meldungDTOList.add(convertModelToDTO(meldung));
            }
            return meldungDTOList;
        }
        else{
            throw new EntityNotFoundException("AKTEID NOT FOUND EXCEPTION :::: " + akteId);
        }
    }

    @Override
    public List<MeldungDTO> getAllOpenMeldungenOfAllAkten(){
        List<MeldungDTO> meldungDTOList= new ArrayList<>();
        List<Meldung> meldungList=meldungRepository.fetchAllOpenMeldungenOfAllAkten();
        for (Meldung meldung: meldungList) {
            meldungDTOList.add(convertModelToDTO(meldung));
        }
        return meldungDTOList;
    }
}