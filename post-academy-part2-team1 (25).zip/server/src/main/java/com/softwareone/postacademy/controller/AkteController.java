package com.softwareone.postacademy.controller;

import com.softwareone.postacademy.dto.*;
import com.softwareone.postacademy.service.AkteService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.net.URI;
import java.util.List;

@RestController
@CrossOrigin(origins = "http://localhost:4200",allowCredentials = "true")
@RequestMapping("/api")
public class AkteController {

    @Autowired
    private AkteService akteService;

    @GetMapping(value = "/akte", produces = {MediaType.APPLICATION_JSON_VALUE, MediaType.APPLICATION_XML_VALUE})
    public ResponseEntity<ResponseDTO> fetchAllAkte(@RequestParam(value = "pageno", defaultValue = "0", required = false) int pageNo,
                                                    @RequestParam(value = "pagesize", defaultValue = "5", required = false) int pageSize) {
        List<AkteDTO> akteDTOList = akteService.getAllAkte(pageNo, pageSize);
        return new ResponseEntity<>(new ResponseDTO("", akteDTOList), HttpStatus.OK); //200 for sucess
    }

    @GetMapping(value = "/akte/{akteId}", produces = {MediaType.APPLICATION_JSON_VALUE, MediaType.APPLICATION_XML_VALUE})
    public ResponseEntity<ResponseDTO> findAkteById(@PathVariable("akteId") Long akteId) {
        AkteDTO akteDTO = akteService.fetchAkteById(akteId);
        return ResponseEntity
                .ok() // 200 for success
                .body(new ResponseDTO("", akteDTO));
    }

    @GetMapping("/akte/{akteId}/historie")
    public ResponseEntity<ResponseDTO> getAllAenderungen(@PathVariable("akteId") Long akteId){
        List<AenderungDTO> aenderungList= akteService.getHistory(akteId);
        return new ResponseEntity<>(new ResponseDTO("",aenderungList), HttpStatus.OK);
    }

    @GetMapping("/akte/version/{aenderungId}")
    public ResponseEntity<ResponseDTO> getAkteVersion(@PathVariable("aenderungId") Long aenderungId){
        AkteVersionierungDTO akteVersionierungDTO= akteService.getVersion(aenderungId);
        return new ResponseEntity<>(new ResponseDTO("",akteVersionierungDTO), HttpStatus.OK);
    }

    @GetMapping(value = "akte/papierkorb", produces = {MediaType.APPLICATION_JSON_VALUE, MediaType.APPLICATION_XML_VALUE})
    public ResponseEntity<ResponseDTO> fetchAllAkteFromPapierkorb() {
        List<PapierkorbDTO> akteDTOList = akteService.getAllAktenFromPapierkorb();
        return new ResponseEntity<>(new ResponseDTO("", akteDTOList), HttpStatus.OK); //200 for sucess
    }

    @GetMapping(value = "/akte/letzteHeftnummer", produces = {MediaType.APPLICATION_JSON_VALUE, MediaType.APPLICATION_XML_VALUE})
    public ResponseEntity<ResponseDTO> findLastHeftNUmber() {
        Long lastHeftNumber = akteService.findLastHeftNumber();
        return new ResponseEntity<>(new ResponseDTO("", lastHeftNumber), HttpStatus.OK); //200 for success
    }

    @GetMapping("/akte/filterByFields")
    public ResponseEntity<ResponseDTO> findAktenByFiltering(
            @RequestParam(value = "heftnummer", required = false) Long heftnummer,
            @RequestParam(value = "flurstueck", required = false) String flurStueck,
            @RequestParam(value = "stadtbezirk", required = false) Long stadtBezirk,
            @RequestParam(value = "kennziffer", required = false) Long kennZiffer,
            @RequestParam(value = "flur", required = false) Long flur,
            @RequestParam(value = "freitext", required = false) String freiText,
            @RequestParam(value = "pageno", defaultValue = "0", required = false) int pageNo,
            @RequestParam(value = "pagesize", defaultValue = "5", required = false) int pageSize,
            @RequestParam(value = "sortColumn", defaultValue = "kennZiffer", required = false) String sortField,
            @RequestParam(value = "sortDirection", defaultValue = "asc", required = false) String sortDirection) {
        AkteResponse akteResponse = akteService.findAktenByFiltering(heftnummer, flurStueck, stadtBezirk, kennZiffer, flur, freiText, pageNo, pageSize, sortField, sortDirection);
        return new ResponseEntity<>(new ResponseDTO("", akteResponse), HttpStatus.OK);
    }

    @GetMapping("/akte/excelExport")
    public ResponseEntity<ResponseDTO> excelExport(
            @RequestParam(value = "heftnummer", required = false) Long heftnummer,
            @RequestParam(value = "flurstueck", required = false) String flurStueck,
            @RequestParam(value = "stadtbezirk", required = false) Long stadtBezirk,
            @RequestParam(value = "kennziffer", required = false) Long kennZiffer,
            @RequestParam(value = "flur", required = false) Long flur,
            @RequestParam(value = "freitext", required = false) String freiText,
            @RequestParam(value = "pageno", defaultValue = "0", required = false) int pageNo,
            @RequestParam(value = "pagesize", defaultValue = "5", required = false) int pageSize,
            @RequestParam(value = "sortColumn", defaultValue = "kennZiffer", required = false) String sortField,
            @RequestParam(value = "sortDirection", defaultValue = "asc", required = false) String sortDirection) {
        AkteResponse akteResponse = akteService.findAktenByFiltering(heftnummer, flurStueck, stadtBezirk, kennZiffer, flur, freiText, pageNo, pageSize, sortField, sortDirection);
        return new ResponseEntity<>(new ResponseDTO("", akteResponse), HttpStatus.OK);
    }

    @PostMapping(value = "/akte/all", produces = {MediaType.APPLICATION_JSON_VALUE, MediaType.APPLICATION_XML_VALUE},
            consumes = {MediaType.APPLICATION_JSON_VALUE, MediaType.APPLICATION_XML_VALUE})
    public ResponseEntity<ResponseDTO> addAllAkten(@RequestBody List<AkteDTO> listAllAkten) {
        for (AkteDTO adto : listAllAkten) {
            AkteDTO akte = akteService.addAkte(adto);
        }
        return new ResponseEntity<>(HttpStatus.CREATED); //201 content created successfully
    }

    @PostMapping(value = "/akte", produces = {MediaType.APPLICATION_JSON_VALUE, MediaType.APPLICATION_XML_VALUE},
            consumes = {MediaType.APPLICATION_JSON_VALUE, MediaType.APPLICATION_XML_VALUE})
    public ResponseEntity<ResponseDTO> createAkte(@RequestBody AkteDTO akteDTO) {

        AkteDTO akte = akteService.addAkte(akteDTO);
        return ResponseEntity
                .created(URI.create("/akte/" + akte.getAkteId())) //201 content created successfully
                .body(new ResponseDTO("", akte));
    }

    @PutMapping(value = "/akte", produces = {MediaType.APPLICATION_JSON_VALUE, MediaType.APPLICATION_XML_VALUE},
            consumes = {MediaType.APPLICATION_JSON_VALUE, MediaType.APPLICATION_XML_VALUE})
    public ResponseEntity<ResponseDTO> modifyAkte(@RequestBody AkteDTO akteDTO) {
        AkteDTO akte = akteService.updateAkte(akteDTO);
        return new ResponseEntity<>(new ResponseDTO("", akte), HttpStatus.OK);
    }

    @DeleteMapping(value = "/akte/all")
    public void deleteAllAkten() {
        akteService.deleteAllAkten();
    }

    @DeleteMapping(value = "/akte/emptyPapierkorb")
    public ResponseEntity<ResponseDTO> deleteAllAktenFromPapierkorb() {
        String msg = akteService.deleteAllAktenFromPapierkorbPermanently();
        return new ResponseEntity<>(new ResponseDTO(msg, null), HttpStatus.OK);
    }

    @DeleteMapping(value = "/akte/permanently", produces = {MediaType.APPLICATION_JSON_VALUE})
    public ResponseEntity<ResponseDTO> delete(@RequestBody() List<Long> akteIdList) {
        String msg = akteService.deleteMultipleAktenPermanently(akteIdList);
        return new ResponseEntity<>(new ResponseDTO(msg, null), HttpStatus.OK);
    }

    @PatchMapping("/akte/restoreFromPapierkorb")
    public ResponseEntity<ResponseDTO> restoreAkten(@RequestBody() List<Long> akteIdList) {
        List<AkteDTO> akteDTOList = akteService.restoreMultipleAktenFromPapierkorb(akteIdList);
        return new ResponseEntity<>(new ResponseDTO("", akteDTOList), HttpStatus.OK);
    }

    @PatchMapping("/akte/moveToPapierkorb")
    public ResponseEntity<ResponseDTO> temporaryDeletionById(@RequestBody List<Long> aktenIds) {
        List<PapierkorbDTO> papierkorbDTOList = akteService.temporaryDeletion(aktenIds);
        return new ResponseEntity<>(new ResponseDTO("", papierkorbDTOList), HttpStatus.OK);
    }
}