import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { RoutingModule, routingComponents } from './modules/routing.module';
import { FormsModule } from '@angular/forms';
import { MaterialModule } from './modules/material.module';
import { HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';
import {
  DateAdapter,
  MAT_DATE_FORMATS,
  MAT_DATE_LOCALE,
} from '@angular/material/core';
/* import {
  MAT_MOMENT_DATE_ADAPTER_OPTIONS,
  MAT_MOMENT_DATE_FORMATS,
  MomentDateAdapter,
} from '@angular/material-moment-adapter'; */
import { NgxPrintModule } from 'ngx-print';

import { AppComponent } from './app.component';
import { GrundstuecksInformationenComponent } from './components/grundstuecks-informationen/grundstuecks-informationen.component';
import { GrundstuecksInformationenDisplayComponent } from './components/grundstuecks-informationen-display/grundstuecks-informationen-display.component';
import { AktenInformationenViewComponent } from './views/akten-informationen-view/akten-informationen-view.component';
import { DialogComponent } from './components/dialog/dialog.component';
import { AkteAusleihenDialogComponent } from './components/akte-ausleihen-dialog/akte-ausleihen-dialog.component';
import { NavComponent } from './components/nav/nav.component';
import { LayoutModule } from '@angular/cdk/layout';
import { InterceptorService } from './shared/services/loader/interceptor.service';
import { MomentDateAdapter } from '@angular/material-moment-adapter';
import { SnackBarErrorComponent } from './components/snack-bar-error/snack-bar-error.component';
import { AktenAufenthaltsorteViewComponent } from './views/akten-aufenthaltsorte-view/akten-aufenthaltsorte-view.component';
import { AktenHistorieViewComponent } from './views/akten-historie-view/akten-historie-view.component';
import { MeldungVerfassenDialogComponent } from './components/meldung-verfassen-dialog/meldung-verfassen-dialog.component';
import { MeldungenTabComponent } from './views/meldungen-tab/meldungen-tab.component';
import { BackButtonDirective } from './shared/directives/back-button.directive';
import { AuthViewComponent } from './views/auth-view/auth-view.component';
import { LoaderComponent } from './shared/services/loader/loader.component';
import { AutoLogoutDialogComponent } from './components/auto-logout-dialog/auto-logout-dialog.component';
/* import { ScrollHeightDirective } from './shared/directives/scroll-height.directive'; */

@NgModule({
  declarations: [
    AppComponent,
    NavComponent,
    GrundstuecksInformationenComponent,
    GrundstuecksInformationenDisplayComponent,
    DialogComponent,
    SnackBarErrorComponent,
    AkteAusleihenDialogComponent,
    AktenInformationenViewComponent,
    AuthViewComponent,
    ...routingComponents,
    AktenAufenthaltsorteViewComponent,
    AktenHistorieViewComponent,
    MeldungVerfassenDialogComponent,
    MeldungenTabComponent,
    BackButtonDirective,
    LoaderComponent,
    AutoLogoutDialogComponent,
    /* ScrollHeightDirective, */
  ],
  imports: [
    BrowserModule,
    RoutingModule,
    BrowserAnimationsModule,
    MaterialModule,
    FormsModule,
    LayoutModule,
    HttpClientModule,
    NgxPrintModule,
  ],
  providers: [
    { provide: HTTP_INTERCEPTORS, useClass: InterceptorService, multi: true },
    {
      provide: DateAdapter,
      useClass: MomentDateAdapter,
      /* deps: [MAT_DATE_LOCALE, MAT_MOMENT_DATE_ADAPTER_OPTIONS] */
    },
    {
      provide: MAT_DATE_FORMATS,
      useValue: {
        display: {
          dateInput: 'DD/MM/YYYY',
          monthYearLabel: 'MMM YYYY',
          dateA11yLabel: 'LL',
          monthYearA11yLabel: 'MMMM YYYY',
        },
        parse: {
          dateInput: 'DD/MM/YYYY',
        },
      },
    },
  ],
  bootstrap: [AppComponent],
})
export class AppModule {}
