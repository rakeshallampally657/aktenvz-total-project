package com.softwareone.postacademy.service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.softwareone.postacademy.dto.*;
import com.softwareone.postacademy.model.*;
import com.softwareone.postacademy.repository.*;
import org.hibernate.envers.AuditReader;
import org.hibernate.envers.AuditReaderFactory;
import org.hibernate.envers.DefaultRevisionEntity;
import org.hibernate.envers.query.AuditEntity;
import org.hibernate.envers.query.AuditQuery;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Service;

import javax.persistence.EntityManager;
import javax.persistence.EntityNotFoundException;
import javax.persistence.PersistenceContext;
import javax.transaction.Transactional;
import org.springframework.data.domain.Pageable;

import java.time.Instant;
import java.util.*;

@Service
@Transactional
public class AkteServiceImpl implements AkteService {

    @Autowired
    private AkteRepository akteRepository;
    @Autowired
    private AufenthaltsortAenderungenRepository aufenthaltsortAenderungenRepository;
    @PersistenceContext
    private EntityManager entityManager;
    @Autowired
    private NutzerRepository nutzerRepository;
    @Autowired
    private MeldungRepository meldungRepository;
    @Autowired
    private ObjectMapper jsonSerializer;
    /**
     * converting DTO to AkteModel
     */
    private Akte convertDTOToModel(AkteDTO akteDTO) {
        Akte akte = new Akte();
        akte.setAkteId(akteDTO.getAkteId());
        akte.setAlmosenKasten(akteDTO.isAlmosenKasten());
        akte.setStadtBezirk(akteDTO.getStadtBezirk());
        akte.setKennZiffer(akteDTO.getKennZiffer());
        akte.setAktenBeginn(akteDTO.getAktenBeginn());
        akte.setLetzteHeftnummer(akteDTO.getLetzteHeftnummer());
        akte.setNeueHeftnummer(akteDTO.getNeueHeftnummer());
        akte.setInPapierKorb(akteDTO.isInPapierkorb());
        akte.setBetreff(akteDTO.getBetreff());
        akte.setSonstigeAnmerkungen(akteDTO.getSonstigeAnmerkungen());
        akte.setAllGrundstuecksInformationen(akteDTO.getAllGrundstuecksInformationen());
        akte.setIstAusgeliehen(akteDTO.isIstAusgeliehen());
        return akte;
    }

    private AuditReader getAuditReader(){
        AuditReader auditReader = AuditReaderFactory.get(this.entityManager);
        return auditReader;
    }

    private PapierkorbDTO convertModelToPapierkorbDTO(Akte akte, Instant revisionDate){
        return new PapierkorbDTO(akte.getAkteId(), akte.getKennZiffer(), akte.getStadtBezirk(),
                akte.getNeueHeftnummer(), akte.getNutzer().getBenutzerName() ,revisionDate ,
                akte.getBetreff());
    }

    /**
     * converting model to DTO
     */
    private AkteDTO convertModelToDTO(Akte akte) {
        AuditReader auditReader = getAuditReader();
        List<Number> akteRevisions = auditReader.getRevisions(Akte.class, "com.softwareone.postacademy.model.Akte", akte.getAkteId());
        if(akteRevisions.isEmpty()){  //tritt nur auf, wenn die akte erstellt wird
            return new AkteDTO(akte, Instant.now());
        }
        Number latestRevision = akteRevisions.get(akteRevisions.size()-1);
        return new AkteDTO(akte,auditReader.getRevisionDate(latestRevision).toInstant());
    }

    @Override
    public AkteDTO addAkte(AkteDTO akteDTO) {
        Akte akte = convertDTOToModel(akteDTO);
        Long letzteHeftnummer = akteRepository.findLastHeftnummer();

        if (letzteHeftnummer == null) {
            letzteHeftnummer = 0L;
        }
        akte.setLetzteHeftnummer(letzteHeftnummer);
        akte.setNeueHeftnummer(letzteHeftnummer + 1);
        //akte.setAktenBeginn(Instant.now());
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        Optional<Nutzer> nutzer = nutzerRepository.findByBenutzerNameAndDeleted(authentication.getName(), false);
        if(nutzer.isPresent()){
            akte.setNutzer(nutzer.get());
        } else {
            throw new EntityNotFoundException("aktuellen Nutzer nicht gefunden");
        }
        Akte savedAkte = akteRepository.save(akte);
        return convertModelToDTO(savedAkte);
    }

    @Override
    public List<AkteDTO> getAllAkte(int pageNo,int pageSize) {
        Pageable pageable= PageRequest.of(pageNo,pageSize);
        Page<Akte> akten  = akteRepository.findAllAkten(pageable);
        List<Akte> akteList = akten.getContent();
        List<AkteDTO> akteDTOList = new ArrayList<>();
        for (Akte akte : akteList) {
            akteDTOList.add(convertModelToDTO(akte));
        }
        return akteDTOList;
    }

    @Override
    public AkteDTO fetchAkteById(Long akteId) throws EntityNotFoundException {
        Akte akte = akteRepository.findByAkteId(akteId);
        if(akte == null){
            throw new EntityNotFoundException("AKTE ID NOT FOUND EXCEPTION :::" + akteId);
        };
        return convertModelToDTO(akte);
    }

    @Override
    public List<PapierkorbDTO> getAllAktenFromPapierkorb() {
        List<Akte> akteList = akteRepository.findAllAktenFromPapierKorb();
        List<PapierkorbDTO> papierkorbDTOList = new ArrayList<>();
        AuditReader auditReader = getAuditReader();

        for (Akte akte : akteList) {
            List<Number> akteRevisions = auditReader.getRevisions(Akte.class, "com.softwareone.postacademy.model.Akte", akte.getAkteId());
            Number latestRevision = akteRevisions.get(akteRevisions.size()-1);
            papierkorbDTOList.add(convertModelToPapierkorbDTO(akte, auditReader.getRevisionDate(latestRevision).toInstant()));
        }
        return papierkorbDTOList;
    }

    @Override
    public Long findLastHeftNumber() {
        Long letzteHeftnummer = akteRepository.findLastHeftnummer();
        if (letzteHeftnummer == null) {
            letzteHeftnummer = 0L;
        }
        return letzteHeftnummer;
    }

    @Override
    public AkteResponse findAktenByFiltering(
            Long heftnummer,
            String flurStueck,
            Long stadtBezirk,
            Long kennZiffer,
            Long flur,
            String freiText,
            int pageNo,
            int pageSize,
            String sortField,
            String sortDirection) {
        Sort sort = null;
        if(!sortField.equals("kennZiffer")) {
            sort = sortDirection.equalsIgnoreCase(Sort.Direction.ASC.name()) ? Sort.by(sortField).ascending() :
                    Sort.by(sortField).descending();
        } else if (sortDirection.equalsIgnoreCase(Sort.Direction.ASC.name())){
            sort = Sort.by(sortField).ascending().and(Sort.by("stadtBezirk").ascending()
                            .and(Sort.by("neueHeftnummer").ascending()));
        } else {
            sort = Sort.by(sortField).descending().and(Sort.by("stadtBezirk").descending()
                    .and(Sort.by("neueHeftnummer").descending()));
        }
        Pageable pageable= PageRequest.of(pageNo,pageSize, sort);
        Page<Akte> akten = akteRepository.findAkteByFiltering(heftnummer,
                flurStueck,
                stadtBezirk,
                kennZiffer,
                flur,
                freiText,
                pageable);
        List<Akte> akteList = akten.getContent();
        List<AkteDTO> akteDTOList = new ArrayList<>();
        for (Akte akte : akteList) {
            akteDTOList.add(convertModelToDTO(akte));
        }
        AkteResponse akteResponse = new AkteResponse();
        akteResponse.setAktenList(akteDTOList);

        Paginator paginator= new Paginator();
        paginator.setPageSize(akten.getSize());
        paginator.setLastPage(akten.isLast());
        paginator.setTotalPages(akten.getTotalPages());
        paginator.setTotalRecords(akten.getTotalElements());

        akteResponse.setPaginator(paginator);
        return akteResponse;
    }

    @Override
    public AkteDTO updateAkte(AkteDTO akteDTO) throws EntityNotFoundException {
        Optional<Akte> akteObtained = akteRepository.findAkteBasedOnId(akteDTO.getAkteId());
        if (akteObtained.isPresent()) {
            Akte akte000 = convertDTOToModel(akteDTO);
            Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
            Optional<Nutzer> nutzer = nutzerRepository.findByBenutzerNameAndDeleted(authentication.getName(), false);
            akte000.setNutzer(nutzer.isPresent() ? nutzer.get() : nutzerRepository.findByBenutzerName("geloeschterNutzer"));
            Akte akte = akteRepository.save(akte000);
            return convertModelToDTO(akte);
        } else {
            throw new EntityNotFoundException("AKTE ID TO BE UPDATED NOT FOUND EXCEPTION :::" + akteDTO.getAkteId());
        }
    }

    @Override
    public void deleteAllAkten() {
        List<Akte> allAkten = akteRepository.findAll();
        while (!allAkten.isEmpty()) {
            akteRepository.delete(allAkten.get(0));
            allAkten.remove(0);
        }
    }

    @Override
    public String deleteAllAktenFromPapierkorbPermanently(){
        List<Akte> allAkten = akteRepository.findAllAktenFromPapierKorb();
//TODO: optimieren
        while (!allAkten.isEmpty()) {
            List<AufenthaltsortAenderungen> aufenthaltsortAenderungenList
                    =aufenthaltsortAenderungenRepository.findAllAufenthaltsortenOfAkte(allAkten.get(0).getAkteId());
            for (AufenthaltsortAenderungen aufenthaltsortAenderungen:aufenthaltsortAenderungenList) {
                aufenthaltsortAenderungen.setAkte(null);
                aufenthaltsortAenderungenRepository.delete(aufenthaltsortAenderungen);
            }
            List<Meldung> meldungList = meldungRepository.fetchAllMeldungenOfAllAktenFromPapierkorb();
            for (Meldung meldung: meldungList) {
                meldung.setAkte(null);
                meldungRepository.delete(meldung);
            }
            akteRepository.delete(allAkten.get(0));
            allAkten.remove(0);
        }
        return "PAPIERKORB HAS BEEN EMPTIED NOW";
    }

    @Override
    public List<AenderungDTO> getHistory(Long akteId) {
        AuditReader auditReader = getAuditReader();
        List<AenderungDTO> aenderungen = new ArrayList<>();
        List<Object[]> queryResult = auditReader.createQuery()
                .forRevisionsOfEntity(Akte.class, false, false)
                .add(AuditEntity.property("akteId").eq(akteId))
                .addOrder(AuditEntity.revisionNumber().desc()).getResultList();

        for(int i = 0; i < queryResult.size() -1; i++){
            AenderungDTO aenderungDTO = new AenderungDTO();
            aenderungDTO.setAenderungId(((DefaultRevisionEntity) queryResult.get(i)[1]).getId());
            aenderungDTO.setDatum(((DefaultRevisionEntity) queryResult.get(i)[1]).getRevisionDate().toInstant());
            aenderungDTO.setAktion(getAktion((Akte)queryResult.get(i)[0], (Akte)queryResult.get(i+1)[0]));
            aenderungDTO.setBenutzerName(((Akte) queryResult.get(i)[0]).getNutzer().getBenutzerName());
            aenderungen.add(aenderungDTO);
        }
        Object[] lastResult = queryResult.get(queryResult.size()-1);
        aenderungen.add(new AenderungDTO(((DefaultRevisionEntity) lastResult[1]).getId(),
                ((DefaultRevisionEntity) lastResult[1]).getRevisionDate().toInstant(),
                lastResult[2].toString(),
                ((Akte) lastResult[0]).getNutzer().getBenutzerName()));
        return aenderungen;
    }

    private String getAktion(Akte currentVersion, Akte previousVersion){  //current & previous according to time, not place in list
        if(currentVersion.isInPapierKorb() && !previousVersion.isInPapierKorb()){
            return "DEL";
        } else if(!currentVersion.isInPapierKorb() && previousVersion.isInPapierKorb()){
            return "RES";
        }
        return "MOD";
    }

    @Override
    public AkteVersionierungDTO getVersion(Long aenderungId) {
        AuditReader auditReader = getAuditReader();
        Akte akte = (Akte) auditReader.createQuery().forEntitiesModifiedAtRevision(Akte.class, aenderungId.intValue())
                .getResultList().get(0);
        System.out.println("====================================================================");
        System.out.println(akte);
        return new AkteVersionierungDTO(akte, aenderungId);
    }

    @Override
    public String deleteMultipleAktenPermanently(List<Long> akteIdList) throws EntityNotFoundException {
        List<Long> notFoundIds = new ArrayList<>();
        //TODO: optimieren
        for (Long akteId : akteIdList) {
            Optional<Akte> akteObtained = akteRepository.findAkteFromPapierkorbByid(akteId);
            if (akteObtained.isPresent()) {
                List<AufenthaltsortAenderungen> aufenthaltsortAenderungenList
                        = aufenthaltsortAenderungenRepository.findAllAufenthaltsortenOfAkte(akteObtained.get().getAkteId());

                for (AufenthaltsortAenderungen aufenthaltsortAenderungen:aufenthaltsortAenderungenList) {
                    aufenthaltsortAenderungen.setAkte(null);
                    aufenthaltsortAenderungenRepository.delete(aufenthaltsortAenderungen);
                }
                List<Meldung> meldungList = meldungRepository.findAllMeldugenOfAkte(akteId);
                for (Meldung meldung: meldungList) {
                    meldung.setAkte(null);
                    meldungRepository.delete(meldung);
                }
                akteRepository.delete(akteObtained.get());
            } else {
                notFoundIds.add(akteId);
            }
        }
        if (!notFoundIds.isEmpty()) {
            StringBuilder sb = new StringBuilder("AKTE ID TO BE DELETED NOT FOUND EXCEPTION :::");
            for (Long akteId : notFoundIds) {
                sb.append(akteId).append(", ");
            }
            sb.delete(sb.length() - 2, sb.length() - 1);
            throw new EntityNotFoundException(sb.toString());
        }
        return "SUCCESSFULLY DELETED ALL AKTEN";
    }

    @Override
    public List<PapierkorbDTO> temporaryDeletion(List<Long> aktenIds) throws EntityNotFoundException{
        List<PapierkorbDTO> papierkorbDTOList = new ArrayList<>();
        List<Long> notFoundIds = new ArrayList<>();
        AuditReader auditReader = getAuditReader();
        //TODO: optimieren
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        Optional<Nutzer> nutzer = nutzerRepository.findByBenutzerNameAndDeleted(authentication.getName(), false);
        for (Long akteId : aktenIds) {
            Optional<Akte> akteObtained = akteRepository.findAkteBasedOnId(akteId);
            if (akteObtained.isPresent()) {
                Akte akte = akteObtained.get();
                akte.setInPapierKorb(true);
                akte.setNutzer(nutzer.isPresent() ? nutzer.get() : nutzerRepository.findByBenutzerName("geloeschterNutzer"));

                akteRepository.save(akte);
                List<Number> akteRevisions = auditReader.getRevisions(Akte.class, "com.softwareone.postacademy.model.Akte", akte.getAkteId());
                Number latestRevision = akteRevisions.get(akteRevisions.size()-1);
                papierkorbDTOList.add(convertModelToPapierkorbDTO(akte, auditReader.getRevisionDate(latestRevision).toInstant()));
            } else {
                notFoundIds.add(akteId);
            }
        }
        if (!notFoundIds.isEmpty()) {
            ResponseDTO resDto = new ResponseDTO();
            resDto.setMessage("AKTE ID TO BE DELETED NOT FOUND EXCEPTION :::");
            resDto.setData(notFoundIds);
            try {
                String json = jsonSerializer.writeValueAsString(resDto);
                throw new EntityNotFoundException(json);
            } catch (JsonProcessingException jpException){
                jpException.printStackTrace();
            }
        }
        return papierkorbDTOList;
    }

    @Override
    public List<AkteDTO> restoreMultipleAktenFromPapierkorb(List<Long> akteIdList) throws EntityNotFoundException {
        List<AkteDTO> akteDTOList = new ArrayList<>();
        List<Long> notFoundIds = new ArrayList<>();
        //TODO: optimieren
        for (Long akteId : akteIdList) {
            Optional<Akte> akteObtained = akteRepository.findAkteFromPapierkorbByid(akteId);
            if (akteObtained.isPresent()) {
                Akte akte = akteObtained.get();
                akte.setInPapierKorb(false);
                akteDTOList.add(convertModelToDTO(akte));
                akteRepository.save(akte);
           } else {
                notFoundIds.add(akteId);
            }
        }
        if (!notFoundIds.isEmpty()) {
            StringBuilder sb = new StringBuilder("AKTE ID TO BE RESTORED FROM PAPIERKORB NOT FOUND EXCEPTION :::");
            for (Long akteId : notFoundIds) {
                sb.append(akteId).append(", ");
            }
            sb.delete(sb.length() - 2, sb.length() - 1);
            throw new EntityNotFoundException(sb.toString());
        }
        return akteDTOList;
    }
}