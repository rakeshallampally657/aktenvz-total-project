export interface GeloeschteAkte {
  akteId: number;
  stadtBezirk: string;
  kennZiffer: string;
  heftnummer: string;
  geloeschtVon: string;
  geloeschtAm: string;
  betreff: string;
}
