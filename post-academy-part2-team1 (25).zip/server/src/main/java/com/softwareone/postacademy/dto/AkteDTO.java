package com.softwareone.postacademy.dto;

import com.softwareone.postacademy.model.Akte;
import com.softwareone.postacademy.model.GrundstuecksInformation;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.Instant;
import java.util.List;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class AkteDTO {
    private long akteId;
    private Long stadtBezirk;
    private Long kennZiffer;
    private Instant aktenBeginn;
    private Long letzteHeftnummer;
    private Long neueHeftnummer;
    private boolean almosenKasten;
    private String betreff;
    private String sonstigeAnmerkungen;
    private boolean inPapierkorb;
    private boolean istAusgeliehen;
    private Instant letzteAenderung;
    private List<GrundstuecksInformation> allGrundstuecksInformationen;

    public AkteDTO(Akte akte, Instant letzteAenderung) {
        this.akteId = akte.getAkteId();
        this.stadtBezirk = akte.getStadtBezirk();
        this.kennZiffer = akte.getKennZiffer();
        this.aktenBeginn = akte.getAktenBeginn();
        this.letzteHeftnummer = akte.getLetzteHeftnummer();
        this.neueHeftnummer = akte.getNeueHeftnummer();
        this.almosenKasten = akte.isAlmosenKasten();
        this.betreff = akte.getBetreff();
        this.sonstigeAnmerkungen = akte.getSonstigeAnmerkungen();
        this.allGrundstuecksInformationen = akte.getAllGrundstuecksInformationen();
        this.letzteAenderung= letzteAenderung;
        this.inPapierkorb = akte.isInPapierKorb();
        this.istAusgeliehen=akte.isIstAusgeliehen();
    }
}