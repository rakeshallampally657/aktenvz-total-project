import { AfterViewInit, Component, OnInit, ViewChild } from '@angular/core';
import { SelectionModel } from '@angular/cdk/collections';
import { MatPaginator } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';
import { MatTableDataSource } from '@angular/material/table';
import { MatDialog } from '@angular/material/dialog';
import { DialogComponent } from 'src/app/components/dialog/dialog.component';
import { AusgelieheneAkte } from 'src/app/interfaces/AusgelieheneAkte.interface';
import { AkteService } from 'src/app/shared/services/akte.service';

@Component({
  selector: 'app-ausgeliehene-akten-view',
  templateUrl: './ausgeliehene-akten-view.component.html',
  styleUrls: ['./ausgeliehene-akten-view.component.scss'],
})
export class AusgelieheneAktenViewComponent implements AfterViewInit, OnInit {
  displayedColumns: string[] = [
    'select',
    'kennZiffer',
    'stadtBezirk',
    'heftnummer',
    'ausgeliehenAn',
    'ausgeliehenVon',
    'rueckgabeDatum',
    'betreff',
  ];
  dataSource = new MatTableDataSource<AusgelieheneAkte>([]);

  selection = new SelectionModel<AusgelieheneAkte>(true, []);

  @ViewChild(MatPaginator) paginator!: MatPaginator;
  @ViewChild(MatSort) sort!: MatSort;

  constructor(private akteS: AkteService, public dialog: MatDialog) {}
  ngOnInit(): void {
   this.init();
  }
  init = async (): Promise<void> => {
    this.dataSource.data = await this.akteS.getAusgelieheneAkteList();
  };

  ngAfterViewInit() {
    this.dataSource.paginator = this.paginator;
    this.dataSource.sort = this.sort;
  }

  applyFilter(event: Event) {
    const filterValue = (event.target as HTMLInputElement).value;
    this.dataSource.filter = filterValue.trim().toLowerCase();

    if (this.dataSource.paginator) {
      this.dataSource.paginator.firstPage();
    }
  }

  isAllSelected() {
    const numSelected = this.selection.selected.length;
    const numRows = this.dataSource.data.length;
    return numSelected === numRows;
  }

  masterToggle() {
    if (this.isAllSelected()) {
      this.selection.clear();
      return;
    }

    this.selection.select(...this.dataSource.data);
  }

  checkboxLabel(row?: AusgelieheneAkte): string {
    if (!row) {
      return `${this.isAllSelected() ? 'deselect' : 'select'} all`;
    }
    return `${this.selection.isSelected(row) ? 'deselect' : 'select'} row ${
      row.kennZiffer
    }`;
  }

  onSelect = async (event: Event) => {
    event.stopPropagation();
    const selected = await this.selection.selected;
    /* console.log(selected); */
  };

  /* actions:
  1: moveToPapierkorb
  2: wiederherstellen
  3: entgueltigLoeschen
  4: papierkorbLeeren
  */
  openDialog(message: string) {
    const dialogRef = this.dialog.open(DialogComponent, {
      data: {
        message,
      },
      autoFocus: false,
      maxWidth: '100%',
    });
    dialogRef.afterClosed().subscribe(async (res) => {
      if (res) {
        await this.akteS.returnFileList(
          this.selection.selected.map((akte) => akte.akteId)
        );
        const restoredAktenIds = this.selection.selected.map(
          (akte) => akte.akteId
        );
        this.dataSource.data = this.dataSource.data.filter(
          (akte) => !restoredAktenIds.includes(akte.akteId)
        );
        this.selection.clear();
      }
    });
  }
}
