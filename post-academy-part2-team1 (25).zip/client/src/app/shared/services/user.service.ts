import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';
import { User } from 'src/app/interfaces/user';
import { RequestService } from './request.service';
import { Router } from '@angular/router';
import { Credentials } from 'src/app/interfaces/credentials';
import { PasswordDetails } from 'src/app/interfaces/password-details';
import { MatDialog } from '@angular/material/dialog';
import { AutoLogoutDialogComponent } from 'src/app/components/auto-logout-dialog/auto-logout-dialog.component';

@Injectable({
  providedIn: 'root',
})
export class UserService {
  public loggedInUser = new BehaviorSubject<User | null>(null);
  private _autoLogoutTimer: any;
  constructor(
    private requestS: RequestService,
    private router: Router,
    public dialog: MatDialog
  ) {
    this.autoLogin();
  }
  autoLogin(): void {
    this.requestS.getUserFromCookie().subscribe(
      (res) => {
        this.setUser(res.data.user);
        this.autoLogout(res.data.jwtDurationInMs - 50000);
      },
      (error) => this.setUser(null)
    );
  }
  archiveList = async (nutzerIdList: (number | null)[]): Promise<void> => {
    await this.requestS
      .patch(
        'nutzer/archive',
        nutzerIdList || [],
        'Sie haben die Nutzer erfolgreich archiviert.'
      )
      .toPromise();
  };
  autoLogout = (timeoutInMs: number): void => {
    this._autoLogoutTimer = setTimeout(() => {
      const dialogRef = this.dialog.open(AutoLogoutDialogComponent, {
        autoFocus: false,
        maxWidth: '100%',
      });
      dialogRef.afterClosed().subscribe(async (res) => {
        if (res) {
          console.log('res:', res);
          this.autoLogout((await this.refreshJwt()) - 50000);
        } else {
          this.logout();
        }
      });
    }, timeoutInMs);
  };
  create = async (nutzer: User): Promise<User> => {
    const res = await this.requestS
      .post(
        'nutzer/byAdmin',
        nutzer,
        'Sie haben einen Nutzer erfolgreich erstellt.'
      )
      .toPromise();
    return res.data;
  };
  deleteList = async (nutzerIdList: (number | null)[]): Promise<void> => {
    await this.requestS
      .deleteList(
        'nutzer',
        nutzerIdList || [],
        'Sie haben die Nutzer erfolgreich entgültig gelöscht.'
      )
      .toPromise();
  };
  get = async (nutzerId: number): Promise<User> => {
    const res = await this.requestS
      .getAllItems('nutzer/' + nutzerId)
      .toPromise();
    return res.data;
  };
  getAllList = async (): Promise<User[]> => {
    const res = await this.requestS.getAllItems('nutzer/all').toPromise();
    return res.data.nutzerList;
  };
  getLink = async (email: string): Promise<string> => {
    const res = await this.requestS
      .post(
        'nutzer/resetPassword',
        email,
        null,
        'Bitte überprüfen Sie Ihr Postfach.'
      )
      .toPromise();
    return res.data;
  };
  getList = async (): Promise<User[]> => {
    const res = await this.requestS.getAllItems('nutzer').toPromise();
    return res.data.nutzerList;
  };
  login = async (credentials: Credentials): Promise<void> => {
    const res = await this.requestS
      .post('nutzer/login', credentials)
      .toPromise();
    this.autoLogout(res.data.jwtDurationInMs - 50000);
    this.setUser(res.data.user);
  };
  logout = async (): Promise<void> => {
    await this.requestS.post('nutzer/logout').toPromise();
    if (this._autoLogoutTimer) {
      clearTimeout(this._autoLogoutTimer);
    }
    this.setUser(null);
  };
  refreshJwt = async (): Promise<number> => {
    const res = await this.requestS.patch('nutzer/refresh').toPromise();
    return res.data.jwtDurationInMs;
  };
  register = async (nutzer: User): Promise<User> => {
    const res = await this.requestS
      .post('nutzer', nutzer, 'Sie haben Ihr Konto erfolgreich erstellt.')
      .toPromise();
    return res.data;
  };
  setUser(user: User | null) {
    if (!!user) {
      /* console.log('if triggered, url:\n', this.router.url); */
      user.rechte = user.rechte.map((recht: any) => Number(recht));
      this.router.navigate([
        /* route is NOT /app... */
        !/\/app(.+)?/g.test(this.router.url)
          ? '/app/akten-verzeichnis'
          : this.router.url,
      ]);
    } else {
      /* route is NOT /auth... */
      this.router.navigate([
        !/\/auth.+/.test(this.router.url) ? '/auth/login' : this.router.url,
      ]);
    }
    this.loggedInUser.next(user);
  }
  unarchiveList = async (nutzerIdList: (number | null)[]): Promise<void> => {
    await this.requestS
      .patch(
        'nutzer/unarchive',
        nutzerIdList || [],
        'Sie haben die Nutzer erfolgreich wiederhergestellt.'
      )
      .toPromise();
  };
  update = async (nutzer: User): Promise<User> => {
    const res = await this.requestS
      .put('nutzer', nutzer, 'Sie haben den Nutzer erfolgreich aktualisiert.')
      .toPromise();
    return res.data;
  };
  updatePassword = async (pwDetails: PasswordDetails): Promise<void> => {
    await this.requestS
      .put(
        'nutzer/password',
        pwDetails,
        'Ihr Passwort wurde erfolgreich aktualisiert.'
      )
      .toPromise();
  };
}
