import { User } from 'src/app/interfaces/user';
import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { UserService } from 'src/app/shared/services/user.service';

@Component({
  selector: 'app-nutzer-bearbeiten-view',
  templateUrl: './nutzer-bearbeiten-view.component.html',
  styleUrls: ['./nutzer-bearbeiten-view.component.scss'],
})
export class NutzerBearbeitenViewComponent implements OnInit {
  createMode: boolean = false;

  nutzer: User = {
    nutzerId: NaN,
    vorName: '',
    name: '',
    benutzerName: '',
    email: '',
    password: '',
    rechte: [],
    deleted: false,
  };

  confirmPassword: string = '';

  rechtList = [
    { name: 'Administrator', granted: false },
    { name: 'Nutzer', granted: false },
    { name: 'darf Akten bearbeiten', granted: false },
    { name: 'darf Akten ausleihen', granted: false },
    { name: 'darf Akten löschen', granted: false },
    { name: 'darf Aktenmeldungen verfassen', granted: false },
    { name: 'darf Akten drucken', granted: false },
    { name: 'darf Excel-Export durchführen', granted: false },
  ];

  constructor(
    private route: ActivatedRoute,
    private userS: UserService,
    private router: Router
  ) {
    this.createMode = this.router.url.split('/').includes('nutzer-erstellen');
    if (!this.createMode) {
      this.userS
        .get(this.route.snapshot.params.nutzerId)
        .then((nutzer: User) => {
          this.nutzer = nutzer;
          nutzer.rechte.forEach((recht: number) => {
            this.rechtList[+recht].granted = true;
          });
        });
    }
  }

  ngOnInit(): void {}

  onSubmit() {
    this.nutzer.rechte = [];
    this.rechtList.forEach((recht, i) => {
      if (recht.granted) this.nutzer.rechte.push(i);
    });
    let newUser: Promise<User>;
    if (this.createMode) {
      newUser = this.userS.create(this.nutzer);
    } else {
      newUser = this.userS.update(this.nutzer);
    }
    newUser.then(() => {
      this.router.navigate(['/app/administration']);
    });
  }
}
