export interface PasswordDetails {
  passwordResetToken: string;
  password: string;
}
