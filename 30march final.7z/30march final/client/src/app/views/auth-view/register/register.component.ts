import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { Router } from '@angular/router';
import { User } from 'src/app/interfaces/user';
import { UserService } from 'src/app/shared/services/user.service';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.scss'],
})
export class RegisterComponent implements OnInit {
  password: string = '';
  constructor(private userS: UserService, private router: Router) {}

  ngOnInit(): void {}

  onSubmit = async (form: NgForm): Promise<void> => {
    /* console.log('auth:form:\n', form.value); */
    if (form.invalid) {
      return;
    }
    const nutzer: User = {
      nutzerId: NaN,
      vorName: form.value.vorName,
      name: form.value.name,
      benutzerName: form.value.benutzerName,
      email: form.value.email,
      password: form.value.password,
      rechte: [],
      deleted: false,
    };
    await this.userS.register(nutzer);
    this.router.navigate(['/auth/login']);
    form.reset();
  };
}
