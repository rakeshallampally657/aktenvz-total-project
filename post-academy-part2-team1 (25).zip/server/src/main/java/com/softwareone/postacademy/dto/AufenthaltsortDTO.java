package com.softwareone.postacademy.dto;

import com.softwareone.postacademy.model.AufenthaltsortAenderungen;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.Instant;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class AufenthaltsortDTO {
    private Instant datum;
    private String aufenthaltsort;
    private String anmerkungAufenthaltsort;

    public AufenthaltsortDTO(AufenthaltsortAenderungen aufenthaltsortAenderungen){
        this.datum= aufenthaltsortAenderungen.getDatum();
        this.aufenthaltsort=aufenthaltsortAenderungen.getAusgeliehenAn();
        this.anmerkungAufenthaltsort=aufenthaltsortAenderungen.getAnmerkungAufenthaltsort();
    }
}