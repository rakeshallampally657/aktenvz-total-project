import { SelectionModel } from '@angular/cdk/collections';
import { Component, OnInit, ViewChild } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { MatPaginator } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';
import { MatTableDataSource } from '@angular/material/table';
import { DialogComponent } from 'src/app/components/dialog/dialog.component';
import { DialogResponse } from 'src/app/interfaces/dialog-response';
import { User } from 'src/app/interfaces/user';
import { UserService } from 'src/app/shared/services/user.service';

@Component({
  selector: 'app-administration-view',
  templateUrl: './administration-view.component.html',
  styleUrls: ['./administration-view.component.scss'],
})
export class AdministrationViewComponent implements OnInit {
  showArchivedOnly: boolean = false;
  displayedColumns: string[] = [
    'select',
    'nutzerId',
    'vorName',
    'name',
    'benutzerName',
    'email',
  ];
  dataSource = new MatTableDataSource<User>([]);

  selection = new SelectionModel<User>(true, []);

  @ViewChild(MatPaginator) paginator!: MatPaginator;
  @ViewChild(MatSort) sort!: MatSort;

  constructor(
    public dialog: MatDialog,
    private userS: UserService
  ) {
    this.userS.getAllList().then((userList: User[]) => {
      this.dataSource.data = userList;
    });
  }
  ngOnInit(): void {}

  ngAfterViewInit() {
    this.dataSource.paginator = this.paginator;
    this.dataSource.sort = this.sort;
  }

  applyFilter(event: Event) {
    const filterValue = (event.target as HTMLInputElement).value;
    this.dataSource.filter = filterValue.trim().toLowerCase();

    if (this.dataSource.paginator) {
      this.dataSource.paginator.firstPage();
    }
  }

  isAllSelected() {
    const numSelected = this.selection.selected.length;
    const numRows = this.dataSource.data.length;
    return numSelected === numRows;
  }

  masterToggle() {
    if (this.isAllSelected()) {
      this.selection.clear();
      return;
    }

    this.selection.select(...this.dataSource.data);
  }

  checkboxLabel(row?: User): string {
    if (!row) {
      return `${this.isAllSelected() ? 'deselect' : 'select'} all`;
    }
    return `${this.selection.isSelected(row) ? 'deselect' : 'select'} row ${
      row.nutzerId
    }`;
  }

  onSelect = async (event: Event) => {
    event.stopPropagation();
    await this.selection.selected;
  };

  openDialog(message: string, action: string) {
    const dialogRef = this.dialog.open(DialogComponent, {
      data: {
        message,
        action,
      },
      autoFocus: false,
      maxWidth: '100%',
    });
    dialogRef.afterClosed().subscribe((res: DialogResponse) => {
      console.log('dialog res:', res);
      const userIdList: (number | null)[] = this.selection.selected.map(
        (nutzer) => nutzer.nutzerId
      );
      if (res.res) {
        switch (res.action) {
          case 'archivieren': {
            this.userS.archiveList(userIdList).then(() => {
              if (this.showArchivedOnly) {
                console.log('showArchivedOnly triggered');
                this.dataSource.data = this.dataSource.data.filter(
                  (user) => !this.selection.selected.includes(user)
                );
              } else {
                this.dataSource.data.forEach((user) => {
                  if (this.selection.selected.includes(user)) {
                    user.deleted = true;
                  }
                });
              }
              this.selection.clear();
            });
            break;
          }
          case 'wiederherstellen': {
            this.userS.unarchiveList(userIdList).then(() => {
              this.dataSource.data.forEach((user) => {
                if (this.selection.selected.includes(user)) {
                  user.deleted = false;
                }
              });
              this.selection.clear();
            });
            break;
          }
          case 'entgueltigLoeschen': {
            this.userS.deleteList(userIdList).then(() => {
              this.dataSource.data = this.dataSource.data.filter(
                (user) => !this.selection.selected.includes(user)
              );
              this.selection.clear();
            });
            break;
          }
          default: {
            console.log('unknown dialog action');
            break;
          }
        }
      }
    });
  }

  refreshTable() {
    let userList: Promise<User[]> ;
    if(this.showArchivedOnly){
      userList = this.userS.getList();
    }
    else{
      userList = this.userS.getAllList();
    }
    userList.then((userList) => (this.dataSource.data = userList));
  }
}
