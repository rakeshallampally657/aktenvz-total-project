import { ComponentFixture, TestBed } from '@angular/core/testing';

import { GrundstuecksInformationenComponent } from './grundstuecks-informationen.component';

describe('GrundstuecksInformationenComponent', () => {
  let component: GrundstuecksInformationenComponent;
  let fixture: ComponentFixture<GrundstuecksInformationenComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ GrundstuecksInformationenComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(GrundstuecksInformationenComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
