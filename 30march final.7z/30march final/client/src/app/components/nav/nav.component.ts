import { Component, OnDestroy, OnInit } from '@angular/core';
import { BreakpointObserver, Breakpoints } from '@angular/cdk/layout';
import { Observable, Subscription } from 'rxjs';
import { map, shareReplay } from 'rxjs/operators';
import { LoaderService } from 'src/app/shared/services/loader/loader.service';
import { UserService } from 'src/app/shared/services/user.service';
import { AuthGuardService } from 'src/app/shared/services/auth-guard.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-nav',
  templateUrl: './nav.component.html',
  styleUrls: ['./nav.component.scss'],
})
export class NavComponent implements OnInit, OnDestroy {
  isHandset$: Observable<boolean> = this.breakpointObserver
    .observe(Breakpoints.Handset)
    .pipe(
      map((result) => result.matches),
      shareReplay()
    );

  loggedInUserSub!: Subscription;
  loggedInUser!: string | undefined;

  constructor(
    private breakpointObserver: BreakpointObserver,
    public loaderS: LoaderService,
    private userS: UserService,
    public authS: AuthGuardService,
    private router: Router
  ) {}

  ngOnInit() {
    this.init();
  }
  init() {
    this.loggedInUserSub = this.userS.loggedInUser.subscribe(
      (user) => (this.loggedInUser = user?.benutzerName)
    );
  }
  logout = async (): Promise<void> => {
    await this.userS.logout();
    this.router.navigate(['/auth/login']);
  };
  ngOnDestroy(): void {
    this.loggedInUserSub.unsubscribe();
  }
}
