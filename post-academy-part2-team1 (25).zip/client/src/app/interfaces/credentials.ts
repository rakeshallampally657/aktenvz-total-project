export interface Credentials {
  benutzerNameOrEmail: string;
  password: string;
}
