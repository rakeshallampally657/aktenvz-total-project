import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AktenDetailsViewComponent } from './akten-details-view.component';

describe('AktenDetailsViewComponent', () => {
  let component: AktenDetailsViewComponent;
  let fixture: ComponentFixture<AktenDetailsViewComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AktenDetailsViewComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(AktenDetailsViewComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
