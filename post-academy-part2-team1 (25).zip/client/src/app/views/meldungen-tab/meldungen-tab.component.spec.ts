import { ComponentFixture, TestBed } from '@angular/core/testing';

import { MeldungenTabComponent } from './meldungen-tab.component';

describe('MeldungenTabComponent', () => {
  let component: MeldungenTabComponent;
  let fixture: ComponentFixture<MeldungenTabComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ MeldungenTabComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(MeldungenTabComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
