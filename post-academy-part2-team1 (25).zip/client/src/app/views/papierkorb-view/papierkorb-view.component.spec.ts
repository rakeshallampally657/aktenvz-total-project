import { ComponentFixture, TestBed } from '@angular/core/testing';

import { PapierkorbViewComponent } from './papierkorb-view.component';

describe('PapierkorbViewComponent', () => {
  let component: PapierkorbViewComponent;
  let fixture: ComponentFixture<PapierkorbViewComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ PapierkorbViewComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(PapierkorbViewComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
