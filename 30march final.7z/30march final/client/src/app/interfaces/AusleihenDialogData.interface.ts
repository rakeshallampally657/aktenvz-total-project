import { User } from './user';

export interface AusleihenDialogData {
  stadtBezirk: string;
  kennZiffer: string;
  heftnummer: string;
  loggedInUser: User;
  userList: User[];
}
