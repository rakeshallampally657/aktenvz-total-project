import { Component, OnInit, ViewChild } from '@angular/core';
import { MatPaginator } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';
import { MatTableDataSource } from '@angular/material/table';
import { RequestService } from 'src/app/shared/services/request.service';
import { MatDialog } from '@angular/material/dialog';
import { MeldungShort } from 'src/app/interfaces/MeldungShort.interface';
import { MatSlideToggleChange } from '@angular/material/slide-toggle';

@Component({
  selector: 'app-akten-meldungen-view',
  templateUrl: './akten-meldungen-view.component.html',
  styleUrls: ['./akten-meldungen-view.component.scss'],
})
export class AktenMeldungenViewComponent implements OnInit {
  displayedColumns: string[] = [
    'bearbeitetDurch',
    'gemeldetAm',
    'gemeldetVon',
    'kennZiffer',
    'almosenKasten',
    'stadtBezirk',
    'heftnummer',
    'bereich',
    'inBearbeitungVon',
  ];
  dataSource = new MatTableDataSource<MeldungShort>([]);
  @ViewChild(MatPaginator) paginator!: MatPaginator;
  @ViewChild(MatSort) sort!: MatSort;

  constructor(private requestS: RequestService, public dialog: MatDialog) {}
  ngOnInit(): void {
   this.init();
  }
  init = async (): Promise<void> => {
    const res = await this.requestS.getAllItems('akte/meldungen').toPromise();
    this.dataSource.data = res.data;
  };

  ngAfterViewInit() {
    this.dataSource.paginator = this.paginator;
    this.dataSource.sort = this.sort;
  }

  refreshTable = async (event: MatSlideToggleChange): Promise<void> => {
    const res = await this.requestS
      .getAllItems(event.checked ? 'akte/meldungen/offen' : 'akte/meldungen/')
      .toPromise();
    this.dataSource.data = res.data;
  };
}
