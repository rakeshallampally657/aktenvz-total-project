import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AddDummyDataViewComponent } from './add-dummy-data-view.component';

describe('AddDummyDataViewComponent', () => {
  let component: AddDummyDataViewComponent;
  let fixture: ComponentFixture<AddDummyDataViewComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AddDummyDataViewComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(AddDummyDataViewComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
