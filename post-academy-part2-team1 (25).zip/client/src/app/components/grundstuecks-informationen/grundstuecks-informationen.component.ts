import {
  Component,
  OnInit,
  Input,
  Output,
  EventEmitter,
  ViewChild,
} from '@angular/core';
import { NgForm } from '@angular/forms';
import { MapperService } from 'src/app/shared/services/mapper.service';
import { GrundstuecksInformation } from '../../interfaces/GrundstuecksInformation.interface';

@Component({
  selector: 'app-grundstuecks-informationen',
  templateUrl: './grundstuecks-informationen.component.html',
  styleUrls: ['./grundstuecks-informationen.component.scss'],
})
export class GrundstuecksInformationenComponent implements OnInit {
  @Input() tableData: GrundstuecksInformation[] = [];
  @Output() onTableUpdate = new EventEmitter<GrundstuecksInformation[]>();

  @ViewChild('addForm') addForm: NgForm = new NgForm([], []);

  tableColumns: string[] = [
    'gemarkung',
    'flur',
    'flurStueck',
    'vertragsBeginn',
    'laufzeit',
    'vertragsNummer',
    'anmerkung',
    'aktion',
  ];
  currentEntry: GrundstuecksInformation = {
    grundstuecksInformationId: '',
    gemarkung: '',
    flur: '',
    flurStueck: '',
    vertragsBeginn: '',
    laufzeit: '',
    vertragsNummer: '',
    anmerkung: '',
    isEditable: false,
  };
  constructor(private mapperS: MapperService) {}

  ngOnInit(): void {}

  createNewEntry = (): GrundstuecksInformation => ({
    grundstuecksInformationId: '',
    gemarkung: this.currentEntry.gemarkung,
    flur: this.currentEntry.flur,
    flurStueck: this.currentEntry.flurStueck,
    vertragsBeginn: this.mapperS.convertDateToString(
      this.currentEntry.vertragsBeginn
    ),
    laufzeit: this.currentEntry.laufzeit,
    vertragsNummer: this.currentEntry.vertragsNummer,
    anmerkung: this.currentEntry.anmerkung,
    isEditable: false,
  });

  save(index: number) {
    this.tableData[index].vertragsBeginn = this.mapperS.convertDateToString(
      this.tableData[index].vertragsBeginn
    );
    this.tableData[index].isEditable = false;
    this.onTableUpdate.emit(this.tableData);
  }

  delete(index: number) {
    this.tableData.splice(index, 1);
    this.tableData = [...this.tableData];
    this.onTableUpdate.emit(this.tableData);
  }
  add() {
    if (this.addForm.form.valid) {
      this.tableData = [...this.tableData, this.createNewEntry()];
      this.onTableUpdate.emit(this.tableData);
      this.addForm.reset();
    }
  }
}
