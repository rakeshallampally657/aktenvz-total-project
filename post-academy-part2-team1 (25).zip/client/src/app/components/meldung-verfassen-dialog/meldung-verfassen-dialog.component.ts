import { Component, Inject, OnInit } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { Akte } from 'src/app/interfaces/Akte.interface';
import { MapperService } from 'src/app/shared/services/mapper.service';

@Component({
  selector: 'app-meldung-verfassen-dialog',
  templateUrl: './meldung-verfassen-dialog.component.html',
  styleUrls: ['./meldung-verfassen-dialog.component.scss'],
})
export class MeldungVerfassenDialogComponent implements OnInit {
  akte: Akte;
  bereichList: string[] = [
    'Stadtbezirk (Gemarkung)',
    'Kennziffer',
    'Heftnummer',
    'Aktenbeginn',
    'Almosenkasten',
  ];

  bereich: string = '';

  nachricht: string = '';

  constructor(
    public dialogRef: MatDialogRef<MeldungVerfassenDialogComponent>,
    @Inject(MAT_DIALOG_DATA) public data: { akte: Akte },

    private mapperS: MapperService
  ) {
    this.akte = data.akte;
    this.akte.aktenBeginn = this.mapperS.convertDateToString(
      this.akte.aktenBeginn
    );
  }

  ngOnInit(): void {}

  closeDialog(res: number) {
    if (res)
      this.dialogRef.close({
        res,
        bereich: this.bereich,
        nachricht: this.nachricht,
      });
  }
}
