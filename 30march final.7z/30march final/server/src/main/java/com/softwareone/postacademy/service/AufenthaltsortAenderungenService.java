package com.softwareone.postacademy.service;

import com.softwareone.postacademy.dto.AkteAusleihenDTO;
import com.softwareone.postacademy.dto.AufenthaltsortDTO;
import com.softwareone.postacademy.dto.AusgelieheneAkteDTO;

import javax.persistence.EntityNotFoundException;
import java.util.List;

public interface AufenthaltsortAenderungenService {

    AusgelieheneAkteDTO ausleihenAkte(AkteAusleihenDTO akteAusleihenDTO, Long akteId) throws EntityNotFoundException;
    List<AufenthaltsortDTO> getAllAufenthaltsortenOfAkte(Long akteId);
    List<AusgelieheneAkteDTO> getLatestAufenthaltsortOfAllBorrowedAkten();
    List<Long> zurueckgebenAkten(List<Long> akteIdList);
}