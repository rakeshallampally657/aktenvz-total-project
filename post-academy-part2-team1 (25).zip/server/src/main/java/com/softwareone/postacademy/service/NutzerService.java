package com.softwareone.postacademy.service;

import com.softwareone.postacademy.dto.LoginDTO;
import com.softwareone.postacademy.dto.NewPasswortDTO;
import com.softwareone.postacademy.dto.NutzerDTO;

import javax.persistence.EntityNotFoundException;
import java.util.List;

public interface NutzerService {
    List<NutzerDTO> getAllNutzer();
    NutzerDTO addNutzer(NutzerDTO nutzerDTO);
    NutzerDTO updateNutzer(NutzerDTO nutzerDTO) throws EntityNotFoundException;
    NutzerDTO fetchNutzerById(Long nutzerId) throws EntityNotFoundException;
    NutzerDTO fetchNutzerByName(String nutzerName) throws EntityNotFoundException;
    void deleteMultipleNutzer(List<Long> nutzerIds);
    List<NutzerDTO> getAllCurrentNutzer();
    void archiveMultipleNutzer(List<Long> nutzerIdList);
    void unarchiveMultipleNutzer(List<Long> nutzerIdList);
    void createNewPassword(NewPasswortDTO newPasswordDto);
    String resetPassword(String email);
}