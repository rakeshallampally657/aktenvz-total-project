export interface AusgelieheneAkte {
  akteId: number;
  stadtBezirk: number;
  kennZiffer: number;
  heftnummer: number;
  betreff: string;
  ausgeliehenAn: string;
  ausgeliehenVon: string;
  rueckgabeDatum: any;
}
