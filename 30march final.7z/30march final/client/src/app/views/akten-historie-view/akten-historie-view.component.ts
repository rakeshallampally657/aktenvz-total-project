import { AfterViewInit, Component, ViewChild } from '@angular/core';
import { MatPaginator } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';
import { MatTableDataSource } from '@angular/material/table';
import { Aenderung } from 'src/app/interfaces/Aenderung.interface';
import { Akte } from 'src/app/interfaces/Akte.interface';
import { AkteService } from 'src/app/shared/services/akte.service';
import { RequestService } from 'src/app/shared/services/request.service';

@Component({
  selector: 'app-akten-historie-view',
  templateUrl: './akten-historie-view.component.html',
  styleUrls: ['./akten-historie-view.component.scss'],
})
export class AktenHistorieViewComponent implements AfterViewInit {
  akteId: number = NaN;
  akte: Akte = this.akteS.getDefaultAkte();
  displayedColumns = ['datum', 'benutzerName', 'aktion'];
  dataSource = new MatTableDataSource<Aenderung>([]);
  selectedAenderungId: number = NaN;
  currentVersion: Akte = this.akte;
  speichernDisabled: boolean = false;
  @ViewChild(MatPaginator) paginator!: MatPaginator;
  @ViewChild(MatSort) sort!: MatSort;
  constructor(private requestS: RequestService, private akteS: AkteService) {}
  ngAfterViewInit() {
    this.dataSource.paginator = this.paginator;
    this.dataSource.sort = this.sort;
  }
  ngOnInit(): void {
    this.init();
  }
  init = async (): Promise<void> => {
    this.akteId = this.akteS.getAkteId();

    const aenderungList: Aenderung[] = await this.akteS.getAenderungList();
    aenderungList.forEach((aenderung) => {
      switch (aenderung.aktion) {
        case 'ADD': {
          aenderung.aktion = 'Erstellt';
          break;
        }
        case 'MOD': {
          aenderung.aktion = 'Bearbeitet';
          break;
        }
        case 'DEL': {
          aenderung.aktion = 'Gelöscht';

          break;
        }
        case 'RES': {
          aenderung.aktion = 'Wiederhergestellt';
          break;
        }
        default: {
          aenderung.aktion = 'Unbekannte Aktion';
          break;
        }
      }
    });

    this.dataSource.data = aenderungList;
    this.selectedAenderungId = aenderungList[0]?.aenderungId || 0;

    const version = await this.akteS.getVersion(this.selectedAenderungId);
    this.akte = version;
    this.currentVersion = version;
    this.speichernDisabled = version.inPapierkorb || false;
  };
  displayVersion = async (aenderungId: number): Promise<void> => {
    this.selectedAenderungId = aenderungId;
    const version = await this.akteS.getVersion(aenderungId);
    this.akte = version;
    this.speichernDisabled =
      version.inPapierkorb || this.currentVersion.inPapierkorb || false;
  };
  save() {
    this.akteS.update(this.akte).then(() => {
      this.requestS
        .getAenderungen(this.akteId)
        .subscribe((aenderungenList: Aenderung[]) => {
          this.dataSource.data = aenderungenList;
          this.selectedAenderungId = aenderungenList[0].aenderungId;
        });
    });
  }
}
