package com.softwareone.postacademy.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.hibernate.envers.Audited;
import org.hibernate.envers.NotAudited;
import org.springframework.lang.Nullable;

import javax.persistence.*;
import java.util.List;
import java.util.Set;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "NUTZER", uniqueConstraints = {
        @UniqueConstraint(columnNames = {"benutzerName"}),
        @UniqueConstraint(columnNames = {"email"})
})
@Audited
public class Nutzer {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private long nutzerId;
    private String benutzerName;
    private String vorName;
    private String name;
    private String email;
    @NotAudited
    private String password;
    @ElementCollection(fetch = FetchType.EAGER)
    @CollectionTable(name = "rechte_table",
    joinColumns = @JoinColumn(name = "nutzerId"))
    @Column(name = "rechte")
    @Enumerated(EnumType.STRING)
    @NotAudited
    private Set<EROLE> rechte;
    private boolean deleted;
    @OneToMany()
    private List<Akte> bearbeiteteAkten;
    @NotAudited
    @Nullable
    private String passwordResetToken;
}