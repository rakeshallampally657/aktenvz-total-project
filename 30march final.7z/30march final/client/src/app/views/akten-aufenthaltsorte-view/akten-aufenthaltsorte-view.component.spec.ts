import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AktenAufenthaltsorteViewComponent } from './akten-aufenthaltsorte-view.component';

describe('AktenAufenthaltsorteViewComponent', () => {
  let component: AktenAufenthaltsorteViewComponent;
  let fixture: ComponentFixture<AktenAufenthaltsorteViewComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AktenAufenthaltsorteViewComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(AktenAufenthaltsorteViewComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
