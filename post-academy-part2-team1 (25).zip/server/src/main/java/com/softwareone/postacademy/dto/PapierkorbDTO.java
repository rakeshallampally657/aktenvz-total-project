package com.softwareone.postacademy.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.Instant;

@AllArgsConstructor
@NoArgsConstructor
@Data
public class PapierkorbDTO {
    private Long akteId;
    private Long kennZiffer;
    private Long stadtBezirk;
    private Long heftNummer;
    private String geloeschtVon;
    private Instant geloeschtAm;
    private String betreff;
}