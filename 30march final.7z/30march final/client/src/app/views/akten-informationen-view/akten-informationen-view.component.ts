import { Component, HostListener, OnInit } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { Router } from '@angular/router';
import { take } from 'rxjs/operators';
import { AkteAusleihenDialogComponent } from 'src/app/components/akte-ausleihen-dialog/akte-ausleihen-dialog.component';
import { DialogComponent } from 'src/app/components/dialog/dialog.component';
import { MeldungVerfassenDialogComponent } from 'src/app/components/meldung-verfassen-dialog/meldung-verfassen-dialog.component';
import { Akte } from 'src/app/interfaces/Akte.interface';
import { AkteService } from 'src/app/shared/services/akte.service';
import { StorageService } from 'src/app/shared/services/storage.service';
import { UserService } from 'src/app/shared/services/user.service';

@Component({
  selector: 'app-akten-informationen-view',
  templateUrl: './akten-informationen-view.component.html',
  styleUrls: ['./akten-informationen-view.component.scss'],
})
export class AktenInformationenViewComponent implements OnInit {
  akteId: number = NaN;
  akte: Akte = this.akteS.getDefaultAkte();
  constructor(
    private storageS: StorageService,
    private router: Router,
    private akteS: AkteService,
    private userS: UserService,
    public dialog: MatDialog
  ) {}
  ngOnInit(): void {
    this.setAkteAndAkteId();
  }
  setAkteAndAkteId = async (): Promise<void> => {
    this.akteId = await this.akteS.getAkteId();
    this.akte = await this.akteS.get(this.akteId);
  };
  openLoeschenDialog(message: string) {
    const dialogRef = this.dialog.open(DialogComponent, {
      data: { message },
      autoFocus: false,
      maxWidth: '100%',
    });
    dialogRef.afterClosed().subscribe((result) => {
      if (result) {
        this.akteS.moveToPapierkorb([this.akteId]).then(() => {
          this.router.navigate(['/app/akten-verzeichnis']);
        });
      }
    });
  }

  openAusleihenDialog = async (): Promise<void> => {
    const { stadtBezirk, kennZiffer, neueHeftnummer } = this.akte;
    const userList = await this.userS.getList();
    this.userS.loggedInUser.pipe(take(1)).subscribe(async (loggedInUser) => {
      const dialogRef = this.dialog.open(AkteAusleihenDialogComponent, {
        data: {
          stadtBezirk,
          kennZiffer,
          heftnummer: neueHeftnummer,
          loggedInUser,
          userList,
        },
        autoFocus: false,
        maxWidth: '100%',
      });
      const dialogRes = await dialogRef.afterClosed().toPromise();
      if (dialogRes.res) {
        await this.akteS.borrowFile(this.akteId, dialogRes.ausleihDetails);
        this.akte = await this.akteS.get(this.akteId);
      }
    });
  };

  openMeldungVerfassenDialog = async () => {
    const dialogRef = this.dialog.open(MeldungVerfassenDialogComponent, {
      data: {
        akte: { ...this.akte },
      },
      autoFocus: false,
      maxWidth: '100%',
    });

    const response = await dialogRef.afterClosed().toPromise();
    if (response.res) {
      this.akteS.createNotification({
        bereich: response.bereich,
        nachricht: response.nachricht,
      });
    }
  };

  @HostListener('window:beforeunload', ['$event']) handleBeforeunload(
    event: Event
  ) {
    this.storageS.saveAkte('current-akte', this.akte);
  }
}
