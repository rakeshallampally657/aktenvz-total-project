package com.softwareone.postacademy.service;

import com.softwareone.postacademy.dto.*;
import com.softwareone.postacademy.exceptions.SaveToDatabaseException;

import javax.persistence.EntityNotFoundException;
import java.util.List;

public interface MeldungService {
    MeldungDTO meldungErstellen(MeldungErstellenDTO meldungErstellenDTO, Long akteId) throws SaveToDatabaseException;
    List<MeldungDTO> getAllMeldungenOfAkte(Long akteId) throws EntityNotFoundException;
    List<MeldungDTO> getMeldungenOfAllAkten();
    MeldungOeffnenResponse meldungOeffnen(Long meldungId) throws EntityNotFoundException;
    String meldungAbbrechen(Long meldungId) throws SaveToDatabaseException;
    String meldungAbschliessen(Long meldungId) throws SaveToDatabaseException;
    List<MeldungDTO> getAllOpenMeldungenOfAkte(Long akteId) throws EntityNotFoundException;
    List<MeldungDTO> getAllOpenMeldungenOfAllAkten();
}