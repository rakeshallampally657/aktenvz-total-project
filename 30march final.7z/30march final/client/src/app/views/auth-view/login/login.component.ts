import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { Router } from "@angular/router";
import { UserService } from 'src/app/shared/services/user.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss'],
})
export class LoginComponent implements OnInit {
  constructor(private userS: UserService, private router: Router) {}

  ngOnInit(): void {}

  onSubmit = async (form: NgForm): Promise<void> => {
    if (form.invalid) {
      return;
    }
    await this.userS.login({
      benutzerNameOrEmail: form.value.benutzerNameOrEmail,
      password: form.value.password,
    });
    this.router.navigate(['/app/akten-verzeichnis'])
    form.reset();
  };
}
