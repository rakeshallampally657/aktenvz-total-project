import { Injectable, OnDestroy } from '@angular/core';
import {
  ActivatedRouteSnapshot,
  CanActivate,
  RouterStateSnapshot,
  UrlTree,
} from '@angular/router';
import { BehaviorSubject, Observable, Subscription } from 'rxjs';
import { UserService } from './user.service';

@Injectable({
  providedIn: 'root',
})
export class AuthGuardService implements CanActivate, OnDestroy {
  public isAdmin = new BehaviorSubject<boolean>(false);
  public exportGranted = new BehaviorSubject<boolean>(false);
  private userSub: Subscription;
  constructor(private userS: UserService) {
    this.userSub = this.userS.loggedInUser.subscribe((user) => {
      this.isAdmin.next(user?.rechte.includes(0) || false);
      this.exportGranted.next(
        user?.rechte.includes(0) || user?.rechte.includes(7) || false
      );
    });
  }

  canActivate(
    route: ActivatedRouteSnapshot,
    state: RouterStateSnapshot
  ):
    | boolean
    | UrlTree
    | Observable<boolean | UrlTree>
    | Promise<boolean | UrlTree> {
    return this.isAdmin;
  }

  ngOnDestroy(): void {
    this.userSub.unsubscribe();
  }
}
