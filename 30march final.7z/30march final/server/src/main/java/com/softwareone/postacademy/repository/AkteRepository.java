package com.softwareone.postacademy.repository;

import com.softwareone.postacademy.model.Akte;
import com.softwareone.postacademy.model.Nutzer;
import org.springframework.data.domain.Page;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;


import org.springframework.data.domain.Pageable;
import java.util.List;
import java.util.Optional;

public interface AkteRepository extends JpaRepository<Akte, Long> {

    @Query(value = "select max(d.neueHeftnummer) from #{#entityName} d ")
    Long findLastHeftnummer();

    @Query(value = "select d from #{#entityName} d where d.inPapierKorb=false")
    Page<Akte> findAllAkten(Pageable pageable);

    @Query(value = "select d from #{#entityName} d where d.inPapierKorb=false and d.akteId= :akteid")
    Optional<Akte> findAkteBasedOnId(Long akteid);

    Akte findByAkteId(Long akteId);
    List<Akte> findByNutzer(Nutzer nutzer);

    @Query(value = "select d from #{#entityName} d where d.inPapierKorb=true ")
    List<Akte> findAllAktenFromPapierKorb();

    @Query(value = "select d from #{#entityName} d where d.inPapierKorb=false and d.istAusgeliehen=true and d.akteId= :akteId")
    Optional <Akte> findAkteFromAusgeliehenAkten(Long akteId);

    @Query(value = "select d from #{#entityName} d where d.inPapierKorb=true and d.akteId= :akteid")
    Optional<Akte> findAkteFromPapierkorbByid(Long akteid);

    @Query(value = "SELECT DISTINCT a FROM Akte a LEFT JOIN a.allGrundstuecksInformationen g " +
            "WHERE ( :flurStueck is null or g.flurStueck LIKE %:flurStueck% ) and" +
            " (:heftnummer is null or a.neueHeftnummer=:heftnummer ) and" +
            "(:stadtBezirk is null or a.stadtBezirk=:stadtBezirk ) and" +
            "(:kennZiffer is null or a.kennZiffer=:kennZiffer ) and" +
            "(:freiText is null or a.sonstigeAnmerkungen LIKE %:freiText% or a.betreff LIKE %:freiText% or g.anmerkung LIKE %:freiText% ) and" +
            "(a.inPapierKorb = false ) and" +
            "(:flur is null or g.flur=:flur )")
    Page<Akte> findAkteByFiltering(
            @Param("heftnummer") Long heftnummer,
            @Param("flurStueck") String flurStueck,
            @Param("stadtBezirk") Long stadtBezirk,
            @Param("kennZiffer") Long kennZiffer,
            @Param("flur") Long flur,
            @Param("freiText") String freiText, Pageable pageable);
}