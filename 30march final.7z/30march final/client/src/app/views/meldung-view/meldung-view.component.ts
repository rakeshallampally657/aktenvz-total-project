import { Component, OnInit, OnDestroy } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Meldung } from 'src/app/interfaces/Meldung.interface';
import { AkteService } from 'src/app/shared/services/akte.service';

@Component({
  selector: 'app-meldung-view',
  templateUrl: './meldung-view.component.html',
  styleUrls: ['./meldung-view.component.scss'],
})
export class MeldungViewComponent implements OnInit, OnDestroy {
  meldung: Meldung = {
    gemeldetVon: '',
    gemeldetAm: new Date().toLocaleDateString('en-GB'),
    bereich: '',
    nachricht: '',
    zustand: 0,
    akte: {
      akteId: 0,
      stadtBezirk: 0,
      kennZiffer: 0,
      aktenBeginn: new Date().toLocaleDateString('en-GB'),
      letzteHeftnummer: 0,
      neueHeftnummer: 0,
      almosenKasten: false,
      betreff: '',
      sonstigeAnmerkungen: '',
      inPapierKorb: false,
      istAusgeliehen: false,
      allGrundstuecksInformationen: [],
    },
  };
  meldungId: number = 0;

  constructor(
    private akteS: AkteService,
    private route: ActivatedRoute,
    private router: Router
  ) {}

  ngOnInit(): void {
    this.init();
  }
  init = async (): Promise<void> => {
    this.meldungId = this.route.snapshot.params.meldungId;
    this.meldung = await this.akteS.openNotification(this.meldungId);
  };
  schliessen = async (): Promise<void> => {
    await this.akteS.closeNotification(this.meldungId);
  };
  abschliessen = async (): Promise<void> => {
    await this.akteS.finishNotification(this.meldungId);
    this.router.navigate(['/app/akten-meldungen']);
  };

  ngOnDestroy() {
    this.schliessen();
  }
}
