import { Component, OnInit } from '@angular/core';
import { GrundstuecksInformation } from 'src/app/interfaces/GrundstuecksInformation.interface';
import { Akte } from 'src/app/interfaces/Akte.interface';
import { RequestService } from 'src/app/shared/services/request.service';

@Component({
  selector: 'app-add-dummy-data-view',
  templateUrl: './add-dummy-data-view.component.html',
  styleUrls: ['./add-dummy-data-view.component.scss'],
})
export class AddDummyDataViewComponent implements OnInit {
  constructor(private requestS: RequestService) {
    const dummyAkten: Akte[] = [
      {
        akteId: 0,
        stadtBezirk: '21',
        kennZiffer: '31',
        aktenBeginn: new Date(),
        letzteHeftnummer: 41,
        neueHeftnummer: 42,
        almosenKasten: true,
        allGrundstuecksInformationen: [
          {
            grundstuecksInformationId: '',
            gemarkung: '43',
            flur: '34',
            flurStueck: '26/43',
            vertragsBeginn: new Date(2021, 6, 1),
            laufzeit: '15',
            vertragsNummer: '356/726',
            anmerkung: 'Kaufvertrag',
            isEditable: false,
          },
          {
            grundstuecksInformationId: '',
            gemarkung: '43',
            flur: '12',
            flurStueck: '56/78',
            vertragsBeginn: new Date(2022, 7, 1),
            laufzeit: '25',
            vertragsNummer: '452/87',
            anmerkung: 'Mietvertrag',
            isEditable: false,
          },
        ],
        betreff: 'Weitere Einträge kommen bald',
        sonstigeAnmerkungen: 'Baubeginn Juni 2022',
        letzteAenderung: '',
      },
      {
        akteId: 0,
        stadtBezirk: '23',
        kennZiffer: '32',
        aktenBeginn: new Date(),
        letzteHeftnummer: 43,
        neueHeftnummer: 44,
        almosenKasten: true,
        allGrundstuecksInformationen: [
          {
            grundstuecksInformationId: '',
            gemarkung: '43',
            flur: '34',
            flurStueck: '26/43',
            vertragsBeginn: new Date(2021, 6, 1),
            laufzeit: '15',
            vertragsNummer: '356/726',
            anmerkung: 'Kaufvertrag',
            isEditable: false,
          },
          {
            grundstuecksInformationId: '',
            gemarkung: '43',
            flur: '12',
            flurStueck: '56/78',
            vertragsBeginn: new Date(2022, 7, 1),
            laufzeit: '25',
            vertragsNummer: '452/87',
            anmerkung: 'Mietvertrag',
            isEditable: false,
          },
        ],
        betreff: 'Weitere Einträge kommen bald',
        sonstigeAnmerkungen: 'Baubeginn August 2022',
        letzteAenderung: '',
      },
    ];

    console.log(
      'add-dummy-data-view constructor triggered, dummyAkten:\n',
      dummyAkten
    );

    this.requestS.addAllItems(dummyAkten);
  }

  ngOnInit(): void {}
}
