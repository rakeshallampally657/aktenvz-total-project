package com.softwareone.postacademy.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.hibernate.envers.Audited;
import org.hibernate.envers.NotAudited;

import javax.persistence.*;
import java.time.Instant;
import java.util.List;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "AKTE")
@Audited
public class Akte {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "akte_id")
    private Long akteId;
    private Long stadtBezirk;
    private Long kennZiffer ;
    private Instant aktenBeginn;
    private Long letzteHeftnummer;
    private Long neueHeftnummer;
    private boolean almosenKasten;
    @Lob
    private String betreff;
    @Lob
    private String sonstigeAnmerkungen;
    private boolean inPapierKorb;
    @NotAudited
    private boolean istAusgeliehen;
    @OneToMany(cascade = CascadeType.ALL)
    @JoinColumn(name="AKTE_Fk")
    private List<GrundstuecksInformation> allGrundstuecksInformationen = null;
    @ManyToOne(fetch = FetchType.EAGER)
    private Nutzer nutzer;  //bearbeitet durch
}