import { ComponentFixture, TestBed } from '@angular/core/testing';

import { RequestResetLinkComponent } from './request-reset-link.component';

describe('RequestResetLinkComponent', () => {
  let component: RequestResetLinkComponent;
  let fixture: ComponentFixture<RequestResetLinkComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ RequestResetLinkComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(RequestResetLinkComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
