package com.softwareone.postacademy.dto;

import com.softwareone.postacademy.model.Akte;
import com.softwareone.postacademy.model.Meldung;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.Instant;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class MeldungOeffnenResponse{
    private String gemeldetVon;
    private Instant gemeldetAm;
    private String bereich;
    private String nachricht;
    private int zustand;
    private Akte akte;

    public MeldungOeffnenResponse(Meldung meldung){
        if(meldung.getGemeldetVon()!=null){
            this.gemeldetVon = meldung.getGemeldetVon().getBenutzerName();
        }
        this.gemeldetAm=meldung.getGemeldetAm();
        this.nachricht = meldung.getNachricht();
        this.akte= meldung.getAkte();
        this.bereich = meldung.getBereich();
        this.zustand = meldung.getZustand();
    }
}