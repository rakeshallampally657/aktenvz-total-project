package com.softwareone.postacademy.unit;

import com.softwareone.postacademy.repository.AkteRepository;
import com.softwareone.postacademy.repository.AufenthaltsortAenderungenRepository;
import com.softwareone.postacademy.repository.NutzerRepository;
import com.softwareone.postacademy.service.AufenthaltsortAenderungenServiceImpl;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.junit4.SpringRunner;

@RunWith(SpringRunner.class)
@WebMvcTest(value = AufenthaltsortAenderungenServiceImpl.class)
public class AufenthaltsortAenderungServiceUnitTest {


    @MockBean
    AufenthaltsortAenderungenRepository aufenthaltsortAenderungenRepository;
    @MockBean
    NutzerRepository nutzerRepository;
    @MockBean
    AkteRepository akteRepository;
    @Test
    public void borrowAnExistingAkteSuccessfulTest() throws Exception{
        System.out.println("test not implemented yet.");
    }
}
