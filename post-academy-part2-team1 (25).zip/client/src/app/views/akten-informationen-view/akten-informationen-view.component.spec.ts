import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AktenInformationenViewComponent } from './akten-informationen-view.component';

describe('AktenInformationenViewComponent', () => {
  let component: AktenInformationenViewComponent;
  let fixture: ComponentFixture<AktenInformationenViewComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AktenInformationenViewComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(AktenInformationenViewComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
