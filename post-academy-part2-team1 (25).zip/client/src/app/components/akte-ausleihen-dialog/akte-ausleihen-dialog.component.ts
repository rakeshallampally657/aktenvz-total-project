import { Component, Inject, OnInit } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { MatSelectChange } from '@angular/material/select';
import { AusleihenDialogData } from 'src/app/interfaces/AusleihenDialogData.interface';
import { User } from 'src/app/interfaces/user';

@Component({
  selector: 'app-akte-ausleihen-dialog',
  templateUrl: './akte-ausleihen-dialog.component.html',
  styleUrls: ['./akte-ausleihen-dialog.component.scss'],
})
export class AkteAusleihenDialogComponent implements OnInit {
  stadtBezirk!: string;

  kennZiffer!: string;

  heftnummer!: string;

  isThirdPerson: boolean = false;

  ausgeliehenVon!: User;
  loggedInUser!: User;
  userList: User[] = [];

  anmerkungAufenthaltsort: string = '';

  ausgeliehenAn: string = '';

  ausgeliehenAnEmail: string = '';

  rueckgabeDatum!: Date;

  constructor(
    public dialogRef: MatDialogRef<AkteAusleihenDialogComponent>,
    @Inject(MAT_DIALOG_DATA) public data: AusleihenDialogData
  ) {}

  ngOnInit(): void {
    this.init();
  }
  init = async (): Promise<void> => {
    this.stadtBezirk = this.data.stadtBezirk;
    this.kennZiffer = this.data.kennZiffer;
    this.heftnummer = this.data.heftnummer;
    this.userList = this.data.userList;
    /* console.log('loggedInUser: ', this.data.loggedInUser);
    console.log('userlist[0]: ', this.data.userList[0]); */
    const loggedInUser = this.data.userList.filter(
      (user) => user.nutzerId === this.data.loggedInUser.nutzerId
    )[0];
    this.ausgeliehenVon = loggedInUser;
    this.ausgeliehenAn = loggedInUser.benutzerName;

    const date = new Date(new Date());
    date.setDate(date.getDate() + 15);
    this.rueckgabeDatum = date;
  };
  adjustAusgeliehenAnEmail(event: MatSelectChange) {
    this.ausgeliehenAnEmail = event.value.email;
  }

  adjustThirdPerson() {
    this.ausgeliehenAn = '';
    this.ausgeliehenAnEmail = '';
  }

  adjustFirstPerson() {
    this.ausgeliehenAn = this.ausgeliehenVon.benutzerName;
    this.ausgeliehenAnEmail = this.ausgeliehenVon.email;
    /* console.log('adjustFirstPerson fired:\n', this.ausgeliehenAn, this.ausgeliehenAnEmail); */
  }

  closeDialog(res: number) {
    if (res)
      this.dialogRef.close({
        res,
        ausleihDetails: {
          ausgeliehenVon: this.ausgeliehenVon.benutzerName,
          ausgeliehenAn: this.ausgeliehenAn,
          ausgeliehenAnEmail: this.ausgeliehenAnEmail,
          rueckgabeDatum: this.rueckgabeDatum,
          anmerkungAufenthaltsort: this.anmerkungAufenthaltsort,
        },
      });
  }
}
