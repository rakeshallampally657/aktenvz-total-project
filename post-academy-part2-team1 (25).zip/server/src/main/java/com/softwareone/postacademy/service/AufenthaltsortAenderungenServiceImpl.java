package com.softwareone.postacademy.service;

import com.softwareone.postacademy.dto.AkteAusleihenDTO;
import com.softwareone.postacademy.dto.AufenthaltsortDTO;
import com.softwareone.postacademy.dto.AusgelieheneAkteDTO;
import com.softwareone.postacademy.model.Akte;
import com.softwareone.postacademy.model.AufenthaltsortAenderungen;
import com.softwareone.postacademy.model.Nutzer;
import com.softwareone.postacademy.repository.AkteRepository;
import com.softwareone.postacademy.repository.AufenthaltsortAenderungenRepository;
import com.softwareone.postacademy.repository.NutzerRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;

import javax.persistence.EntityNotFoundException;
import java.security.Principal;
import java.time.Instant;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@Service
public class AufenthaltsortAenderungenServiceImpl implements AufenthaltsortAenderungenService {

    @Autowired
    private AufenthaltsortAenderungenRepository aufenthaltsortAenderungenRepository;
    @Autowired
    private NutzerRepository nutzerRepository;
    @Autowired
    private AkteRepository akteRepository;

    private AufenthaltsortAenderungen convertDTOtoModel(AkteAusleihenDTO akteAusleihenDTO) {
        AufenthaltsortAenderungen aufenthaltsortAenderungen = new AufenthaltsortAenderungen();
        aufenthaltsortAenderungen.setDatum(Instant.now());
        aufenthaltsortAenderungen.setIstAusgeliehen(true);
        aufenthaltsortAenderungen.setAnmerkungAufenthaltsort(
                akteAusleihenDTO.getAnmerkungAufenthaltsort());
        aufenthaltsortAenderungen.setRueckgabeDatum(akteAusleihenDTO.getRueckgabeDatum());
        aufenthaltsortAenderungen.setAusgeliehenAn(akteAusleihenDTO.getAusgeliehenAn());
        aufenthaltsortAenderungen.setAusgeliehenAnEmail(akteAusleihenDTO.getAusgeliehenAnEmail());
        Principal principal = SecurityContextHolder.getContext().getAuthentication();
        Optional<Nutzer> nutzer = nutzerRepository.findByBenutzerNameAndDeleted(principal.getName(), false);
        aufenthaltsortAenderungen.setNutzer(nutzer.get());
        return aufenthaltsortAenderungen;
    }

    private AusgelieheneAkteDTO convertModelToDTO(AufenthaltsortAenderungen aufenthaltsortAenderungen) {
        return new AusgelieheneAkteDTO(aufenthaltsortAenderungen);
    }

    @Override
    public AusgelieheneAkteDTO ausleihenAkte(AkteAusleihenDTO akteAusleihenDTO, Long akteId)
            throws EntityNotFoundException {
        AufenthaltsortAenderungen aufenthaltsortAenderungen = convertDTOtoModel(akteAusleihenDTO);
        aufenthaltsortAenderungen.setIstAusgeliehen(true);// setting it to true in aufenthalsortanderung entity

        Optional<Akte> possibleAkte = akteRepository.findAkteBasedOnId(akteId);
        if (possibleAkte.isPresent() && !possibleAkte.get().isIstAusgeliehen()) {
            Akte akte = possibleAkte.get();
            aufenthaltsortAenderungen.setAkte(akte);
            akte.setIstAusgeliehen(true);
            akteRepository.save(akte);
        } else {
            throw new EntityNotFoundException("AKTE ID TO BE LENT NOT FOUND EXCEPTION :::" + akteId);
        }
        return convertModelToDTO(aufenthaltsortAenderungenRepository.save(aufenthaltsortAenderungen));
    }

    @Override
    public List<AufenthaltsortDTO> getAllAufenthaltsortenOfAkte(Long akteId) {
        List<AufenthaltsortAenderungen> aufenthaltsortAenderungenList = aufenthaltsortAenderungenRepository.findAllAufenthaltsortenOfAkte(akteId);
        List<AufenthaltsortDTO> aufenthaltsortDTOList = new ArrayList<>();

        for (AufenthaltsortAenderungen aufenthaltsortAenderungen : aufenthaltsortAenderungenList) {
            aufenthaltsortDTOList.add(new AufenthaltsortDTO(aufenthaltsortAenderungen));
        }
        return aufenthaltsortDTOList;
    }

    @Override
    public List<AusgelieheneAkteDTO> getLatestAufenthaltsortOfAllBorrowedAkten() {

        List<AufenthaltsortAenderungen> aufenthaltsortAenderungenList = aufenthaltsortAenderungenRepository.findAllLatestAufenthaltsortOfEachAkte();
        List<AusgelieheneAkteDTO> aufenthaltsortAenderungenDTOList = new ArrayList<>();

        for (AufenthaltsortAenderungen aufenthaltsortAenderungen : aufenthaltsortAenderungenList) {
            aufenthaltsortAenderungenDTOList.add(convertModelToDTO(aufenthaltsortAenderungen));
        }
        return aufenthaltsortAenderungenDTOList;
    }

    @Override
    public List<Long> zurueckgebenAkten(List<Long> akteIdList){
        List<Long> akteIdNotFoundList = new ArrayList<>();
        for (Long akteId : akteIdList) {
            Optional<Akte> possibleAkte = akteRepository.findAkteFromAusgeliehenAkten(akteId);
            if (possibleAkte.isPresent()) {
                Akte akte = possibleAkte.get();
                akte.setIstAusgeliehen(false);// setting it to false in akte entity
                AufenthaltsortAenderungen aufenthaltsortAenderungen = new AufenthaltsortAenderungen();
                aufenthaltsortAenderungen.setIstAusgeliehen(false);
                aufenthaltsortAenderungen.setAusgeliehenAn("Archiv");
                aufenthaltsortAenderungen.setDatum(Instant.now());
                aufenthaltsortAenderungen.setAkte(akte);
                akteRepository.save(akte);
                aufenthaltsortAenderungenRepository.save(aufenthaltsortAenderungen);
            } else {
                akteIdNotFoundList.add(akteId);
            }
        }
        if(akteIdNotFoundList.isEmpty()){
            return null;
        }
        return akteIdNotFoundList;
    }
}