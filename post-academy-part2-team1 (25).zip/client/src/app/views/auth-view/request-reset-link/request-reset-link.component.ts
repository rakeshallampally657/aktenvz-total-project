import { Component, OnInit } from '@angular/core';
import { NgForm } from "@angular/forms";
import { UserService } from "src/app/shared/services/user.service";

@Component({
  selector: 'app-request-reset-link',
  templateUrl: './request-reset-link.component.html',
  styleUrls: ['./request-reset-link.component.scss']
})
export class RequestResetLinkComponent implements OnInit {

  constructor(private userS: UserService) { }

  ngOnInit(): void {
  }

  onSubmit = async (form: NgForm): Promise<void> => {
    if (form.invalid) {
      return;
    }
    await this.userS.getLink(
      form.value.email
    );
    form.reset();
  };

}
