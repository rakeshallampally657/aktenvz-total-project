export interface SuchFelder {
  flur?: string;
  flurstueck?: string;
  stadtbezirk?: string;
  heftnummer?: string;
  kennziffer?: string;
  freitext?: string;
}
