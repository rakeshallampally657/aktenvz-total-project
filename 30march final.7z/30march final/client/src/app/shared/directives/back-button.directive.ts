/*
source:
https://nils-mehlhorn.de/posts/angular-navigate-back-previous-page
*/

import { Directive, HostListener } from '@angular/core';
import { NavigationService } from '../services/navigation.service';

@Directive({
  selector: '[appBackButton]',
})
export class BackButtonDirective {
  constructor(private navigationS: NavigationService) {}

  @HostListener('click')
  onClick(): void {
    this.navigationS.back();
  }
}
