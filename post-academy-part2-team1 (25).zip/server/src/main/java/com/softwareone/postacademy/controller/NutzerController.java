package com.softwareone.postacademy.controller;

import com.softwareone.postacademy.dto.*;
import com.softwareone.postacademy.model.EROLE;
import com.softwareone.postacademy.service.NutzerService;
import com.softwareone.postacademy.service.UserDetailsImpl;
import com.softwareone.postacademy.util.JwtUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.*;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.util.WebUtils;

import javax.persistence.EntityNotFoundException;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.net.URI;
import java.util.*;

@RestController
@CrossOrigin(origins = "http://localhost:4200", allowCredentials = "true")
@RequestMapping("/api")
public class NutzerController {

    @Autowired
    private NutzerService nutzerService;

    @Autowired
    private AuthenticationManager authenticationManager;

    @Autowired
    private JwtUtils jwtUtils;

    @Value("${app.jwtCookieName}")
    private String jwtCookie;

    @GetMapping(value = "/nutzer", produces = {MediaType.APPLICATION_JSON_VALUE, MediaType.APPLICATION_XML_VALUE})
    public ResponseEntity<ResponseDTO> fetchAllCurrentUsers() {
        Map<String, Object> res = new HashMap<>();
        res.put("nutzerList", nutzerService.getAllCurrentNutzer());
        return new ResponseEntity<>(new ResponseDTO("", res), HttpStatus.OK); //200 for sucess
    }

    @GetMapping(value = "/nutzer/all", produces = {MediaType.APPLICATION_JSON_VALUE, MediaType.APPLICATION_XML_VALUE})
    public ResponseEntity<ResponseDTO> fetchAllUsers() {
        Map<String, Object> res = new HashMap<>();
        res.put("nutzerList", nutzerService.getAllNutzer());
        return new ResponseEntity<>(new ResponseDTO("", res), HttpStatus.OK); //200 for sucess
    }

    @GetMapping(value = "/nutzer/{nutzerId}", produces = {MediaType.APPLICATION_JSON_VALUE, MediaType.APPLICATION_XML_VALUE})
    public ResponseEntity<ResponseDTO> fetchNutzerById(@PathVariable("nutzerId") Long nutzerId) {
        NutzerDTO nutzerObtained = nutzerService.fetchNutzerById(nutzerId);
        return new ResponseEntity<>(new ResponseDTO("", nutzerObtained), HttpStatus.OK); //200 for sucess
    }

    @PutMapping("/nutzer")
    public ResponseEntity<ResponseDTO> modifyNutzer(@RequestBody NutzerDTO nutzerDTO) {
        NutzerDTO nutzerDTOObtained = nutzerService.updateNutzer(nutzerDTO);
        return new ResponseEntity<>(new ResponseDTO("Nutzer updated", nutzerDTOObtained),
                HttpStatus.OK); //201 content created successfully
    }

    @PostMapping("/nutzer")
    public ResponseEntity<ResponseDTO> registerUser(@RequestBody NutzerDTO nutzerDTO) {
        NutzerDTO nutzerDTOObtained = nutzerService.addNutzer(nutzerDTO);
        return ResponseEntity.created(URI.create("/nutzer/" + nutzerDTOObtained.getNutzerId()))
                .body(new ResponseDTO("", null)); //201 content created successfully
    }

    @PostMapping("/nutzer/byAdmin")
    public ResponseEntity<ResponseDTO> adminCreatesUser(@RequestBody NutzerDTO nutzerDTO) {
        NutzerDTO nutzerDTOObtained = nutzerService.addNutzer(nutzerDTO);
        return ResponseEntity.created(URI.create("/nutzer/" + nutzerDTOObtained.getNutzerId()))
                .body(new ResponseDTO("", null)); //201 content created successfully
    }


    @PostMapping("/nutzer/login")
    public ResponseEntity<ResponseDTO> authenticateUser(@RequestBody LoginDTO loginDTO) {
        Authentication authentication = authenticationManager
                .authenticate(
                        new UsernamePasswordAuthenticationToken(
                                loginDTO.getBenutzerNameOrEmail(),
                                loginDTO.getPassword()
                        )
                );
        SecurityContextHolder.getContext().setAuthentication(authentication);
        UserDetailsImpl userDetails = (UserDetailsImpl) authentication.getPrincipal();
        if (userDetails.isDeleted()) {
            return new ResponseEntity<>(new ResponseDTO("", null), HttpStatus.FORBIDDEN);
        }
        ResponseCookie jwtCookie = jwtUtils.generateJwtCookie(userDetails);
        Set<String> rechte = new HashSet<>();
        for (GrantedAuthority recht : userDetails.getAuthorities()) {
            String index = EROLE.valueOf(recht.getAuthority()).index();
            rechte.add(index);
        }
        Map resData = new HashMap();
        resData.put("user",
                new NutzerDTO(
                        userDetails.getId(),
                        userDetails.getVorName(),
                        userDetails.getName(),
                        userDetails.getUsername(),
                        userDetails.getEmail(),
                        null,
                        userDetails.isDeleted(),
                        rechte
                )
        );
        resData.put("jwtDurationInMs", jwtCookie.getMaxAge().toMillis());

        return ResponseEntity.ok()
                .header(HttpHeaders.SET_COOKIE, jwtCookie.toString())
                .body(new ResponseDTO("data includes user and jwt duration", resData));
    }

    @PostMapping(value = "/nutzer/logout")
    public ResponseEntity<ResponseDTO> logoutUser(HttpServletRequest request, HttpServletResponse response) {
        Cookie cookie = WebUtils.getCookie(request, jwtCookie);
        cookie.setValue(null);
        cookie.setMaxAge(0);
        cookie.setHttpOnly(true);
        cookie.setSecure(true);
        cookie.setPath("/api");
        response.addCookie(cookie);
        return new ResponseEntity<>(new ResponseDTO("User logged out", null), HttpStatus.OK); //200 for sucess
    }

    @PostMapping(value = "/nutzer/resetPassword")
    public ResponseEntity<ResponseDTO> resetPassword(@RequestBody String email) {
        String link = nutzerService.resetPassword(email);
        String message = "user was found, password reset link is in data";
        return ResponseEntity.ok().body(new ResponseDTO(message, link));
    }

    @PutMapping(value = "/nutzer/password")
    public ResponseEntity<ResponseDTO> createNewPassword(@RequestBody NewPasswortDTO newPasswordDTO) {
        nutzerService.createNewPassword(newPasswordDTO);
        return ResponseEntity.ok().body(new ResponseDTO());
    }

    @GetMapping(value = "/nutzer/fromCookie", produces = {MediaType.APPLICATION_JSON_VALUE, MediaType.APPLICATION_XML_VALUE})
    public ResponseEntity<ResponseDTO> getUserFromCookie(HttpServletRequest req) {
        String nutzerName = SecurityContextHolder.getContext().getAuthentication().getName();
        NutzerDTO nutzerObtained = nutzerService.fetchNutzerByName(nutzerName);

        Map resData = new HashMap();
        resData.put("jwtDurationInMs", jwtUtils.getJwtDurationInMs(req));
        resData.put("user", nutzerObtained);
        return ResponseEntity.ok().body(new ResponseDTO("data includes user and jwt duration", resData));
    }

    @DeleteMapping(value = "/nutzer", consumes = {MediaType.APPLICATION_JSON_VALUE})
    public ResponseEntity<ResponseDTO> deleteUser(@RequestBody List<Long> nutzerIdList) {
        nutzerService.deleteMultipleNutzer(nutzerIdList);
        return new ResponseEntity<>(new ResponseDTO("", null), HttpStatus.OK);
    }

    @PatchMapping(value = "/nutzer/archive", consumes = {MediaType.APPLICATION_JSON_VALUE})
    public ResponseEntity<ResponseDTO> archiveUser(@RequestBody List<Long> nutzerIdList) {
        nutzerService.archiveMultipleNutzer(nutzerIdList);
        return ResponseEntity
                .ok()
                .body(
                        new ResponseDTO(
                                "the users with the following IDs have been archived successfully: " + nutzerIdList,
                                null));
    }

    @PatchMapping(value = "/nutzer/unarchive", consumes = {MediaType.APPLICATION_JSON_VALUE})
    public ResponseEntity<ResponseDTO> unarchiveUser(@RequestBody List<Long> nutzerIdList) {
        nutzerService.unarchiveMultipleNutzer(nutzerIdList);
        return ResponseEntity
                .ok()
                .body(
                        new ResponseDTO(
                                "the users with the following IDs have been unarchived successfully: "
                                        + nutzerIdList,
                                null
                        )
                );
    }

    @PatchMapping(value = "/nutzer/refresh")
    public ResponseEntity<ResponseDTO> refresh(HttpServletRequest request) {
        UserDetailsImpl userDetails =
                (UserDetailsImpl) SecurityContextHolder
                        .getContext()
                        .getAuthentication()
                        .getPrincipal();
        ResponseCookie jwtCookie = jwtUtils.generateJwtCookie(userDetails);
        Map resData = new HashMap();
        resData.put("jwtDurationInMs", jwtCookie.getMaxAge().toMillis());
        return ResponseEntity.ok()
                .header(HttpHeaders.SET_COOKIE, jwtCookie.toString())
                .body(new ResponseDTO("user refreshed", resData));
    }
}