import { Injectable } from '@angular/core';
import {
  HttpClient,
  HttpErrorResponse,
  HttpHeaders,
  HttpParams,
} from '@angular/common/http';
import { Observable, throwError } from 'rxjs';
import { Akte } from 'src/app/interfaces/Akte.interface';
import { catchError, map, tap } from 'rxjs/operators';
import { MatSnackBar } from '@angular/material/snack-bar';
import { Response } from 'src/app/interfaces/Response.interface';
import { SuchFelder } from 'src/app/interfaces/SuchFelder.interface';
import { environment } from 'src/environments/environment';
import { PaginatorDetails } from 'src/app/interfaces/PaginatorDetails.interface';
import { AusleihDetails } from 'src/app/interfaces/AusleihDetails.interface';
import { Aenderung } from 'src/app/interfaces/Aenderung.interface';
import { SortDirection } from '@angular/material/sort';
import { GrundstuecksInformation } from 'src/app/interfaces/GrundstuecksInformation.interface';
import { MeldungShort } from 'src/app/interfaces/MeldungShort.interface';
import { MapperService } from './mapper.service';
import { AusgelieheneAkte } from 'src/app/interfaces/AusgelieheneAkte.interface';
import { GeloeschteAkte } from 'src/app/interfaces/geloeschte-akte';

@Injectable({
  providedIn: 'root',
})
export class RequestService {
  private baseUrl = environment.baseUrl;
  private httpOptions = {
    headers: new HttpHeaders({
      'Content-Type': 'application/json',
    }),
    body: {},
    params: {},
    withCredentials: true,
  };
  constructor(
    private http: HttpClient,
    private snackBar: MatSnackBar,
    private mapperS: MapperService
  ) {}
  private handleError = (e: HttpErrorResponse) => {
    if (e.error instanceof ErrorEvent) {
      /* ErrorEvent: client-side / network */
      console.error('client or network error, message:\n', e.error.message);
    } else {
      console.error('backend error, status code:\n', e.status);
      console.error('full error response:\n', e);
    }
    this.snackBar.open('Es ist ein Fehler aufgetreten.', 'Schließen', {
      panelClass: 'error-message',
      duration: 3000,
    });
    // return an observable with a user-facing error message
    return throwError('Something bad happened; please try again later.');
  };

  /* GET */
  getAllItems(url: string): Observable<Response> {
    return this.http.get<Response>(this.baseUrl + url, this.httpOptions).pipe(
      catchError(this.handleError),
      map(this.mapperS.convertInstantToDate)
    );
  }
  getFilteredItems(
    suchFelder: SuchFelder,
    sortColumn: string,
    sortDirection: SortDirection,
    pageIndex: number,
    pageSize: number
  ): Observable<{ aktenList: Akte[]; paginator: PaginatorDetails }> {
    return this.http
      .get<Response>(this.baseUrl + 'akte/filterByFields', {
        params: new HttpParams({
          fromObject: {
            ...suchFelder,
            sortColumn,
            sortDirection,
            pageno: pageIndex,
            pagesize: pageSize,
          },
        }),
        withCredentials: true,
      })
      .pipe(
        catchError(this.handleError),
        map((res) => res.data)
      );
  }
  getAenderungen(akteId: number): Observable<Aenderung[]> {
    return this.http
      .get<Response>(this.baseUrl + 'akte/' + akteId + '/historie')
      .pipe(
        catchError(this.handleError),
        /* tap(res => console.log('res from getAenderungn:\n', res)), */
        map((res) => res.data)
      );
  }
  getUserFromCookie(): Observable<Response> {
    return this.http.get<Response>(this.baseUrl + 'nutzer/fromCookie', {
      withCredentials: true,
    });
  }

  /* POST */
  post(
    url: string,
    body?: any,
    options?: any,
    message?: string
  ): Observable<Response> {
    const opts = {
      headers: this.httpOptions.headers,
      body: options?.body || {},
      params: options?.params || {},
      withCredentials: true,
    };
    return this.http.post<Response>(this.baseUrl + url, body, opts).pipe(
      catchError(this.handleError),
      tap(() => {
        if (message)
          this.snackBar.open(message, 'Schließen', { duration: 3000 });
      })
    );
  }
  addAllItems(allItems: Akte[]): void {
    this.http
      .post<Response>(this.baseUrl + 'akte/all', allItems, this.httpOptions)
      .pipe(catchError(this.handleError))
      .subscribe((res) => {
        console.log('addAllItems service executed, res:\n', res);
      });
  }
  akteAusleihen(akteId: number, body: AusleihDetails): Observable<Response> {
    /* console.log('akteId:\n', akteId);
    console.log('body:AusleihDetails:\n', body); */
    return this.http
      .post<Response>(
        this.baseUrl + 'akte/' + akteId + '/ausleihen',
        body,
        this.httpOptions
      )
      .pipe(catchError(this.handleError));
  }

  /* PUT */
  put(url: string, body: any, message?: string): Observable<Response> {
    if (body.allGrundstuecksInformationen) {
      body.allGrundstuecksInformationen.forEach(
        (gsi: GrundstuecksInformation) => {
          gsi.vertragsBeginn = this.mapperS.convertStringToDate(
            gsi.vertragsBeginn
          );
        }
      );
    }
    return this.http
      .put<Response>(this.baseUrl + url, body, this.httpOptions)
      .pipe(
        catchError(this.handleError),
        tap(() => {
          if (message)
            this.snackBar.open(message, 'Schließen', { duration: 3000 });
        })
      );
  }

  /* PATCH */
  patch(url: string, body?: any, message?: string): Observable<Response> {
    return this.http
      .patch<Response>(this.baseUrl + url, body, this.httpOptions)
      .pipe(
        catchError(this.handleError),
        tap(() => {
          if (message)
            this.snackBar.open(message, 'Schließen', { duration: 3000 });
        }),
        map(this.mapperS.convertInstantToDate)
      );
  }

  /* DELETE */
  deleteList(url: string, body?: any, message?: string): Observable<Response> {
    this.httpOptions.body = body;
    return this.http
      .delete<Response>(this.baseUrl + url, this.httpOptions)
      .pipe(
        catchError(this.handleError),
        tap(() => {
          if (message)
            this.snackBar.open(message, 'Schließen', { duration: 3000 });
        })
      );
  }
}
