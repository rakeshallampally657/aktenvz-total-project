package com.softwareone.postacademy.repository;

import com.softwareone.postacademy.model.AufenthaltsortAenderungen;
import com.softwareone.postacademy.model.Nutzer;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.List;

public interface AufenthaltsortAenderungenRepository extends JpaRepository<AufenthaltsortAenderungen,Long> {

    @Query(value = "select d from #{#entityName} d where d.akte.akteId=?1 order by d.datum desc ")
    List<AufenthaltsortAenderungen> findAllAufenthaltsortenOfAkte(Long akteId);

    @Query(value = "select * from aufenthaltsort_aenderungen  where (akte_fk,datum,ist_ausgeliehen) in\n" +
            " (select akte_fk, max(datum),ist_ausgeliehen from aufenthaltsort_aenderungen  group by akte_fk)",
            nativeQuery = true)
    List<AufenthaltsortAenderungen> findAllLatestAufenthaltsortOfEachAkte();

    List<AufenthaltsortAenderungen> findByNutzer(Nutzer nutzer);
}
