import { Injectable } from '@angular/core';
import { MatPaginatorIntl } from '@angular/material/paginator';
import { Subject } from 'rxjs';

@Injectable({
  providedIn: 'root',
})
export class CustomPaginatorIntl implements MatPaginatorIntl {
  changes = new Subject<void>();

  // For internationalization, the `$localize` function from
  // the `@angular/localize` package can be used.
  /* firstPageLabel = $localize`First page`; */
  firstPageLabel = 'Erste Seite';
  /*  itemsPerPageLabel = $localize`Items per page:`; */
  itemsPerPageLabel = 'Einträge pro Seite:';
  /* lastPageLabel = $localize`Last page`; */
  lastPageLabel = 'Letzte Seite';

  // You can set labels to an arbitrary string too, or dynamically compute
  // it through other third-party internationalization libraries.
  /* nextPageLabel = 'Next page'; */
  nextPageLabel = 'Weiter';
  /* previousPageLabel = 'Previous page'; */
  previousPageLabel = 'Zurück';

  getRangeLabel(page: number, pageSize: number, length: number): string {
    if (length === 0) {
      return 'Eintrag 0 von 0';
    }
    /* const amountPages = Math.ceil(length / pageSize); */
    /* return `Seite ${page + 1} von ${amountPages}`; */
    return `Eintrag ${page * pageSize + 1} - ${Math.min((page + 1) * pageSize, length)} von ${length}`;
  }
  constructor() {}
}
