import { ComponentFixture, TestBed } from '@angular/core/testing';

import { MeldungVerfassenDialogComponent } from './meldung-verfassen-dialog.component';

describe('MeldungVerfassenDialogComponent', () => {
  let component: MeldungVerfassenDialogComponent;
  let fixture: ComponentFixture<MeldungVerfassenDialogComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ MeldungVerfassenDialogComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(MeldungVerfassenDialogComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
