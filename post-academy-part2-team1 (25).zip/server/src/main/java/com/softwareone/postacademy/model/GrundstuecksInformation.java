package com.softwareone.postacademy.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.hibernate.envers.Audited;

import javax.persistence.*;
import java.time.Instant;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Audited
public class GrundstuecksInformation {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long grundStueckId;
    private Long gemarkung;
    private Long flur;
    private String flurStueck;
    private Instant vertragsBeginn;
    private Long laufzeit;
    private String vertragsNummer;
    @Lob
    private String anmerkung;
}