import { Injectable } from '@angular/core';
import { BehaviorSubject, Observable } from 'rxjs';

@Injectable({
  providedIn: 'root',
})
export class LoaderService {
  private _counter = 0;
  private _isLoading$ = new BehaviorSubject<boolean>(false);
  constructor() {}

  getIsLoading(): Observable<boolean> {
    return this._isLoading$.asObservable();
  }
  startLoading(): void {
    if (++this._counter === 1) {
      this._isLoading$.next(true);
    }
  }
  stopLoading(): void {
    if (this._counter === 0 || --this._counter === 0) {
      this._isLoading$.next(false);
    }
  }
  resetLoader():void {
    this._counter = 0;
    this._isLoading$.next(false);
  }
}
