package com.softwareone.postacademy.runners;

import com.softwareone.postacademy.model.EROLE;
import com.softwareone.postacademy.model.Nutzer;
import com.softwareone.postacademy.repository.NutzerRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Component;

import java.util.*;

@Component
public class DataInitialise implements CommandLineRunner {
    @Autowired
    private NutzerRepository nutzerRepository;
    @Autowired
    private BCryptPasswordEncoder passwordEncoder;

    @Override
    public void run(String... args) throws Exception {
        Nutzer admin1 = new Nutzer();
        admin1.setVorName("admin");
        admin1.setBenutzerName("admin");
        admin1.setEmail("admin@gmail.com");
        admin1.setPassword(passwordEncoder.encode("admin"));
        Set<EROLE> rechte= new HashSet<>();
        rechte.add(EROLE.ADMIN);
        rechte.add(EROLE.AKTE_MELDUNGEN_VERFASSEN);
        rechte.add(EROLE.AKTE_DRUCKEN);
        admin1.setRechte(rechte);
        admin1.setDeleted(false);

        Nutzer geloeschterNutzer = new Nutzer();
        geloeschterNutzer.setVorName("geloeschter");
        geloeschterNutzer.setName("Nutzer");
        geloeschterNutzer.setBenutzerName("geloeschterNutzer");
        geloeschterNutzer.setEmail("geloeschterNutzer@swo.com");
        geloeschterNutzer.setPassword(passwordEncoder.encode("123"));
        Set<EROLE> keineRechte= new HashSet<>();
        geloeschterNutzer.setRechte(keineRechte);
        geloeschterNutzer.setDeleted(true);

        List<Nutzer> nutzerList= new ArrayList<>(Arrays.asList(admin1, geloeschterNutzer));

        for (Nutzer nutzer:nutzerList) {
            if(!nutzerRepository.existsByEmail(nutzer.getEmail())){
                nutzerRepository.save(nutzer);
            }
        }
    }
}