package com.softwareone.postacademy.service;

public interface EmailService {
    void sendSimpleMessage(String to, String subject, String name, String link);
}
