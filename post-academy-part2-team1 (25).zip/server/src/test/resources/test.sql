insert into AKTE(  stadt_bezirk,kenn_ziffer,akten_beginn,letzte_heftnummer,
                 neue_heftnummer,almosen_kasten,betreff,in_papier_korb,sonstige_anmerkungen,ist_ausgeliehen) values (1,11,'2020-01-07',0,1,
                                                                                   true,'first akten',false,'Detailed info of' ||
                                                                                                      ' 1st akten',false );
insert into AKTE(  stadt_bezirk,kenn_ziffer,akten_beginn,letzte_heftnummer,
                   neue_heftnummer,almosen_kasten,betreff,in_papier_korb,sonstige_anmerkungen,ist_ausgeliehen) values (2,12,'2015-01-09',1,2,
                                                                                       true,'second akten',false,'Detailed info of' ||
                                                                                                          ' 2nd akten',false );
insert into AKTE(  stadt_bezirk,kenn_ziffer,akten_beginn,almosen_kasten,betreff,in_papier_korb,sonstige_anmerkungen,ist_ausgeliehen) values (3,13,'2015-01-09',
                                                                                                       false ,'akten',true,'Detailed info of' ||
                                                                                                                                 '  akten',false );
insert into AKTE(  stadt_bezirk,kenn_ziffer,akten_beginn,almosen_kasten,betreff,in_papier_korb,sonstige_anmerkungen,ist_ausgeliehen) values (4,14,'2015-01-09',
                                                                                                       false ,'akten',true,'Detailed info of' ||
                                                                                                                                 '  akten',false );

insert into AKTE(  stadt_bezirk,kenn_ziffer,akten_beginn,almosen_kasten,betreff,in_papier_korb,sonstige_anmerkungen,ist_ausgeliehen) values (5,15,'2015-01-09',
                                                                                                                             false ,'akten',true,'Detailed info of' ||
                                                                                                                                                 '  akten',false );
insert into AKTE(  stadt_bezirk,kenn_ziffer,akten_beginn,almosen_kasten,betreff,in_papier_korb,sonstige_anmerkungen,ist_ausgeliehen) values (6,16,'2015-01-09',
                                                                                                                             false ,'akten',true,'Detailed info of' ||'  akten',false );

insert into AKTE(  stadt_bezirk,kenn_ziffer,akten_beginn,almosen_kasten,betreff,in_papier_korb,sonstige_anmerkungen,ist_ausgeliehen) values (7,17,'2015-01-09',
                                                                                                                             false ,'akten',false,'Detailed info of' ||'  akten',false );