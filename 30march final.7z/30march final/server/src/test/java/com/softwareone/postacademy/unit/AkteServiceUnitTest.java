//package com.softwareone.postacademy.unit;
//
//import com.softwareone.postacademy.dto.AkteDTO;
//import com.softwareone.postacademy.dto.AkteResponse;
//import com.softwareone.postacademy.dto.Paginator;
//import com.softwareone.postacademy.model.Akte;
//import com.softwareone.postacademy.model.Nutzer;
//import com.softwareone.postacademy.repository.*;
//import com.softwareone.postacademy.service.AkteService;
//import com.softwareone.postacademy.service.AkteServiceImpl;
//import org.junit.jupiter.api.Assertions;
//import org.junit.Test;
//import org.junit.runner.RunWith;
//import org.mockito.Mockito;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
//import org.springframework.boot.test.mock.mockito.MockBean;
//import org.springframework.data.domain.*;
//import org.springframework.test.context.junit4.SpringRunner;
//import org.springframework.test.web.servlet.MockMvc;
//
//import java.util.*;
//
//
//@RunWith(SpringRunner.class)
//@WebMvcTest(value = AkteServiceImpl.class)
//public class AkteServiceUnitTest {
//
//    @Autowired
//    private MockMvc mockMvc;
//    @Autowired
//    private AkteService akteService;
//
//    @MockBean
//    private AkteRepository akteRepo;
//
//    @MockBean
//    private AufenthaltsortAenderungenRepository aufenthaltsortAenderungenRepository;
//
//
//    @MockBean
//    private AenderungRepository aenderungRepository;
//
//    @MockBean
//    private NutzerRepository nutzerRepository;
//
//    @MockBean
//    private MeldungRepository meldungRepository;
//
//
//
//
//    @Test
//    public void delete5AktenPermanently2Successful3Fail() throws Exception {
//        List<Long> aktenIds = new ArrayList<>();
//        aktenIds.add(1L);
//        aktenIds.add(2L);
//        aktenIds.add(3L);
//        aktenIds.add(4L);
//        aktenIds.add(5L);
//
//        Akte akte1= new Akte(1L,2L,11L,new Date(2020-1-7),
//                0L,1L,false,"first akte", "other docs",true,false, null);
//
//        Akte akte4= new Akte(4L,3L,12L,new Date(2020-1-7),
//                1L,2L,false,"second akte", "other docs", true,false, null);
//
//        Mockito.when(akteRepo.findAkteFromPapierkorbByid(1L)).thenReturn(Optional.of(akte1));
//        Mockito.when(akteRepo.findAkteFromPapierkorbByid(2L)).thenReturn(Optional.ofNullable(null));
//        Mockito.when(akteRepo.findAkteFromPapierkorbByid(3L)).thenReturn(Optional.ofNullable(null));
//        Mockito.when(akteRepo.findAkteFromPapierkorbByid(4L)).thenReturn(Optional.of(akte4));
//        Mockito.when(akteRepo.findAkteFromPapierkorbByid(5L)).thenReturn(Optional.ofNullable(null));
//        Mockito.doNothing().when(akteRepo).delete(akte1);
//        Mockito.doNothing().when(akteRepo).delete(akte4);
//        //test, if delete-failed-message contains akte 2, 3 and 5
//        Assertions.assertThrows(Exception.class,() -> akteService.deleteMultipleAktenPermanently(aktenIds),
//                "AKTE ID TO BE RESTORED FROM PAPIERKORB NOT FOUND EXCEPTION :::2, 3, 5");
//        Mockito.verify(akteRepo, Mockito.times(1)).delete(akte1);
//        Mockito.verify(akteRepo, Mockito.times(1)).delete(akte4);
//    }
//
//    @Test()
//    public void restore5Akten2Successful3Fail() throws Exception {
//        List<Long> aktenIds = new ArrayList<>();
//        aktenIds.add(1L);
//        aktenIds.add(2L);
//        aktenIds.add(3L);
//        aktenIds.add(4L);
//        aktenIds.add(5L);
//
//        Akte akte1= new Akte(1L,2L,11L,new Date(2020-1-7),
//                0L,1L,false,"first akte", "other docs",true,false, null);
//
//        Akte akte4= new Akte(4L,3L,12L,new Date(2020-1-7),
//                1L,2L,false,"second akte", "other docs", true, false,null);
//
//        Nutzer nutzer1 = new Nutzer(1L,"rakesh","rakesh@gmail.com","rakesh");
//
//        Mockito.when(akteRepo.findAkteFromPapierkorbByid(1L)).thenReturn(Optional.of(akte1));
//        Mockito.when(akteRepo.findAkteFromPapierkorbByid(2L)).thenReturn(Optional.ofNullable(null));
//        Mockito.when(akteRepo.findAkteFromPapierkorbByid(3L)).thenReturn(Optional.ofNullable(null));
//        Mockito.when(akteRepo.findAkteFromPapierkorbByid(4L)).thenReturn(Optional.of(akte4));
//        Mockito.when(akteRepo.findAkteFromPapierkorbByid(5L)).thenReturn(Optional.ofNullable(null));
//        Mockito.when(nutzerRepository.findByBenutzerNameAndDeleted("rakesh", false)).thenReturn(Optional.of(nutzer1));
//
//
//        //test, if restore-failed-message contains akte 2, 3 and 5
//        Assertions.assertThrows(Exception.class,() -> akteService.restoreMultipleAktenFromPapierkorb(aktenIds),
//                "AKTE ID TO BE RESTORED FROM PAPIERKORB NOT FOUND EXCEPTION :::2, 3, 5");
//
//        //test, if akte1 and akte4 are restored
//        Assertions.assertFalse(akte1.isInPapierKorb());
//        Assertions.assertFalse(akte4.isInPapierKorb());
//    }
//
//    @Test
//    public void searchForAnAkteByStadtBezirkAndBetreffContains_akte_() throws Exception {
//        Akte akte1 = new Akte(1L, 3L, 11L, new Date(),
//                0L, 1L, false, "first akte", "other docs", false, false, null);
//
//        Akte akte2 = new Akte(2L, 3L, 12L, new Date(),
//                1L, 2L, false, "second akte", "other docs", false, false, null);
//        AkteDTO akteDto1 = new AkteDTO(1L, 3L, 11L, new Date(),
//                0L, 1L, false, "first akte", "other docs", false, false, null, null);
//
//        AkteDTO akteDto2 = new AkteDTO(2L, 3L, 12L, new Date(),
//                1L, 2L, false, "second akte", "other docs", false, false, null, null);
//
//        //setting pagenumber=0 and pagesize=5
//        Sort sort = Sort.by("kennZiffer").ascending().and(Sort.by("stadtBezirk").ascending()
//                .and(Sort.by("neueHeftnummer").ascending()));
//        Pageable pageable = PageRequest.of(0, 5, sort);
//
//        //akten to be returned
//        List<AkteDTO> returnedAkten = new ArrayList<>();
//        returnedAkten.add(akteDto1);
//        returnedAkten.add(akteDto2);
//
//        //akten to be returned from aktenRepo
//        List<Akte> akteList = new ArrayList<>();
//        akteList.add(akte1);
//        akteList.add(akte2);
//
//        AkteResponse akteResponse = new AkteResponse();
//        akteResponse.setAktenList(returnedAkten);
//
//        Paginator paginator = new Paginator();
//        paginator.setPageSize(5);
//        paginator.setPageNo(0);
//        paginator.setTotalPages(1);
//        paginator.setLastPage(true);
//        paginator.setTotalRecords(2);
//
//        akteResponse.setPaginator(paginator);
//
//
//        Page<Akte> aktenFromRepository = new PageImpl<>(akteList, pageable, akteList.size() );
//
//        Mockito.when(akteRepo.findAkteByFiltering(null, null, 3L, null, null, "akte", pageable))
//                .thenReturn(aktenFromRepository);
//
//    Assertions.assertEquals(akteResponse, akteService.findAktenByFiltering(null, null, 3L, null, null, "akte",0,5, "kennZiffer", "asc"));
//    }
//}
