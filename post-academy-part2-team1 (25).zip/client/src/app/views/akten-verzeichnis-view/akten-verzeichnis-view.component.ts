import { AfterViewInit, Component, OnInit, ViewChild } from '@angular/core';
import { Akte } from 'src/app/interfaces/Akte.interface';
import { cloneDeep } from 'lodash';
import { RequestService } from 'src/app/shared/services/request.service';
import { Router } from '@angular/router';
import { SuchFelder } from 'src/app/interfaces/SuchFelder.interface';
import { MatPaginator } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';
import { MatTableDataSource } from '@angular/material/table';
import { StorageService } from 'src/app/shared/services/storage.service';
import { merge } from 'rxjs';
import { startWith, switchMap, take } from 'rxjs/operators';

import * as XLSX from 'xlsx';
import { User } from 'src/app/interfaces/user';
import { AkteService } from 'src/app/shared/services/akte.service';
import { AuthGuardService } from 'src/app/shared/services/auth-guard.service';

@Component({
  selector: 'app-akten-verzeichnis-view',
  templateUrl: './akten-verzeichnis-view.component.html',
  styleUrls: ['./akten-verzeichnis-view.component.scss'],
})
export class AktenVerzeichnisViewComponent implements OnInit, AfterViewInit {
  suchFelder: SuchFelder = {
    flur: '',
    flurstueck: '',
    stadtbezirk: '',
    heftnummer: '',
    kennziffer: '',
    freitext: '',
  };

  dataSource = new MatTableDataSource<Akte>([]);

  displayedColumns = [
    'kennZiffer',
    'almosenKasten',
    'stadtBezirk',
    'neueHeftnummer',
    'flur',
    'flurStueck',
    'aufenthaltsort',
    'anmerkungAufenthaltsort',
    'betreff',
    'sonstigeAnmerkungen',
  ];

  tableIsVisible: boolean = false;

  @ViewChild(MatPaginator) paginator!: MatPaginator;
  @ViewChild(MatSort) sort!: MatSort;

  constructor(
    private requestS: RequestService,
    private akteS: AkteService,
    public authS: AuthGuardService,
    private router: Router,
    private storageS: StorageService
  ) {
    const suchFelder = this.storageS.getSavedSearch('search');
    this.suchFelder = suchFelder;
  }

  user!: User | null;

  ngAfterViewInit() {
    this.dataSource.paginator = this.paginator;
    this.sort.active = '';
    this.dataSource.sort = this.sort;

    /* If the user changes the sort order, reset back to the first page. */
    this.dataSource.sort.sortChange.subscribe(
      () => (this.paginator.pageIndex = 0)
    );
  }

  ngOnInit(): void {}

  removeEmptySuchFelder = (suchFelder: SuchFelder): SuchFelder =>
    Object.entries(cloneDeep(suchFelder))
      .filter(([key, value]) => value !== '')
      .reduce((acc: any, value) => {
        acc[value[0]] = value[1];
        return acc;
      }, {});

  getResults() {
    merge(this.sort.sortChange, this.paginator.page)
      .pipe(
        startWith({}),
        switchMap(() => {
          return this.requestS.getFilteredItems(
            this.removeEmptySuchFelder(this.suchFelder),
            this.sort.active,
            this.sort.direction,
            this.paginator.pageIndex,
            this.paginator.pageSize
          );
        })
      )
      .subscribe((data) => {
        /* console.log('this.sort:\n', this.sort); */
        /* this.sort.start = this.sort.direction || "asc"; */
        this.dataSource.data = data.aktenList;
        this.paginator.length = data.paginator.totalRecords;
        this.dataSource.paginator = cloneDeep(this.paginator);
        this.tableIsVisible = true;
        this.storageS.saveSearch('search', this.suchFelder);
      });
  }

  export(): void {
    this.authS.exportGranted.pipe(take(1)).subscribe((exportGranted) => {
      if (exportGranted) {
        this.akteS.getList().then((list: Akte[]) => {
          const ws: XLSX.WorkSheet = XLSX.utils.json_to_sheet(list);

          const wb: XLSX.WorkBook = XLSX.utils.book_new();
          XLSX.utils.book_append_sheet(wb, ws, 'Sheet1');

          XLSX.writeFile(wb, 'akten-such-resultate.xlsx');
        });
      }
    });
    /*
      source:
        https://medium.com/@patade888/exporting-data-to-excel-in-angular-8-5a7cf5d0d25d
    */
  }

  openAkte(akte: Akte) {
    this.router.navigate(['/app/akten-verzeichnis', akte.akteId, 'informationen']);
  }
}
