export interface PaginatorDetails {
  pageNo: number;
  pageSize: number;
  totalRecords: number;
  totalPages: number;
  lastPage: boolean;
}
