package com.softwareone.postacademy.repository;

import com.softwareone.postacademy.model.Meldung;
import com.softwareone.postacademy.model.Nutzer;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.List;

public interface MeldungRepository extends JpaRepository<Meldung,Long> {

    @Query(value = "select d from #{#entityName} d where d.akte.akteId=?1 order by d.gemeldetAm desc")
    List<Meldung> findAllMeldugenOfAkte(Long akteId);

    @Query(value = "select d from #{#entityName} d where d.akte.inPapierKorb=false and d.akte.istAusgeliehen=false order by d.gemeldetAm desc")
    List<Meldung> fetchAllMeldungenOfAllAkten();

    @Query(value = "select d from #{#entityName} d where d.zustand=1 and d.akte.akteId=:akteId order by d.gemeldetAm desc")
    List<Meldung> fetchAllOpenMeldungenOfAkte(Long akteId);

    @Query(value = "select d from #{#entityName} d where d.zustand=1 and d.akte.inPapierKorb=false and d.akte.istAusgeliehen=false order by d.gemeldetAm desc")
    List<Meldung> fetchAllOpenMeldungenOfAllAkten();

    @Query(value = "select d from #{#entityName} d where d.akte.inPapierKorb=true")
    List<Meldung> fetchAllMeldungenOfAllAktenFromPapierkorb();

    List<Meldung> findByBearbeitetDurchOrGemeldetVon(Nutzer nutzer, Nutzer nutzer2);
}