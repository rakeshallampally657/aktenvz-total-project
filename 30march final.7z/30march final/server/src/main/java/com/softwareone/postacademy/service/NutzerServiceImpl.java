package com.softwareone.postacademy.service;

import com.softwareone.postacademy.dto.NewPasswortDTO;
import com.softwareone.postacademy.dto.NutzerDTO;
import com.softwareone.postacademy.model.*;
import com.softwareone.postacademy.repository.AkteRepository;
import com.softwareone.postacademy.repository.AufenthaltsortAenderungenRepository;
import com.softwareone.postacademy.repository.MeldungRepository;
import com.softwareone.postacademy.repository.NutzerRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;

import javax.persistence.EntityNotFoundException;
import java.util.*;

@Service
@RequiredArgsConstructor
public class NutzerServiceImpl implements NutzerService, UserDetailsService {
    private final NutzerRepository nutzerRepository;
    private final BCryptPasswordEncoder passwordEncoder;
    @Autowired
    private MeldungRepository meldungRepository;
    @Autowired
    private AkteRepository akteRepository;
    @Autowired
    private AufenthaltsortAenderungenRepository aufenthaltsortAenderungenRepository;
    @Autowired
    private EmailService emailService;

    public Nutzer convertDTOToModel(NutzerDTO nutzerDTO) {
        Nutzer nutzer= new Nutzer();
        nutzer.setBenutzerName(nutzerDTO.getBenutzerName());
        nutzer.setEmail(nutzerDTO.getEmail());
        nutzer.setName(nutzerDTO.getName());
        nutzer.setVorName(nutzerDTO.getVorName());
        nutzer.setDeleted(nutzerDTO.isDeleted());
        if(nutzerDTO.getNutzerId() != null)
            nutzer.setNutzerId(nutzerDTO.getNutzerId());
        Set<EROLE> roles = new HashSet<>();
        for(String index : nutzerDTO.getRechte()){
            roles.add(EROLE.get(index));
        }
        nutzer.setRechte(roles);
        return nutzer;
    }

    public NutzerDTO convertModelToDTO(Nutzer nutzer) {
        return new NutzerDTO(nutzer);
    }

    @Override
    public List<NutzerDTO> getAllNutzer() {
        List<Nutzer> nutzerList=nutzerRepository.findAll();
        List<NutzerDTO> nutzerResponseList = new ArrayList<>();
        for (Nutzer nutzer : nutzerList) {
            if(!nutzer.getBenutzerName().equals("geloeschterNutzer")){
                nutzerResponseList.add(new NutzerDTO(nutzer));
            }
        }
        return nutzerResponseList;
    }

    @Override
    public List<NutzerDTO> getAllCurrentNutzer() {
        List<Nutzer> nutzerList=nutzerRepository.findByDeleted(false);
        List<NutzerDTO> nutzerResponseList = new ArrayList<>();
        for (Nutzer nutzer : nutzerList) {
            if(!nutzer.getBenutzerName().equals("geloeschterNutzer")) {
                nutzerResponseList.add(new NutzerDTO(nutzer));
            }
        }
        return nutzerResponseList;
    }

    @Override
    public NutzerDTO addNutzer(NutzerDTO nutzerDTO) {
        Nutzer nutzer = convertDTOToModel(nutzerDTO);
        Set<EROLE> rechte= new HashSet<>();
        if(nutzerDTO.getRechte() == null || nutzerDTO.getRechte().isEmpty()) {
            rechte.add(EROLE.USER);
            rechte.add(EROLE.AKTE_MELDUNGEN_VERFASSEN);
            rechte.add(EROLE.AKTE_DRUCKEN);
        } else {
            rechte = nutzer.getRechte();
        }
        nutzer.setRechte(rechte);
        nutzer.setPasswordResetToken(null);
        //encode password
        nutzer.setPassword(passwordEncoder.encode(nutzerDTO.getPassword()));
        return convertModelToDTO(nutzerRepository.save(nutzer));
    }

    @Override
    public NutzerDTO updateNutzer(NutzerDTO nutzerDTO) throws EntityNotFoundException {
        Nutzer nutzer = convertDTOToModel(nutzerDTO);
        Optional<Nutzer> nutzerObtained= nutzerRepository.findById(nutzerDTO.getNutzerId());
        if(nutzerObtained.isEmpty() || nutzerObtained.get().getBenutzerName().equals("geloeschterNutzer")){
            throw new EntityNotFoundException("Nutzer to be updated not found");
        }
        if(nutzerDTO.getPassword()==null){
            nutzer.setPassword(nutzerObtained.get().getPassword());
        } else{
            nutzer.setPassword(passwordEncoder.encode(nutzerDTO.getPassword()));
        }
        return new NutzerDTO(nutzerRepository.save(nutzer));
    }

    @Override
    public NutzerDTO fetchNutzerById(Long nutzerId) throws EntityNotFoundException {
        Optional<Nutzer> nutzerObtained= nutzerRepository.findById(nutzerId);
        if(nutzerObtained.isEmpty() || nutzerObtained.get().getBenutzerName().equals("geloeschterNutzer")){
            throw new EntityNotFoundException("Nutzer not found");
        }
        return new NutzerDTO(nutzerObtained.get());
    }

    @Override
    public NutzerDTO fetchNutzerByName(String nutzerName) throws EntityNotFoundException {
        Optional<Nutzer> nutzerObtained= nutzerRepository.findByBenutzerNameAndDeleted(nutzerName, false);
        if(nutzerObtained.isEmpty() || nutzerObtained.get().getBenutzerName().equals("geloeschterNutzer")){
            throw new EntityNotFoundException("Nutzer not found");
        }
        return new NutzerDTO(nutzerObtained.get());
    }

    @Override
    /**maybe needs long time, because every change made by this users must be found and the corresponding user
     * has to be changed to deleted user*/
    public void deleteMultipleNutzer(List<Long> nutzerIds) {
        List<Nutzer> nutzerList = nutzerRepository.findAllById(nutzerIds);
        Nutzer geloeschterNutzer = nutzerRepository.findByBenutzerName("geloeschterNutzer");
        for(Nutzer nutzer : nutzerList){
            if(nutzer.getBenutzerName().equals("geloeschterNutzer") || nutzer.getBenutzerName().equals("admin")){
                nutzerIds.remove(nutzer.getNutzerId());
                continue;
            }
            List<Meldung> meldungen = meldungRepository.findByBearbeitetDurchOrGemeldetVon(nutzer, nutzer);
            for(Meldung meldung : meldungen){
                if(meldung.getGemeldetVon().equals(nutzer)){
                    meldung.setGemeldetVon(geloeschterNutzer);
                }
                if(meldung.getBearbeitetDurch().equals(nutzer)){
                    meldung.setBearbeitetDurch(geloeschterNutzer);
                }
            }
            meldungRepository.saveAll(meldungen);
            List<AufenthaltsortAenderungen> aufenthaltsortAenderungenList = aufenthaltsortAenderungenRepository.findByNutzer(nutzer);
            for(AufenthaltsortAenderungen aAenderung : aufenthaltsortAenderungenList){
                aAenderung.setNutzer(geloeschterNutzer);
            }
            aufenthaltsortAenderungenRepository.saveAll(aufenthaltsortAenderungenList);
            List<Akte> bearbeiteteAkten = akteRepository.findByNutzer(nutzer);
            for(Akte akte : bearbeiteteAkten){
                akte.setNutzer(geloeschterNutzer);
            }
            akteRepository.saveAll(bearbeiteteAkten);
        }
        nutzerRepository.deleteAllById(nutzerIds);
    }

    @Override
    public void archiveMultipleNutzer(List<Long> nutzerIdList) {
        for(Long id : nutzerIdList){
            Nutzer nutzer = nutzerRepository.findByNutzerIdAndDeleted(id, false);
            if(nutzer.getBenutzerName().equals("geloeschterNutzer") || nutzer.getBenutzerName().equals("admin")){
                nutzerIdList.remove(nutzer.getNutzerId());
                continue;
            }
            nutzer.setDeleted(true);
            nutzerRepository.save(nutzer);
        }
    }

    @Override
    public void unarchiveMultipleNutzer(List<Long> nutzerIdList){
        for(Long id : nutzerIdList){
            Nutzer nutzer = nutzerRepository.findByNutzerIdAndDeleted(id, true);
            if(nutzer.getBenutzerName().equals("geloeschterNutzer") || nutzer.getBenutzerName().equals("admin")){
                nutzerIdList.remove(nutzer.getNutzerId());
                continue;
            }
            nutzer.setDeleted(false);
            nutzerRepository.save(nutzer);
        }
    }

    @Override
    public void createNewPassword(NewPasswortDTO newPasswordDto) {
        Nutzer nutzer = nutzerRepository.findByPasswordResetTokenAndDeleted(
                newPasswordDto.getPasswordResetToken(), false);
        if(nutzer.getBenutzerName().equals("geloeschterNutzer")){
            return;
        }
        nutzer.setPassword(passwordEncoder.encode(newPasswordDto.getPassword()));
        nutzer.setPasswordResetToken(null);
        nutzerRepository.save(nutzer);
    }

    @Override
    public String resetPassword(String email) {
        //"testfueraktenvz@byom.de"
        System.out.println("==============================================================================");
        Nutzer nutzer = nutzerRepository.findByEmailAndDeleted(email, false);
        if(nutzer != null && !nutzer.getBenutzerName().equals("geloeschterNutzer")) {
            String baseUrl = ServletUriComponentsBuilder.fromCurrentContextPath().build().toUriString();
            System.out.println(baseUrl);
            String uuid = UUID.randomUUID().toString();
            nutzer.setPasswordResetToken(uuid);
            nutzerRepository.save(nutzer);
            /* production link */
            /* String link = baseUrl + "/auth/neues-passwort-festlegen/"+ uuid;*/

            /* local dev link */
            String link = "http://localhost:4200/auth/neues-passwort-festlegen/"+ uuid;

            emailService.sendSimpleMessage(email, "Reset password for AktenVZ App", nutzer.getBenutzerName(),
                    link);
            return link;
        }else {
            System.out.println("Nutzer nicht gefunden");
            throw new EntityNotFoundException();
        }
    }

    @Override
    public UserDetails loadUserByUsername(String nutzerNameOrEmail) throws UsernameNotFoundException {
        Optional<Nutzer> nutzerObtained = nutzerRepository.findByBenutzerNameOrEmailAndDeleted(nutzerNameOrEmail,nutzerNameOrEmail, false);
        if(nutzerObtained.isEmpty() || nutzerObtained.get().getBenutzerName().equals("geloeschterNutzer")){
            throw new EntityNotFoundException("Nutzer not found");
        }
        Nutzer nutzer = nutzerObtained.get();
        return UserDetailsImpl.build(nutzer);
    }
}