import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AktenMeldungenViewComponent } from './akten-meldungen-view.component';

describe('AktenMeldungenViewComponent', () => {
  let component: AktenMeldungenViewComponent;
  let fixture: ComponentFixture<AktenMeldungenViewComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AktenMeldungenViewComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(AktenMeldungenViewComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
