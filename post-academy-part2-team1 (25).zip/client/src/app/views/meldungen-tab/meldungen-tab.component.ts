import { Component, OnInit, ViewChild } from '@angular/core';
import { MatPaginator } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';
import { MatTableDataSource } from '@angular/material/table';
import { MatDialog } from '@angular/material/dialog';
import { MeldungShort } from 'src/app/interfaces/MeldungShort.interface';
import { MatSlideToggleChange } from '@angular/material/slide-toggle';
import { AkteService } from 'src/app/shared/services/akte.service';

@Component({
  selector: 'app-meldungen-tab',
  templateUrl: './meldungen-tab.component.html',
  styleUrls: ['./meldungen-tab.component.scss'],
})
export class MeldungenTabComponent implements OnInit {
  displayedColumns: string[] = [
    'bearbeitetDurch',
    'gemeldetAm',
    'gemeldetVon',
    'kennZiffer',
    'almosenKasten',
    'stadtBezirk',
    'heftnummer',
    'bereich',
    'inBearbeitungVon',
  ];
  dataSource = new MatTableDataSource<MeldungShort>([]);
  @ViewChild(MatPaginator) paginator!: MatPaginator;
  @ViewChild(MatSort) sort!: MatSort;

  constructor(public dialog: MatDialog, private akteS: AkteService) {}

  ngOnInit(): void {
   this.init();
  }
  init = async (): Promise<void> => {
    this.dataSource.data = await this.akteS.getMeldungList();
  };

  ngAfterViewInit() {
    this.dataSource.paginator = this.paginator;
    this.dataSource.sort = this.sort;
  }

  refreshTable = async (event: MatSlideToggleChange): Promise<void> => {
    this.dataSource.data = event.checked
      ? await this.akteS.getMeldungOffenList()
      : await this.akteS.getMeldungList();
  };
}
