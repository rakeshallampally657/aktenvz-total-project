package com.softwareone.postacademy.repository;

import com.softwareone.postacademy.model.Nutzer;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;
import java.util.Optional;

public interface NutzerRepository extends JpaRepository<Nutzer,Long> {
    Optional<Nutzer> findByBenutzerNameOrEmailAndDeleted(String benutzerName, String email, Boolean deleted);
    Optional<Nutzer> findByBenutzerNameAndDeleted(String benutzerName, Boolean deleted);
    Boolean existsByEmail(String email);
    Nutzer findByNutzerIdAndDeleted(Long id, Boolean deleted);
    List<Nutzer> findByDeleted( boolean deleted);
    List<Nutzer> findAll();
    Nutzer findByBenutzerName(String benutzerName);
    Nutzer findByPasswordResetTokenAndDeleted(String pwrToken, boolean deleted);

    Nutzer findByEmailAndDeleted(String email, boolean deleted);
}