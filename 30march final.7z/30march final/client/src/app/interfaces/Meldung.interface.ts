import { GrundstuecksInformation } from './GrundstuecksInformation.interface';

export interface Meldung {
  gemeldetVon: string;
  gemeldetAm: any;
  bereich: string;
  nachricht: string;
  zustand: number;
  akte: {
    akteId: number;
    stadtBezirk: number;
    kennZiffer: number;
    aktenBeginn: any;
    letzteHeftnummer: number;
    neueHeftnummer: number;
    almosenKasten: boolean;
    betreff: string;
    sonstigeAnmerkungen: string;
    inPapierKorb: boolean;
    istAusgeliehen: boolean;
    allGrundstuecksInformationen: GrundstuecksInformation[];
  };
}
