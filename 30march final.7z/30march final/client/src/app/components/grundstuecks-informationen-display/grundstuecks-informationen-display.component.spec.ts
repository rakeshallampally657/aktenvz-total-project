import { ComponentFixture, TestBed } from '@angular/core/testing';

import { GrundstuecksInformationenDisplayComponent } from './grundstuecks-informationen-display.component';

describe('GrundstuecksInformationenDisplayComponent', () => {
  let component: GrundstuecksInformationenDisplayComponent;
  let fixture: ComponentFixture<GrundstuecksInformationenDisplayComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ GrundstuecksInformationenDisplayComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(GrundstuecksInformationenDisplayComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
