import { AfterViewInit, Component, OnInit, ViewChild } from '@angular/core';
import { SelectionModel } from '@angular/cdk/collections';
import { MatPaginator } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';
import { MatTableDataSource } from '@angular/material/table';

import { MatDialog } from '@angular/material/dialog';
import { DialogComponent } from 'src/app/components/dialog/dialog.component';
import { GeloeschteAkte } from 'src/app/interfaces/geloeschte-akte';
import { AkteService } from 'src/app/shared/services/akte.service';

@Component({
  selector: 'app-papierkorb-view',
  templateUrl: './papierkorb-view.component.html',
  styleUrls: ['./papierkorb-view.component.scss'],
})
export class PapierkorbViewComponent implements AfterViewInit, OnInit {
  displayedColumns: string[] = [
    'select',
    'kennZiffer',
    'stadtBezirk',
    'heftNummer',
    'geloeschtVon',
    'geloeschtAm',
    'betreff',
  ];
  dataSource = new MatTableDataSource<GeloeschteAkte>([]);

  selection = new SelectionModel<GeloeschteAkte>(true, []);

  @ViewChild(MatPaginator) paginator!: MatPaginator;
  @ViewChild(MatSort) sort!: MatSort;

  constructor(private akteS: AkteService, public dialog: MatDialog) {}
  ngOnInit(): void {
    this.init();
  }
  init = async (): Promise<void> => {
    this.dataSource.data = await this.akteS.getPapierkorb();
  };

  ngAfterViewInit() {
    this.dataSource.paginator = this.paginator;
    this.dataSource.sort = this.sort;
  }

  applyFilter(event: Event) {
    const filterValue = (event.target as HTMLInputElement).value;
    this.dataSource.filter = filterValue.trim().toLowerCase();

    if (this.dataSource.paginator) {
      this.dataSource.paginator.firstPage();
    }
  }

  isAllSelected() {
    const numSelected = this.selection.selected.length;
    const numRows = this.dataSource.data.length;
    return numSelected === numRows;
  }

  masterToggle() {
    if (this.isAllSelected()) {
      this.selection.clear();
      return;
    }

    this.selection.select(...this.dataSource.data);
  }

  checkboxLabel(row?: GeloeschteAkte): string {
    if (!row) {
      return `${this.isAllSelected() ? 'deselect' : 'select'} all`;
    }
    return `${this.selection.isSelected(row) ? 'deselect' : 'select'} row ${
      row.kennZiffer
    }`;
  }

  onSelect = async (event: Event) => {
    event.stopPropagation();
    const selected = await this.selection.selected;
    console.log(selected);
  };

  /* actions:
  1: moveToPapierkorb
  2: wiederherstellen
  3: entgueltigLoeschen
  4: papierkorbLeeren
  */
  openDialog(message: string, action: number) {
    const dialogRef = this.dialog.open(DialogComponent, {
      data: {
        message,
      },
      autoFocus: false,
      maxWidth: '100%',
    });
    dialogRef.afterClosed().subscribe((res) => {
      if (res) {
        switch (action) {
          case 2: {
            this.akteS
              .restoreFromPapierkorb(
                this.selection.selected.map((akte) => akte.akteId)
              )
              .then(() => {
                const restoredAktenIds = this.selection.selected.map(
                  (akte) => akte.akteId
                );
                this.dataSource.data = this.dataSource.data.filter(
                  (akte) => !restoredAktenIds.includes(akte.akteId)
                );
                this.selection.clear();
              });
            break;
          }
          case 3: {
            this.akteS
              .deleteListPermanently(
                this.selection.selected.map((akte) => akte.akteId)
              )
              .then(() => {
                const deletedAktenIds = this.selection.selected.map(
                  (akte) => akte.akteId
                );
                this.dataSource.data = this.dataSource.data.filter(
                  (akte) => !deletedAktenIds.includes(akte.akteId)
                );
                this.selection.clear();
              });
            break;
          }
          case 4: {
            this.akteS.emptyPapierkorb().then(() => {
              this.dataSource.data = [];
              this.selection.clear();
            });
            break;
          }
          default: {
            console.log('dialogRefAfterClosed triggered default');
            break;
          }
        }
      }
    });
  }
}
