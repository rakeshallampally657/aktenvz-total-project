import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { UserService } from 'src/app/shared/services/user.service';

@Component({
  selector: 'app-new-password',
  templateUrl: './new-password.component.html',
  styleUrls: ['./new-password.component.scss'],
})
export class NewPasswordComponent implements OnInit {
  newPassword: string = '';
  constructor(
    private userS: UserService,
    private route: ActivatedRoute,
    private router: Router
  ) {}

  ngOnInit(): void {}

  onSubmit = async (form: NgForm): Promise<void> => {
    if (form.invalid) {
      return;
    }
    await this.userS.updatePassword({
      passwordResetToken: this.route.snapshot.params.uuid,
      password: form.value.password,
    });
    this.router.navigate(['/auth/login']);
    form.reset();
  };
}
