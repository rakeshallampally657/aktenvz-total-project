import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AktenVerzeichnisViewComponent } from './akten-verzeichnis-view.component';

describe('AktenVerzeichnisViewComponent', () => {
  let component: AktenVerzeichnisViewComponent;
  let fixture: ComponentFixture<AktenVerzeichnisViewComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AktenVerzeichnisViewComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(AktenVerzeichnisViewComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
