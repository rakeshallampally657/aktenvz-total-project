import { AfterViewInit, Component, OnInit, ViewChild } from '@angular/core';
import { MatPaginator } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';
import { MatTableDataSource } from '@angular/material/table';
import { cloneDeep } from 'lodash';
import { RequestService } from 'src/app/shared/services/request.service';
import { MatDialog } from '@angular/material/dialog';
import { Aufenthaltsort } from 'src/app/interfaces/Aufenthaltsort.interface';
import { AkteService } from 'src/app/shared/services/akte.service';
@Component({
  selector: 'app-akten-aufenthaltsorte-view',
  templateUrl: './akten-aufenthaltsorte-view.component.html',
  styleUrls: ['./akten-aufenthaltsorte-view.component.scss'],
})
export class AktenAufenthaltsorteViewComponent
  implements OnInit, AfterViewInit
{
  displayedColumns: string[] = [
    'datum',
    'aufenthaltsort',
    'anmerkungAufenthaltsort',
  ];
  dataSource = new MatTableDataSource<Aufenthaltsort>([]);
  @ViewChild(MatPaginator) paginator!: MatPaginator;
  @ViewChild(MatSort) sort!: MatSort;
  constructor(private akteS: AkteService, public dialog: MatDialog) {}
  ngOnInit(): void {
   this.init();
  }
  init = async (): Promise<void> => {
    this.dataSource.data = await this.akteS.getAufenthaltsortList();
  };
  ngAfterViewInit() {
    this.dataSource.paginator = this.paginator;
    this.dataSource.sort = this.sort;
  }
  applyFilter(event: Event) {
    const filterValue = (event.target as HTMLInputElement).value;
    this.dataSource.filter = filterValue.trim().toLowerCase();

    if (this.dataSource.paginator) {
      this.dataSource.paginator.firstPage();
    }
  }
}
