export interface AusleihDetails {
  ausgeliehenVon: string;
  ausgeliehenAn: string;
  ausgeliehenAnEmail: string;
  rueckgabeDatum: Date;
  anmerkungAufenthaltsort: string;
}
