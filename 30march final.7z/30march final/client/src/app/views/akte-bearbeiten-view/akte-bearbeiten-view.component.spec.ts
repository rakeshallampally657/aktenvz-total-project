import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AkteBearbeitenViewComponent } from './akte-bearbeiten-view.component';

describe('AkteBearbeitenViewComponent', () => {
  let component: AkteBearbeitenViewComponent;
  let fixture: ComponentFixture<AkteBearbeitenViewComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AkteBearbeitenViewComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(AkteBearbeitenViewComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
