package com.softwareone.postacademy.integration;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.softwareone.postacademy.PostacademyApplication;
import com.softwareone.postacademy.dto.AkteAusleihenDTO;
import com.softwareone.postacademy.dto.AkteDTO;
import org.hamcrest.Matchers;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.MethodSorters;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.context.TestPropertySource;
import org.springframework.test.context.jdbc.Sql;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockHttpServletRequestBuilder;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;

import java.util.Date;

import java.util.List;

import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
@RunWith(SpringRunner.class)
@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT,classes = PostacademyApplication.class)
@TestPropertySource(locations = "classpath:application-test2.properties")
@AutoConfigureMockMvc
public class AufenthaltsortAenderungenControllerIntegrationTest {
    @Autowired
    private MockMvc mockMvc; // for sending the http request

    @Autowired
    private ObjectMapper jsonSerializer;

    private static String baseUrl="/api";

    @Sql({"/test2.sql"})
    @Test
    public void _getAllAufenthaltsortenOfAkteTest() throws Exception
    {
        // The akten information is loaded in the in to database using test2.sql script
        //Getting all the Aufenthaltsorten information
        mockMvc.perform( MockMvcRequestBuilders
                        .get(baseUrl+"/akte/1/aufenthaltsort")
                        .accept(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andExpect(MockMvcResultMatchers.jsonPath("$.data").exists()) //checking whether akte exists
                .andExpect(MockMvcResultMatchers.jsonPath("$.data[0].aufenthaltsort").value(true))
                .andExpect(MockMvcResultMatchers.jsonPath("$.data[1].aufenthaltsort").value(false));
    }

    @Test
    public void getLatestAufenthaltsortOfAllBorrowedAktenTest() throws Exception
    {
        // The akten information is loaded in the  database using test2.sql script
        //Getting all the Borrowed akten information and verfying whether the data is present
        mockMvc.perform( MockMvcRequestBuilders
                        .get(baseUrl+"/akte/ausgeliehen")
                        .accept(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andExpect(MockMvcResultMatchers.jsonPath("$.data").exists()) ;//checking whether akte exists

    }

    @Test
    public void ausleihenAkteTest() throws Exception {
        //Created the akteAusleihen data object which will be passed as the request body for post http request

        AkteAusleihenDTO akteAusleihenDTO = new AkteAusleihenDTO("Tom","Tom@gmail.com",null,
                "freitext");

        ObjectMapper jsonSerializer = new ObjectMapper();
        //converting java object into json
        String akteToBeCreatedJson = jsonSerializer.writeValueAsString(akteAusleihenDTO);

        mockMvc.perform( MockMvcRequestBuilders
                        .post(baseUrl+"/akte/3/ausleihen")
                        .content(akteToBeCreatedJson)
                        .contentType(MediaType.APPLICATION_JSON)
                        .accept(MediaType.APPLICATION_JSON))
                .andExpect(status().isCreated())
                .andExpect(MockMvcResultMatchers.jsonPath("$.data.akteId").exists())
                .andExpect(MockMvcResultMatchers.jsonPath("$.data.ausgeliehenVon").value("rakesh"));

    }

    @Test
    public void returnABorrowedAkteSuccessfulTest() throws Exception {

        MockHttpServletRequestBuilder postRequest = MockMvcRequestBuilders
                .post(baseUrl + "/akte/zurueckgeben")
                .contentType(MediaType.APPLICATION_JSON)
                .content(jsonSerializer.writeValueAsString(List.of(4)));
        mockMvc.perform(postRequest)
                .andExpect(status().isCreated())
                .andExpect(MockMvcResultMatchers.jsonPath("$.data").doesNotExist());
    }

    @Test public void returnABorrowedAkteErrorAkteNotFoundTest() throws Exception{
        MockHttpServletRequestBuilder postRequest = MockMvcRequestBuilders
                .post(baseUrl + "/akte/zurueckgeben")
                .contentType(MediaType.APPLICATION_JSON)
                .content(jsonSerializer.writeValueAsString(List.of(5)));
        mockMvc.perform(postRequest)
                .andExpect(status().is5xxServerError())
                .andExpect(MockMvcResultMatchers.jsonPath("$.data", Matchers.hasSize(1)))
                .andExpect(MockMvcResultMatchers.jsonPath("$.data[0]").value(5));
    }
}
