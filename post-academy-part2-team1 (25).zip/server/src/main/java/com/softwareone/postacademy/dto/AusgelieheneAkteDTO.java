package com.softwareone.postacademy.dto;

import com.softwareone.postacademy.model.AufenthaltsortAenderungen;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.Instant;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class AusgelieheneAkteDTO {
    private Long akteId;
    private Long kennZiffer;
    private Long stadtBezirk;
    private Long heftnummer;
    private String betreff;

    private String ausgeliehenAn;
    private String ausgeliehenVon;
    private Instant rueckgabeDatum;

    public AusgelieheneAkteDTO(AufenthaltsortAenderungen aufenthaltsortAenderungen) {
        this.akteId = aufenthaltsortAenderungen.getAkte().getAkteId();
        this.kennZiffer = aufenthaltsortAenderungen.getAkte().getKennZiffer();
        this.stadtBezirk = aufenthaltsortAenderungen.getAkte().getStadtBezirk();
        this.heftnummer = aufenthaltsortAenderungen.getAkte().getNeueHeftnummer();
        this.betreff = aufenthaltsortAenderungen.getAkte().getBetreff();
        this.ausgeliehenAn = aufenthaltsortAenderungen.getAusgeliehenAn();
        if(aufenthaltsortAenderungen.getNutzer()!=null){
            this.ausgeliehenVon = aufenthaltsortAenderungen.getNutzer().getBenutzerName();
        }
        this.rueckgabeDatum=aufenthaltsortAenderungen.getRueckgabeDatum();
    }
}