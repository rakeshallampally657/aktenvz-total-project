import { Injectable } from '@angular/core';
import * as moment from 'moment';

@Injectable({
  providedIn: 'root',
})
export class MapperService {
  constructor() {}

  convertDateToString(date: any): string {
    if (moment.isMoment(date)) date = date.format('DD/MM/YYYY');
    if (date instanceof Date) date = date.toLocaleDateString('en-GB');
    return date;
  }

  convertStringToDate = (date: string) => {
    return new Date(
      Number(date.split('/')[2]),
      Number(date.split('/')[1]) - 1,
      Number(date.split('/')[0])
    );
  };

  /*
  source:
  https://cheatcode.co/tutorials/how-to-recursively-traverse-an-object-with-javascript
  */

  targetKeyList: string[] = ['gemeldetAm', 'datum', 'letzteAenderung'];
  targetKeyListDate: string[] = [
    'rueckgabeDatum',
    'geloeschtAm',
    'aktenBeginn',
    'vertragsBeginn',
  ];
  convertInstantToDate = (object: any = {}): any => {
    if (object && typeof object === 'object') {
      const entryList = Object.entries(object);

      for (let i = 0; i < entryList.length; i += 1) {
        const [objectKey, objectValue] = entryList[i];

        if (objectValue && typeof objectValue === 'object') {
          /* console.log('objectKey:', objectKey);
          console.log('objectValue:', objectValue); */
          this.convertInstantToDate(objectValue);
        }

        if (this.targetKeyList.includes(objectKey)) {
          object[objectKey] = new Date(object[objectKey]).toLocaleString();
        } else if (this.targetKeyListDate.includes(objectKey)) {
          object[objectKey] = new Date(object[objectKey]).toLocaleDateString();
        }
      }
    }
    return object;
  };
}
