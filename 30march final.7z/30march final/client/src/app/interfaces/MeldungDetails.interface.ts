export interface MeldungDetails {
  bereich: string;
  nachricht: string;
}
