package com.softwareone.postacademy.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.Instant;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class AkteAusleihenDTO {
    private String ausgeliehenAn;
    private String ausgeliehenAnEmail;
    private Instant rueckgabeDatum;
    private String anmerkungAufenthaltsort;
}
