import { ChangeDetectorRef, Component, OnDestroy, OnInit } from '@angular/core';
import { Subscription } from "rxjs";
import { LoaderService } from './loader.service';

@Component({
  selector: 'app-loader',
  templateUrl: './loader.component.html',
  styleUrls: ['./loader.component.scss'],
})
export class LoaderComponent implements OnInit, OnDestroy {
  loaderIsVisible: boolean = false;
  isLoadingSub!: Subscription;

  constructor(
    private loaderS: LoaderService,
    private cdRef: ChangeDetectorRef
  ) {}
  ngOnInit(): void {
    this.init();
  }
  init() {
    this.isLoadingSub = this.loaderS.getIsLoading().subscribe((isLoading) => {
      this.loaderIsVisible = isLoading;
      this.cdRef.detectChanges();
    });
  }
  ngOnDestroy(): void {
      this.isLoadingSub.unsubscribe();
  }
}
