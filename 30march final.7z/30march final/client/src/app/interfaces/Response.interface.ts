export interface Response {
  message: string;
  data: any;
}
