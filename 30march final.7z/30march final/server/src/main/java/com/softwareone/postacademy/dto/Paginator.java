package com.softwareone.postacademy.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class Paginator {
    private int pageNo;
    private int pageSize;
    private long totalRecords;
    private int totalPages;
    private boolean isLastPage;
}