package com.softwareone.postacademy.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;
import java.time.Instant;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
public class AufenthaltsortAenderungen {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long aufenthaltsortAnderungId;
    private Instant datum;
    private Instant rueckgabeDatum;
    private String ausgeliehenAn;
    private String ausgeliehenAnEmail;
    private boolean istAusgeliehen;
    @Lob
    private String anmerkungAufenthaltsort;
    @ManyToOne(cascade = CascadeType.DETACH)
    @JoinColumn(name="akte_fk")
    private Akte akte;
    @ManyToOne(cascade = CascadeType.DETACH)
    @JoinColumn(name="nutzer_fk")
    private Nutzer nutzer;
}