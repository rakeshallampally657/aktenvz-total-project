package com.softwareone.postacademy.service;

import com.softwareone.postacademy.dto.*;

import javax.persistence.EntityNotFoundException;
import java.util.List;

public interface AkteService {
    AkteDTO addAkte(AkteDTO akteDTO);
    List<AkteDTO> getAllAkte(int pageNo,int pageSize);
    AkteDTO fetchAkteById(Long akteId) throws EntityNotFoundException;
    List<PapierkorbDTO> getAllAktenFromPapierkorb();
    Long findLastHeftNumber();
    AkteResponse findAktenByFiltering(Long heftnummer, String flurStueck, Long stadtBezirk, Long kennZiffer, Long flur, String freiText, int pageNo, int pageSize, String sortField, String sortDirection);
    AkteDTO updateAkte(AkteDTO akteDTO) throws EntityNotFoundException;
    void deleteAllAkten();
    String deleteMultipleAktenPermanently(List<Long> akteIdList) throws EntityNotFoundException;
    List<PapierkorbDTO> temporaryDeletion(List<Long> akteId) throws EntityNotFoundException;
    List<AkteDTO> restoreMultipleAktenFromPapierkorb(List<Long> akteIdList) throws EntityNotFoundException;
    String deleteAllAktenFromPapierkorbPermanently();
    List<AenderungDTO> getHistory(Long akteId);
    AkteVersionierungDTO getVersion(Long aenderungId);
}