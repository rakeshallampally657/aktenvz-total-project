package com.softwareone.postacademy.dto;

import com.softwareone.postacademy.model.EROLE;
import com.softwareone.postacademy.model.Nutzer;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.HashSet;
import java.util.Set;

@AllArgsConstructor
@Data
@NoArgsConstructor
public class NutzerDTO {

    private Long nutzerId;
    private String vorName;
    private String name;
    private String benutzerName;
    private String email;
    private String password;
    private boolean deleted;
    private Set<String> rechte;

    public NutzerDTO(Nutzer nutzer){
        this.nutzerId = nutzer.getNutzerId();
        this.name=nutzer.getName();
        this.vorName=nutzer.getVorName();
        this.benutzerName= nutzer.getBenutzerName();
        this.email= nutzer.getEmail();
        this.password=null;
        this.deleted = nutzer.isDeleted();
        this.rechte = new HashSet<>();
        for (EROLE role : nutzer.getRechte()){
            this.rechte.add(role.index());
        }
    }
}