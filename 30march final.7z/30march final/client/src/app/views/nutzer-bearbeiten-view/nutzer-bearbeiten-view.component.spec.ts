import { ComponentFixture, TestBed } from '@angular/core/testing';

import { NutzerBearbeitenViewComponent } from './nutzer-bearbeiten-view.component';

describe('NutzerBearbeitenViewComponent', () => {
  let component: NutzerBearbeitenViewComponent;
  let fixture: ComponentFixture<NutzerBearbeitenViewComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ NutzerBearbeitenViewComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(NutzerBearbeitenViewComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
