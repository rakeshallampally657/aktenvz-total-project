export interface DialogData {
  message: string;
  action: string;
}
