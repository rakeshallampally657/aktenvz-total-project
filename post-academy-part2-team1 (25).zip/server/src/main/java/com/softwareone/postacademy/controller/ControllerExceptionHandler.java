package com.softwareone.postacademy.controller;

import com.softwareone.postacademy.dto.ResponseDTO;
import com.softwareone.postacademy.exceptions.SaveToDatabaseException;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;

import javax.persistence.EntityNotFoundException;
import java.lang.Exception;

@ControllerAdvice
public class ControllerExceptionHandler {

    @ExceptionHandler(EntityNotFoundException.class)
    public ResponseEntity<ResponseDTO> entityNotFoundException(EntityNotFoundException enfException){
        enfException.printStackTrace();
        return new ResponseEntity<>(new ResponseDTO(enfException.getMessage(), null), HttpStatus.NOT_FOUND);
    }

    @ExceptionHandler(SaveToDatabaseException.class)
    public ResponseEntity<ResponseDTO> saveToDatabaseException(SaveToDatabaseException stbException){
        stbException.printStackTrace();
        return new ResponseEntity<>(new ResponseDTO(stbException.getMessage(), null), HttpStatus.INTERNAL_SERVER_ERROR);
    }

    @ExceptionHandler(Exception.class)
    public ResponseEntity<ResponseDTO> anyOtherException(Exception exception){
        exception.printStackTrace();
        return new ResponseEntity<>(new ResponseDTO(exception.getMessage(), null), HttpStatus.INTERNAL_SERVER_ERROR);
    }
}
