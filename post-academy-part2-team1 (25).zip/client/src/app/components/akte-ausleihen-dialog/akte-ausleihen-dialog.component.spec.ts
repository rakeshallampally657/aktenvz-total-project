import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AkteAusleihenDialogComponent } from './akte-ausleihen-dialog.component';

describe('AkteAusleihenDialogComponent', () => {
  let component: AkteAusleihenDialogComponent;
  let fixture: ComponentFixture<AkteAusleihenDialogComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AkteAusleihenDialogComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(AkteAusleihenDialogComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
