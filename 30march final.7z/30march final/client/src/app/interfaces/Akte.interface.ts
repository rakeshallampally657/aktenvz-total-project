
import { GrundstuecksInformation } from "./GrundstuecksInformation.interface";

export interface Akte {
    akteId: number;
    stadtBezirk: string;
    kennZiffer: string;
    aktenBeginn: any;
    letzteHeftnummer: number;
    neueHeftnummer: number;
    almosenKasten: any;
    allGrundstuecksInformationen: GrundstuecksInformation[];
    betreff: string;
    sonstigeAnmerkungen: string;
    letzteAenderung?: any;
    istAusgeliehen?: boolean;
    inPapierkorb?: boolean;
}
