##Refinement 2 (25.01.2022)
- refinement is in some projects the only chance to talk to PO (if PO is on customer side) !
- infos referring borrowing an akte:
  - default aufenthaltsort of an Akte is "Archiv"
  - there is 1 responsible person per akte
  - this 1 Person can borrow the akte = ausleihen-Button
  - or lead it to another one = dritte Person ausleihen - Button
  - in case of 3rd person borrows an Akte, responsible person has to enter 3rd persons email
  - aufenthaltsort = email of the person if it is borrowed
  - Rückgabedatum should be set by the user
  - Wireframe 2.3.7 (=where was the akte at which time) should be in Aufenthaltsort, not in Aktenhistorie

##Planning 2 (18.01.2022)
- Susann is on holiday at friday 21.01.2022 (and maybe thursday afternoon)
- freitext goes to all remark field (betreff, sonstige Anmerkungen, Anmerkung Aufenthaltsort, Aufenthaltsort)
- search has to be possible for combination of all search types, but only exact values
- order search results by Kennziffer, Stadtbezirk, Heftnummer (=combined PK)
- Heftnummer is unique

###Time Estimations Sprint 2
####integration test delete file permanently:
####3
####restore files:
4 <br>
2 <br>
2 <br>

---
####8

---
---

####delete files temporary:
0.5 <br>
1 <br>
1 <br>
2 <br>
3 <br>

---
####7.5

---
---

####search, sort & filter files:
24 <br>
4 <br>
8 <br>
6 <br>
22 <br>
12 <br>
10 <br>
4 <br>
20 <br>
4 <br>
7 <br>

---
####121


=> 139.5h total + learning

##Feedback Review 1 (18.01.2022)
- empty the input mask for Grundstuecksinfo in edit Akte view
- widen the Betreff input to whole page width
- (point from my side) add "in Jahren" to the input line for Grundstuecksinfo

##Retro 1 (18.01.2022)
- plan more time per task for training
- (point from my side) use the daily to check azure

##Refinement 1 (11.01.2022)
###Questions:
create file task:
create login first ?
=> no
create file directory page ?
=> no

    relationship:
        Grundstuecksbezeichnung <-> Vertragsinformation
            => 1-1

    front-end design:
        above creation fields: supposed to be short tables ?
            => yes

        clarify Grundstuecksbezeichnung creation mask
        clarify Vertragsinformation creation mask
            => remove buttons, leave the creation masks on screen

        when and where to create anmerkungAufenthaltsort ?
            => when borrowing a file there should be a new window(not present in wireframes)
            => to input the following data: aufenthaltsort, anmerkungAufenthaltsort
            => default aufenthaltsort: Archiv

        whom to send the notification to ?
            => no1 to send to, it's just raised

        function of freitext search ?
            => go through each field of the akte and look for matches

        create notification missing ?
            => yes, create Aktionbutton("Meldung verfassen") in file information page

        Bemerkung(file creation) = Betreff(file directory)

        Bereich refers to Aktenfields: Stadtbezirk, Kennziffer, ...

    data structure:
        Kennziffer & Stadtbezirk expected values ? + static / dynamic ?
            => simple as possible & static

##Planning 1 (04.01.2022)
###Time Estimations Sprint 1:
####create file:
1h x 3 <br>
4h x 3 <br>
4h x 2 <br>
1h x 2 <br>
1h x 2 <br>
1h <br>
2h <br>
2h

---
####16h / 32h

---
---
####edit existing file:
2h <br>
2h <br>
1h <br>
4h x 2 <br>
4h x 2

---

####13h / 21h

---
---
