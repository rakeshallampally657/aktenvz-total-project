import { Injectable } from '@angular/core';
import { Aenderung } from 'src/app/interfaces/Aenderung.interface';
import { Akte } from 'src/app/interfaces/Akte.interface';
import { Aufenthaltsort } from 'src/app/interfaces/Aufenthaltsort.interface';
import { AusgelieheneAkte } from 'src/app/interfaces/AusgelieheneAkte.interface';
import { AusleihDetails } from 'src/app/interfaces/AusleihDetails.interface';
import { GeloeschteAkte } from 'src/app/interfaces/geloeschte-akte';
import { Meldung } from 'src/app/interfaces/Meldung.interface';
import { MeldungDetails } from 'src/app/interfaces/MeldungDetails.interface';
import { MeldungShort } from 'src/app/interfaces/MeldungShort.interface';
import { RequestService } from './request.service';

@Injectable({
  providedIn: 'root',
})
export class AkteService {
  private akteId: number = NaN;

  constructor(private requestS: RequestService) {}

  borrowFile = async (
    fileId: number,
    borrowDetails: AusleihDetails
  ): Promise<void> => {
    await this.requestS
      .post(`akte/${fileId}/ausleihen`, borrowDetails)
      .toPromise();
  };
  closeNotification = async (notificationId: number): Promise<void> => {
    await this.requestS
      .patch(`akte/meldungen/${notificationId}/schliessen`)
      .toPromise();
  };
  create = async (akte: Akte): Promise<Akte> => {
    const res = await this.requestS
      .post('akte', akte, 'Sie haben eine neue Akte erfolgreich angelegt.')
      .toPromise();
    return res.data;
  };
  createNotification = async (meldung: MeldungDetails): Promise<void> => {
    await this.requestS
      .post(
        'akte/' + this.akteId + '/melden',
        meldung,
        'Sie haben die Meldung erfolgreich gesendet.'
      )
      .toPromise();
  };
  deleteListPermanently = async (akteIdList: number[]): Promise<void> => {
    const res = await this.requestS
      .deleteList(
        'akte/permanently',
        akteIdList,
        'Die Akte(n) wurden erfolgreich entgültig gelöscht.'
      )
      .toPromise();
    return res.data;
  };
  emptyPapierkorb = async (): Promise<void> => {
    await this.requestS
      .deleteList(
        'akte/emptyPapierkorb',
        'Der Papierkorb wurde erfolgreich geleert.'
      )
      .toPromise();
  };
  finishNotification = async (notificationId: number): Promise<void> => {
    await this.requestS
      .patch(
        `akte/meldungen/${notificationId}/abschliessen`,

        'Die Meldung wurde erfolgreich abgeschlossen.'
      )
      .toPromise();
  };
  get = async (akteId: number): Promise<Akte> => {
    const res = await this.requestS.getAllItems('akte/' + akteId).toPromise();
    return res.data;
  };
  getAenderungList = async (): Promise<Aenderung[]> => {
    const res = await this.requestS
      .getAllItems('akte/' + this.akteId + '/historie')
      .toPromise();
    return res.data;
  };
  getAkteId = (): number => this.akteId;
  getAufenthaltsortList = async (): Promise<Aufenthaltsort[]> => {
    const res = await this.requestS
      .getAllItems('akte/' + this.akteId + '/aufenthaltsort')
      .toPromise();
    return res.data;
  };
  getAusgelieheneAkteList = async (): Promise<AusgelieheneAkte[]> => {
    const res = await this.requestS.getAllItems('akte/ausgeliehen').toPromise();
    return res.data;
  };
  getDefaultAkte = (): Akte => {
    return {
      akteId: 0,
      stadtBezirk: '',
      kennZiffer: '',
      aktenBeginn: new Date().toLocaleDateString(),
      letzteHeftnummer: NaN,
      neueHeftnummer: NaN,
      almosenKasten: '',
      allGrundstuecksInformationen: [],
      betreff: '',
      sonstigeAnmerkungen: '',
      letzteAenderung: '',
    };
  };
  getHeftnummer = async (): Promise<number> => {
    const res = await this.requestS
      .getAllItems('akte/letzteHeftnummer')
      .toPromise();
    return res.data;
  };
  getList = async (): Promise<Akte[]> => {
    const res = await this.requestS.getAllItems('akte/excelExport').toPromise();
    return res.data.aktenList;
  };
  getMeldungList = async (): Promise<MeldungShort[]> => {
    const res = await this.requestS
      .getAllItems('akte/' + this.akteId + '/meldungen')
      .toPromise();
    return res.data;
  };
  getMeldungOffenList = async (): Promise<MeldungShort[]> => {
    const res = await this.requestS
      .getAllItems('akte/' + this.akteId + '/meldungen/offen')
      .toPromise();
    return res.data;
  };
  getPapierkorb = async (): Promise<GeloeschteAkte[]> => {
    const res = await this.requestS.getAllItems('akte/papierkorb').toPromise();
    return res.data;
  };
  getVersion = async (aenderungId: number): Promise<Akte> => {
    const res = await this.requestS
      .getAllItems('akte/version/' + aenderungId)
      .toPromise();
    return res.data;
  };
  moveToPapierkorb = async (akteIdList: number[]): Promise<Akte[]> => {
    const res = await this.requestS
      .patch('akte/moveToPapierkorb', akteIdList)
      .toPromise();
    return res.data;
  };
  openNotification = async (notificationId: number): Promise<Meldung> => {
    const res = await this.requestS
      .patch(`akte/meldungen/${notificationId}/oeffnen`)
      .toPromise();
    return res.data;
  };
  restoreFromPapierkorb = async (akteIdList: number[]): Promise<Akte[]> => {
    const res = await this.requestS
      .patch(
        'akte/restoreFromPapierkorb',
        akteIdList,
        'Die Akten wurden erfolgreich wiederhergestellt.'
      )
      .toPromise();
    return res.data;
  };
  returnFileList = async (fileIdList: number[]): Promise<void> => {
    await this.requestS.post('akte/zurueckgeben', fileIdList).toPromise();
  };
  setAkteId = (akteId: number): void => {
    this.akteId = akteId;
  };
  update = async (akte: Akte): Promise<Akte> => {
    const res = await this.requestS.put('akte', akte).toPromise();
    return res.data;
  };
}
