import { Component, OnInit, Input} from '@angular/core';
import { GrundstuecksInformation } from "../../interfaces/GrundstuecksInformation.interface";

@Component({
  selector: 'app-grundstuecks-informationen-display',
  templateUrl: './grundstuecks-informationen-display.component.html',
  styleUrls: ['./grundstuecks-informationen-display.component.scss']
})
export class GrundstuecksInformationenDisplayComponent implements OnInit {
  @Input() tableData: GrundstuecksInformation[] = [];
  tableColumns: string[] = [
    'gemarkung',
    'flur',
    'flurStueck',
    'vertragsBeginn',
    'laufzeit',
    'vertragsNummer',
    'anmerkung'
  ];
  currentEntry: GrundstuecksInformation = {
    grundstuecksInformationId: '',
    gemarkung: '',
    flur: '',
    flurStueck: '',
    vertragsBeginn: '',
    laufzeit: '',
    vertragsNummer: '',
    anmerkung: '',
    isEditable: false
  };
  constructor() {}

  ngOnInit(): void {}


}
