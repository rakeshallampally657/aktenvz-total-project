package com.softwareone.postacademy.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;
import java.time.Instant;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
public class Meldung {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private long meldungId;
    private int zustand;
    private String bereich;
    @Lob
    private String nachricht;
    @ManyToOne(cascade = CascadeType.DETACH)
    @JoinColumn(name="GEMELDET_VON_Fk")
    private Nutzer gemeldetVon;
    @ManyToOne(cascade = CascadeType.DETACH)
    @JoinColumn(name="BEARBEITET_DURCH_Fk")
    private Nutzer bearbeitetDurch;
    @ManyToOne(cascade = CascadeType.DETACH)
    @JoinColumn(name="IN_BEARBEITUNG_VON_Fk")
    private Nutzer inBearbeitungVon;
    private Instant gemeldetAm;
    @ManyToOne(cascade = CascadeType.DETACH)
    @JoinColumn(name="akte_fk")
    private Akte akte;
}