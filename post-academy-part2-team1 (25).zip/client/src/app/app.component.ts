import { Component, OnDestroy, OnInit } from '@angular/core';
import { Subscription } from 'rxjs';
import { LoaderService } from './shared/services/loader/loader.service';
import { UserService } from './shared/services/user.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss'],
})
export class AppComponent implements OnInit, OnDestroy {
  isLoggedIn: boolean = false;

  userSub!: Subscription;

  constructor(private userS: UserService, public loaderS: LoaderService) {}

  ngOnInit() {
    this.setIsLoggedIn();
  }
  setIsLoggedIn = async (): Promise<void> => {
    this.userSub = await this.userS.loggedInUser.subscribe((user) => {
      this.isLoggedIn = !!user;
      /*
      console.log('app:oninit:user from userS:\n', user);
      console.log('app:oninit:isLoggedIn:\n', this.isLoggedIn);
      */
    });
  };

  ngOnDestroy(): void {
    this.userSub.unsubscribe();
  }
}
