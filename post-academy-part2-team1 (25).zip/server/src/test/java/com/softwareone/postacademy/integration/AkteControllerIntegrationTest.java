package com.softwareone.postacademy.integration;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.softwareone.postacademy.PostacademyApplication;
import com.softwareone.postacademy.dto.AkteDTO;
import com.softwareone.postacademy.model.GrundstuecksInformation;
import org.hamcrest.Matchers;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.MethodSorters;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.context.TestPropertySource;
import org.springframework.test.context.jdbc.Sql;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockHttpServletRequestBuilder;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;

import java.time.Instant;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
@RunWith(SpringRunner.class)
@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT,classes = PostacademyApplication.class)
@TestPropertySource(locations = "classpath:application-test.properties")
@AutoConfigureMockMvc
public class AkteControllerIntegrationTest {

    @Autowired
    private MockMvc mockMvc; // for sending the http request

    /* The test.sql is the file that contains  akten information i.e., akteId=1 and akteId=2 and
    akteId=[3,4,5,6] is present in the recycle bin
    which is loaded in the in-memory database using h2 as the datasource*/
    @Sql({"/test.sql"})
    @Test
    public void _allAktenFetchingTest() throws Exception
    {
        // The akten information is loaded in the in-memory database using test.sql script
        //Getting all the akten information and verfying is the akteId is present
        mockMvc.perform( MockMvcRequestBuilders
                        .get("/api/akte")
                        .accept(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andExpect(MockMvcResultMatchers.jsonPath("$.data").exists()) //checking whether akte exists
                .andExpect(MockMvcResultMatchers.jsonPath("$.data[*].akteId").isNotEmpty()); // Ensuring akteId is not empty
    }

    @Test
    public void getAkteByIdTest() throws Exception{
        // The akten information is loaded in the in-memory database using test.sql script
        mockMvc.perform( MockMvcRequestBuilders
                        .get("/api/akte/2")
                        .accept(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andExpect(MockMvcResultMatchers.jsonPath("$.data.akteId").value(2)); //Verifying whether the obtained akteId=2
    }

    @Test
    public void createNewAkteTest() throws Exception {
        //Created the akte data object which will be passed as the request body for post http request
        AkteDTO akte= new AkteDTO(50L,3L,13L,Instant.parse("2020-1-7T10:15:30.00Z"),
                2L,3L,false,"third akte", "other docs", false,false, null,null);

        ObjectMapper jsonSerializer = new ObjectMapper();
        //converting java object into json
        String akteToBeCreatedJson = jsonSerializer.writeValueAsString(akte);

        mockMvc.perform( MockMvcRequestBuilders
                        .post("/api/akte")
                        .content(akteToBeCreatedJson)
                        .contentType(MediaType.APPLICATION_JSON)
                        .accept(MediaType.APPLICATION_JSON))
                .andExpect(status().isCreated())
                .andExpect(MockMvcResultMatchers.jsonPath("$.data.akteId").exists())
                .andExpect(MockMvcResultMatchers.jsonPath("$.data.stadtBezirk").value(3L))
                .andExpect(MockMvcResultMatchers.jsonPath("$.data.kennZiffer").value(13L))
                .andExpect(MockMvcResultMatchers.jsonPath("$.data.almosenKasten").value(false))
                .andExpect(MockMvcResultMatchers.jsonPath("$.data.betreff").value("third akte"))
                .andExpect(MockMvcResultMatchers.jsonPath("$.data.sonstigeAnmerkungen").value("other docs"));
    }

    @Test
    public void findLastHeftNumberTest() throws Exception{
        // The akten information is loaded in the in-memory database using test.sql script
        mockMvc.perform( MockMvcRequestBuilders
                        .get("/api/akte/letzteHeftnummer")
                        .accept(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                //Verifying whether the obtained LastheftNumberValue=3 because lastHeftNumber in this inMemory database is 3
                .andExpect(MockMvcResultMatchers.jsonPath("$.data").exists());
    }

    @Test
    public void updateAkteAndGrundstuecksInformationTest() throws Exception {

        //The akte that has to be updated , as akte with akteId=3 is already present in in-memory h2 database, so modifying its data
        AkteDTO akte= new AkteDTO(1L,30L,33L,Instant.parse("2020-1-7T10:15:30.00Z"),
                10L,11L,false,"first akte", "other docs",false,false, null,null);

        //Adding GrundstuecksInformation to akte
        GrundstuecksInformation grundstuecksInformation = new GrundstuecksInformation(1L,20L,34L,"34/52"
                , Instant.parse("2020-1-7T10:15:30.00Z"),4L, "345/952", "The akten 1st contract");

        // Creating list of grundstuecksInformationen
        List<GrundstuecksInformation> grundstuecksInformationenList = List.of(grundstuecksInformation);

        // setting the grundstuecksInformationen to the akte that is being fetched
        akte.setAllGrundstuecksInformationen(grundstuecksInformationenList);

        ObjectMapper jsonSerializer = new ObjectMapper();
        //converting java object into json
        String akteToBeUpdatedJson = jsonSerializer.writeValueAsString(akte);

        mockMvc.perform( MockMvcRequestBuilders
                        .put("/api/akte")
                        .content(akteToBeUpdatedJson)
                        .contentType(MediaType.APPLICATION_JSON)
                        .accept(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andExpect(MockMvcResultMatchers.jsonPath("$.data.akteId").value(1L))
                .andExpect(MockMvcResultMatchers.jsonPath("$.data.stadtBezirk").value(30L))
                .andExpect(MockMvcResultMatchers.jsonPath("$.data.kennZiffer").value(33L))
                .andExpect(MockMvcResultMatchers.jsonPath("$.data.letzteHeftnummer").value(10L))
                .andExpect(MockMvcResultMatchers.jsonPath("$.data.neueHeftnummer").value(11L))
                .andExpect(MockMvcResultMatchers.jsonPath("$.data.almosenKasten").value(false))
                .andExpect(MockMvcResultMatchers.jsonPath("$.data.betreff").value("first akte"))
                .andExpect(MockMvcResultMatchers.jsonPath("$.data.sonstigeAnmerkungen").value("other docs"))
                .andExpect(MockMvcResultMatchers.jsonPath("$.data.allGrundstuecksInformationen[0].gemarkung").value(20L))
                .andExpect(MockMvcResultMatchers.jsonPath("$.data.allGrundstuecksInformationen[0].flur").value(34L))
                .andExpect(MockMvcResultMatchers.jsonPath("$.data.allGrundstuecksInformationen[0].flurStueck").value("34/52"))
                .andExpect(MockMvcResultMatchers.jsonPath("$.data.allGrundstuecksInformationen[0].laufzeit").value(4L))
                .andExpect(MockMvcResultMatchers.jsonPath("$.data.allGrundstuecksInformationen[0].vertragsNummer").value("345/952"))
                .andExpect(MockMvcResultMatchers.jsonPath("$.data.allGrundstuecksInformationen[0].anmerkung").value("The akten 1st contract"));
    }

    @Test
    public void updateNonExistingAkte() throws Exception {

        //The akte with akteId=10L is not present in h2 database, when trying to update it , it should throw an error
        AkteDTO akte= new AkteDTO(10L,25L,32L, Instant.parse("2020-1-7T10:15:30.00Z"),
                10L,11L,false,"first akte", "other docs",false,false, null,null);

        ObjectMapper jsonSerializer = new ObjectMapper();
        //converting java object into json
        String akteToBeUpdatedJson = jsonSerializer.writeValueAsString(akte);

        mockMvc.perform( MockMvcRequestBuilders
                        .put("/api/akte")
                        .content(akteToBeUpdatedJson)
                        .contentType(MediaType.APPLICATION_JSON)
                        .accept(MediaType.APPLICATION_JSON))
                .andExpect(status().is4xxClientError())// it throws error when trying to update non-existing akte
                .andExpect(MockMvcResultMatchers.jsonPath("$.data.akteId").doesNotExist());
    }


    @Test
    public void deleteTwoAktenPermanentlyFromRecyclebinSuccess() throws Exception {

        //Considering that akten with akteId=5 and akteId=6 is already in recycle bin
        List<Long> aktenIds = new ArrayList<>();
        aktenIds.add(5L);
        aktenIds.add(6L);

        ObjectMapper jsonSerializer = new ObjectMapper();
        //converting java object into json
        String aktenToBeDeletedJson = jsonSerializer.writeValueAsString(aktenIds);

        mockMvc.perform( MockMvcRequestBuilders
                        .delete("/api/akte/permanently")
                        .content(aktenToBeDeletedJson)
                        .contentType(MediaType.APPLICATION_JSON)
                        .accept(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andDo(print());
    }


    @Test
    public void deleteTwoAktenPermanentlyFromRecyclebinFailure() throws Exception {

        //Considering that akten with akteId=150 and akteId=151 is not present in recycle bin, so when tried to delete it should throw an error
        List<Long> aktenIds = new ArrayList<>();
        aktenIds.add(150L);
        aktenIds.add(151L);

        ObjectMapper jsonSerializer = new ObjectMapper();
        //converting java object into json
        String aktenToBeDeletedJson = jsonSerializer.writeValueAsString(aktenIds);

        mockMvc.perform( MockMvcRequestBuilders
                        .delete("/api/akte/permanently")
                        .content(aktenToBeDeletedJson)
                        .contentType(MediaType.APPLICATION_JSON)
                        .accept(MediaType.APPLICATION_JSON))
                .andExpect(status().is4xxClientError())
                .andDo(print());
    }


    @Test
    public void restoreTwoAktenFromRecyclebinSuccess() throws Exception {

        //Considering that akten with akteId=3 and akteId=4 is  present in recycle bin
        List<Long> aktenIds = new ArrayList<>();
        aktenIds.add(3L);
        aktenIds.add(4L);

        ObjectMapper jsonSerializer = new ObjectMapper();
        //converting java object into json
        String aktenToBeRestoredJson = jsonSerializer.writeValueAsString(aktenIds);

        mockMvc.perform( MockMvcRequestBuilders
                        .patch("/api/akte/restoreFromPapierkorb")
                        .content(aktenToBeRestoredJson)
                        .contentType(MediaType.APPLICATION_JSON)
                        .accept(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andDo(print());
    }


    @Test
    public void restoreTwoAktenFromRecyclebinFailure() throws Exception {

        //Considering that akten with akteId=1 and akteId=2 is not present in recycle bin, so when tried to restore it throws an error
        List<Long> aktenIds = new ArrayList<>();
        aktenIds.add(1L);
        aktenIds.add(2L);

        ObjectMapper jsonSerializer = new ObjectMapper();
        //converting java object into json
        String aktenToBeRestoredJson = jsonSerializer.writeValueAsString(aktenIds);

        mockMvc.perform( MockMvcRequestBuilders
                        .patch("/api/akte/restoreFromPapierkorb")
                        .content(aktenToBeRestoredJson)
                        .contentType(MediaType.APPLICATION_JSON)
                        .accept(MediaType.APPLICATION_JSON))
                .andExpect(status().is4xxClientError())
                .andDo(print());
    }


    @Test
    public void temporaryDeletionByIdSucess() throws Exception {

        //Considering that akte with akteId=7 is present in the database
        List<Long> aktenIds = new ArrayList<>();
        aktenIds.add(7L);

        ObjectMapper jsonSerializer = new ObjectMapper();
        //converting java object into json
        String aktenToBeTemporarilyDeletedJson = jsonSerializer.writeValueAsString(aktenIds);

        mockMvc.perform( MockMvcRequestBuilders
                        .patch("/api/akte/moveToPapierkorb")
                        .content(aktenToBeTemporarilyDeletedJson)
                        .contentType(MediaType.APPLICATION_JSON)
                        .accept(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andDo(print());
    }


    @Test
    public void temporaryDeletionByIdFailure() throws Exception {

        //Considering that akten with akteId=170 is not present in the database
        List<Long> aktenIds = new ArrayList<>();
        aktenIds.add(170L);

        ObjectMapper jsonSerializer = new ObjectMapper();
        //converting java object into json
        String aktenToBeTemporarilyDeletedJson = jsonSerializer.writeValueAsString(aktenIds);

        mockMvc.perform( MockMvcRequestBuilders
                        .patch("/api/akte/moveToPapierkorb")
                        .content(aktenToBeTemporarilyDeletedJson)
                        .contentType(MediaType.APPLICATION_JSON)
                        .accept(MediaType.APPLICATION_JSON))
                .andExpect(status().is4xxClientError())
                .andDo(print());
    }

    @Test
    public void searchForAnAkteByStadtBezirkAndBetreffContains_akte_() throws Exception {
        // considering there are akten with stadtbezirk = 3 and betreff contains akte

        MockHttpServletRequestBuilder getRequest = MockMvcRequestBuilders
                .get("/api/akte/filterByFields")
                .contentType(MediaType.APPLICATION_JSON)
                .param("stadtbezirk", "4")
                .param("freitext", "akte");
        mockMvc.perform(getRequest).andExpect(status().isOk())
                .andExpect(jsonPath("$.data.aktenList", Matchers.hasSize(1)))
                .andExpect(jsonPath("$.data.aktenList[0].stadtBezirk").value(4));
    }
}