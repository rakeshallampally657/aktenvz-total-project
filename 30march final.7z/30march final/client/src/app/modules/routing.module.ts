import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { NeueAkteViewComponent } from '../views/neue-akte-view/neue-akte-view.component';
import { AktenVerzeichnisViewComponent } from '../views/akten-verzeichnis-view/akten-verzeichnis-view.component';
import { NotFoundViewComponent } from '../views/not-found-view/not-found-view.component';
import { AkteBearbeitenViewComponent } from '../views/akte-bearbeiten-view/akte-bearbeiten-view.component';
import { AddDummyDataViewComponent } from '../views/add-dummy-data-view/add-dummy-data-view.component';
import { DeleteAllDataViewComponent } from '../views/delete-all-data-view/delete-all-data-view.component';
import { PapierkorbViewComponent } from '../views/papierkorb-view/papierkorb-view.component';
import { AusgelieheneAktenViewComponent } from '../views/ausgeliehene-akten-view/ausgeliehene-akten-view.component';
import { AktenDetailsViewComponent } from '../views/akten-details-view/akten-details-view.component';
import { AktenMeldungenViewComponent } from '../views/akten-meldungen-view/akten-meldungen-view.component';
import { MeldungViewComponent } from '../views/meldung-view/meldung-view.component';
import { AktenInformationenViewComponent } from '../views/akten-informationen-view/akten-informationen-view.component';
import { AktenHistorieViewComponent } from '../views/akten-historie-view/akten-historie-view.component';
import { AktenAufenthaltsorteViewComponent } from '../views/akten-aufenthaltsorte-view/akten-aufenthaltsorte-view.component';
import { MeldungenTabComponent } from '../views/meldungen-tab/meldungen-tab.component';
import { AdministrationViewComponent } from '../views/administration-view/administration-view.component';
import { NutzerBearbeitenViewComponent } from '../views/nutzer-bearbeiten-view/nutzer-bearbeiten-view.component';
import { AuthGuardService } from '../shared/services/auth-guard.service';
import { AuthViewComponent } from '../views/auth-view/auth-view.component';
import { LoginComponent } from '../views/auth-view/login/login.component';
import { RegisterComponent } from '../views/auth-view/register/register.component';
import { NewPasswordComponent } from '../views/auth-view/new-password/new-password.component';
import { NavComponent } from '../components/nav/nav.component';
import { RequestResetLinkComponent } from "../views/auth-view/request-reset-link/request-reset-link.component";

export const routingComponents = [
  AktenVerzeichnisViewComponent,
  NeueAkteViewComponent,
  AktenDetailsViewComponent,
  AkteBearbeitenViewComponent,
  AusgelieheneAktenViewComponent,
  PapierkorbViewComponent,
  AktenMeldungenViewComponent,
  MeldungViewComponent,
  AdministrationViewComponent,
  NutzerBearbeitenViewComponent,
  LoginComponent,
  RegisterComponent,
  RequestResetLinkComponent,
  NewPasswordComponent,

  AddDummyDataViewComponent,
  DeleteAllDataViewComponent,
  NotFoundViewComponent,
];

const routes: Routes = [
  { path: '', redirectTo: '/auth/login', pathMatch: 'full' },
  {
    path: 'auth',
    component: AuthViewComponent,
    children: [
      {
        path: 'login',
        component: LoginComponent,
      },
      {
        path: 'register',
        component: RegisterComponent,
      },
      {
        path: 'link-anfragen',
        component: RequestResetLinkComponent,
      },
      {
        path: 'neues-passwort-festlegen/:uuid',
        component: NewPasswordComponent,
      },
    ],
  },
  {
    path: 'app',
    component: NavComponent,
    children: [
      { path: 'akten-verzeichnis', component: AktenVerzeichnisViewComponent },
      { path: 'akte-anlegen', component: NeueAkteViewComponent },
      {
        path: 'akte-bearbeiten/:akteId',
        component: AkteBearbeitenViewComponent,
      },
      {
        path: 'akten-verzeichnis/:akteId',
        component: AktenDetailsViewComponent,
        children: [
          {
            path: 'informationen',
            component: AktenInformationenViewComponent,
          },
          {
            path: 'meldungen',
            component: MeldungenTabComponent,
          },
          {
            path: 'aufenthaltsorte',
            component: AktenAufenthaltsorteViewComponent,
          },
          {
            path: 'historie',
            component: AktenHistorieViewComponent,
          },
        ],
      },
      { path: 'ausgeliehene-akten', component: AusgelieheneAktenViewComponent },
      {
        path: 'akten-meldungen',
        component: AktenMeldungenViewComponent,
      },
      {
        path: 'akten-meldungen/:meldungId',
        component: MeldungViewComponent,
      },
      {
        path: 'papierkorb',
        component: PapierkorbViewComponent,
      },
      {
        path: 'administration',
        canActivate: [AuthGuardService],
        component: AdministrationViewComponent,
      },
      {
        path: 'administration/nutzer-bearbeiten/:nutzerId',
        canActivate: [AuthGuardService],
        component: NutzerBearbeitenViewComponent,
      },
      {
        path: 'administration/nutzer-erstellen',
        canActivate: [AuthGuardService],
        component: NutzerBearbeitenViewComponent,
      },
      {
        path: 'dev-tools/add-dummy-data',
        component: AddDummyDataViewComponent,
      },
      { path: 'dev-tools/delete-all', component: DeleteAllDataViewComponent },
    ],
  },

  { path: '**', component: NotFoundViewComponent },
];

@NgModule({
  imports: [RouterModule.forRoot(routes /* {useHash: true} */)],
  exports: [RouterModule],
})
export class RoutingModule {}
