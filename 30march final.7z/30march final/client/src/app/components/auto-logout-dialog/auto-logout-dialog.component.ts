import { Component, OnDestroy, OnInit } from '@angular/core';
import { MatDialogRef } from '@angular/material/dialog';

@Component({
  selector: 'app-auto-logout-dialog',
  templateUrl: './auto-logout-dialog.component.html',
  styleUrls: ['./auto-logout-dialog.component.scss'],
})
export class AutoLogoutDialogComponent implements OnInit, OnDestroy {
  timer: number = 30;
  private _intervallRef: any;
  constructor(public dialogRef: MatDialogRef<AutoLogoutDialogComponent>) {}

  ngOnInit(): void {
    this.init();
  }
  init() {
    this._intervallRef = setInterval(() => {
      --this.timer;
      if (this.timer <= 0) {
        this.closeDialog(0);
      }
    }, 1000);
  }
  closeDialog(res: number) {
    this.dialogRef.close(res);
  }

  ngOnDestroy(): void {
    clearInterval(this._intervallRef);
  }
}
