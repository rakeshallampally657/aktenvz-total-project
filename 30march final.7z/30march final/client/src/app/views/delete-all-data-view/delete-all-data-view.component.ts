import { Component, OnInit } from '@angular/core';
import { RequestService } from 'src/app/shared/services/request.service';

@Component({
  selector: 'app-delete-all-data-view',
  templateUrl: './delete-all-data-view.component.html',
  styleUrls: ['./delete-all-data-view.component.scss'],
})
export class DeleteAllDataViewComponent implements OnInit {
  constructor(private requestS: RequestService) {
    console.log('delete-all-data-view contructor fired');
    this.requestS.deleteList('akte/all');
  }
  
  ngOnInit(): void {}
}
