package com.softwareone.postacademy.config;

import com.softwareone.postacademy.filter.AuthTokenFilter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpMethod;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.method.configuration.EnableGlobalMethodSecurity;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;

@Configuration
@EnableWebSecurity
@EnableGlobalMethodSecurity(prePostEnabled = true)
public class SecurityConfig extends WebSecurityConfigurerAdapter {

    @Autowired
    private UserDetailsService userDetailsService;

    @Autowired
    private BCryptPasswordEncoder passwordEncoder;

    @Autowired
    private InvalidNutzerAuthenticationEntryPoint authenticationEntryPoint;

    @Autowired
    private AuthTokenFilter securityFilter;


    @Override
    protected void configure(AuthenticationManagerBuilder auth) throws Exception {
        auth.userDetailsService(userDetailsService)
                .passwordEncoder(passwordEncoder);
    }

    @Override
    @Bean
    protected AuthenticationManager authenticationManager() throws Exception {
        return super.authenticationManager();
    }

    @Override
    protected void configure(HttpSecurity http) throws Exception {
        http.cors().and().csrf().disable()
                .exceptionHandling()
                .authenticationEntryPoint(authenticationEntryPoint)
                .and()
                .sessionManagement()
                .sessionCreationPolicy(SessionCreationPolicy.STATELESS)
                .and()
                .authorizeRequests()
                .antMatchers(
                        "/v3/api-docs/**",
                        "/swagger-ui/**",
                        "/swagger-resources/**",
                        "/swagger-ui.html",
                        "/*",
                        "/assets/*",
                        "/api/nutzer/login",
                        "/api/nutzer/logout",
                        "/api/nutzer/resetPassword",
                        "/api/nutzer/password"
                ).permitAll()
                .antMatchers(HttpMethod.PATCH, "/api/nutzer/refresh").permitAll()
                .antMatchers(HttpMethod.POST, "/api/nutzer").permitAll()
                .antMatchers(HttpMethod.PUT, "/api/akte").hasAnyAuthority("AKTE_BEARBEITEN", "ADMIN")
                .antMatchers("/api/akte/{akteId}/ausleihen", "/api/akte/zurueckgeben").hasAnyAuthority("AKTE_AUSLEIHEN", "ADMIN")
                .antMatchers("/api/akte/moveToPapierkorb", "/api/akte/restoreFromPapierkorb").hasAnyAuthority("AKTE_LOESCHEN", "ADMIN")
                .antMatchers("/api/akte/{akteId}/melden", "/api/akte/meldungen/{meldungId}/schliessen").hasAnyAuthority("AKTE_MELDUNGEN_VERFASSEN", "ADMIN")
                .antMatchers(HttpMethod.GET, "/api/akte/{akteId}/meldungen/**").hasAnyAuthority("EXCEL_EXPORT", "ADMIN", "AKTE_BEARBEITEN", "AKTE_AUSLEIHEN",
                        "AKTE_LOESCHEN", "AKTE_MELDUNGEN_VERFASSEN", "USER")
                .antMatchers(HttpMethod.GET, "/api/akte/meldungen/**").hasAnyAuthority("EXCEL_EXPORT", "ADMIN", "AKTE_BEARBEITEN", "AKTE_AUSLEIHEN",
                        "AKTE_LOESCHEN", "AKTE_MELDUNGEN_VERFASSEN", "USER")
                .antMatchers("/api/akte/meldungen/{meldungId}/abschliessen").hasAnyAuthority("ADMIN", "AKTE_BEARBEITEN")
                .antMatchers("/api/akte/excelExport").hasAnyAuthority("EXCEL_EXPORT", "ADMIN")
                .antMatchers(HttpMethod.GET, "/api/akte/**", "/api/nutzer/**")
                .hasAnyAuthority("EXCEL_EXPORT", "ADMIN", "AKTE_BEARBEITEN", "AKTE_AUSLEIHEN",
                        "AKTE_LOESCHEN", "AKTE_MELDUNGEN_VERFASSEN", "USER")
                .anyRequest().hasAuthority("ADMIN")
                .and()

                // register filter for 2nd request onwards
                .addFilterBefore(securityFilter, UsernamePasswordAuthenticationFilter.class);

    }
}
