import { Directive, ElementRef, HostBinding, OnInit } from '@angular/core';

@Directive({
  selector: '[appScrollHeight]',
})
export class ScrollHeightDirective implements OnInit {
  @HostBinding('style.height') height: string = '';
  constructor(private elRef: ElementRef) {}

  ngOnInit(): void {
      /* this.height = this.elRef.nativeElement.scrollHeight + 'px'; */
      console.log('this:\n', this);
      console.log('this.height:\n', this.height);
      console.log('this.elRef.nativeElement.scrollHeight:\n', this.elRef.nativeElement.scrollHeight);
  }
}
