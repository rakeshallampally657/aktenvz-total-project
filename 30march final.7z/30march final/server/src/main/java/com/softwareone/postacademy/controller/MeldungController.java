package com.softwareone.postacademy.controller;

import com.softwareone.postacademy.dto.*;
import com.softwareone.postacademy.service.MeldungService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@CrossOrigin(origins = "http://localhost:4200",allowCredentials = "true")
@RequestMapping("/api")
public class MeldungController {

    @Autowired
    private MeldungService meldungService;

    @PostMapping(value = "/akte/{akteId}/melden", produces = {MediaType.APPLICATION_JSON_VALUE, MediaType.APPLICATION_XML_VALUE},
            consumes = {MediaType.APPLICATION_JSON_VALUE, MediaType.APPLICATION_XML_VALUE})
    public ResponseEntity<ResponseDTO> meldungErstellen(@RequestBody MeldungErstellenDTO meldungErstellenDTO, @PathVariable("akteId") Long akteId){
            MeldungDTO meldungDTO=meldungService.meldungErstellen(meldungErstellenDTO, akteId);
            return new ResponseEntity<>(new ResponseDTO("Akte notification created", meldungDTO),
                    HttpStatus.CREATED); //201 content created successfully
    }

    @GetMapping(value = "/akte/{akteId}/meldungen", produces = {MediaType.APPLICATION_JSON_VALUE, MediaType.APPLICATION_XML_VALUE})
    public ResponseEntity<ResponseDTO> getAllMeldungen(@PathVariable("akteId") Long akteId) {
            List<MeldungDTO> meldungDTOList = meldungService.getAllMeldungenOfAkte(akteId);
            return new ResponseEntity<>(new ResponseDTO("The list of all meldungen", meldungDTOList), HttpStatus.OK); //200 for sucess
    }

    @GetMapping(value = "/akte/meldungen", produces = {MediaType.APPLICATION_JSON_VALUE, MediaType.APPLICATION_XML_VALUE})
    public ResponseEntity<ResponseDTO> getMeldungenOfAllAkten() {
            List<MeldungDTO> meldungDTOList = meldungService.getMeldungenOfAllAkten();
            return new ResponseEntity<>(new ResponseDTO("The list of all meldungen of all akten", meldungDTOList), HttpStatus.OK); //200 for sucess
    }


    @GetMapping(value = "/akte/{akteId}/meldungen/offen", produces = {MediaType.APPLICATION_JSON_VALUE, MediaType.APPLICATION_XML_VALUE})
    public ResponseEntity<ResponseDTO> getAllOpenMeldungenOfAkte(@PathVariable("akteId") Long akteId) {
            List<MeldungDTO> meldungDTOList = meldungService.getAllOpenMeldungenOfAkte(akteId);
            return new ResponseEntity<>(new ResponseDTO("The list of Meldungen of akte", meldungDTOList), HttpStatus.OK); //200 for sucess
    }

    @GetMapping(value = "/akte/meldungen/offen", produces = {MediaType.APPLICATION_JSON_VALUE, MediaType.APPLICATION_XML_VALUE})
    public ResponseEntity<ResponseDTO> getAllOpenMeldungenOfAllAkten() {
            List<MeldungDTO> meldungDTOList = meldungService.getAllOpenMeldungenOfAllAkten();
            return new ResponseEntity<>(new ResponseDTO("The list of Meldungen of all akte", meldungDTOList), HttpStatus.OK); //200 for sucess
    }

    @PatchMapping(value = "/akte/meldungen/{meldungId}/oeffnen", produces = {MediaType.APPLICATION_JSON_VALUE, MediaType.APPLICATION_XML_VALUE})
    public ResponseEntity<ResponseDTO> meldungOeffnen(@PathVariable("meldungId") Long meldungId) {
            MeldungOeffnenResponse meldungOeffnenResponse= meldungService.meldungOeffnen(meldungId);
            return new ResponseEntity<>(new ResponseDTO("The Meldung is opened", meldungOeffnenResponse), HttpStatus.OK); //200 for sucess
    }

    @PatchMapping(value = "/akte/meldungen/{meldungId}/schliessen", produces = {MediaType.APPLICATION_JSON_VALUE, MediaType.APPLICATION_XML_VALUE})
    public ResponseEntity<ResponseDTO> meldungAbbrechen(@PathVariable("meldungId") Long meldungId){
            String msg= meldungService.meldungAbbrechen(meldungId);
            return new ResponseEntity<>(new ResponseDTO(msg, null), HttpStatus.OK); //200 for sucess
    }

    @PatchMapping(value = "/akte/meldungen/{meldungId}/abschliessen", produces = {MediaType.APPLICATION_JSON_VALUE, MediaType.APPLICATION_XML_VALUE})
    public ResponseEntity<ResponseDTO> meldungAbschliessen(@PathVariable("meldungId") Long meldungId){
            String msg= meldungService.meldungAbschliessen(meldungId);
            return new ResponseEntity<>(new ResponseDTO(msg, null), HttpStatus.OK); //200 for sucess
    }
}
