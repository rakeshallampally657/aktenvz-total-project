package com.softwareone.postacademy.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@AllArgsConstructor
@NoArgsConstructor
@Data
public class NewPasswortDTO {
    private String passwordResetToken;
    private String password;
}
