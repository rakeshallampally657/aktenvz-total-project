package com.softwareone.postacademy.unit;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.softwareone.postacademy.controller.AufenthaltsortAenderungenController;
import com.softwareone.postacademy.dto.AkteAusleihenDTO;
import com.softwareone.postacademy.dto.AkteDTO;
import com.softwareone.postacademy.dto.AufenthaltsortDTO;
import com.softwareone.postacademy.dto.AusgelieheneAkteDTO;
import com.softwareone.postacademy.service.AufenthaltsortAenderungenService;
import org.hamcrest.Matchers;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockHttpServletRequestBuilder;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;


import java.util.List;

import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@RunWith(SpringRunner.class)
@WebMvcTest(value = AufenthaltsortAenderungenController.class)
public class AufenthaltsortAenderungenControllerUnitTest {
    private static String baseUrl="/api";
    @Autowired
    private MockMvc mockMvc;
    @Autowired
    private ObjectMapper jsonSerializer;
    @MockBean
    private AufenthaltsortAenderungenService aufenthaltsortAenderungenService;

    @Test
    public void getAllAufenthaltsortenOfAkteTest() throws Exception{
        Long akteId=1L;

        // Considering that getAllAufenthaltsortenOfAkte from service method returns 2 locations with akteId=1
        AufenthaltsortDTO akte1 = new AufenthaltsortDTO(null,"true","text");
        AufenthaltsortDTO akte2 = new AufenthaltsortDTO(null,"false","text");

        // List of akten that are returned form service class
        List<AufenthaltsortDTO> expectedAkten = List.of(akte1, akte2);


        // defining the behaciour through stubbing
        Mockito.when(aufenthaltsortAenderungenService.getAllAufenthaltsortenOfAkte(akteId)).thenReturn(expectedAkten);

        // verifying the obtained values
        mockMvc.perform(MockMvcRequestBuilders
                        .get(baseUrl+"/akte/1/aufenthaltsort")
                        .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andExpect(MockMvcResultMatchers.jsonPath("$.data", Matchers.hasSize(2)))
                .andExpect(MockMvcResultMatchers.jsonPath("$.data[0].aufenthaltsort").value(true))
                .andExpect(MockMvcResultMatchers.jsonPath("$.data[1].aufenthaltsort").value(false));

    }


    @Test
    public void getLatestAufenthaltsortOfAllBorrowedAktenTest() throws Exception{

        // Considering that getAllAufenthaltsortenOfAkte from service method returns 2 records i.e., akteId=1 and akteId=2
        AusgelieheneAkteDTO akte1= new AusgelieheneAkteDTO(1L,1L,1L,1L,
                "text", "rakesh","ilya",null);
        AusgelieheneAkteDTO akte2= new AusgelieheneAkteDTO(2L,2L,3L,2L,
                "text", "rakesh","ilya",null);

        // List of akten that are returned form service class
        List<AusgelieheneAkteDTO> expectedBorrowedAkten = List.of(akte1, akte2);


        // defining the behaciour through stubbing
        Mockito.when(aufenthaltsortAenderungenService.getLatestAufenthaltsortOfAllBorrowedAkten()).thenReturn(expectedBorrowedAkten);

        // verifying the obtained values
        mockMvc.perform(MockMvcRequestBuilders
                        .get(baseUrl+"/akte/ausgeliehen")
                        .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andExpect(MockMvcResultMatchers.jsonPath("$.data", Matchers.hasSize(2)))
                .andExpect(MockMvcResultMatchers.jsonPath("$.data[0].akteId").value(1))
                .andExpect(MockMvcResultMatchers.jsonPath("$.data[1].akteId").value(2));
    }

    @Test
    public void ausleihenAkteTest() throws Exception {

        // considering that akteId=100L is present in database and lending it
        Long akteId = 100L;

        // mocking the akte data that is being lent
        AkteAusleihenDTO akteAusleihenDTO = new AkteAusleihenDTO( "ilya", "rakesh@gmail.com",
                null, "free text");

        //response body of akten that is being lent
        AusgelieheneAkteDTO ausgelieheneAkteDTO = new AusgelieheneAkteDTO(akteId, 1L, 1L, 1L,
                "text",  "rakesh", "ilya", null);

        // setting the behavior by stubbing, so any of the AKteDTO class is passed as the argument it retuns the akte
        Mockito.when(aufenthaltsortAenderungenService.ausleihenAkte(Mockito.any(AkteAusleihenDTO.class), Mockito.anyLong())).thenReturn(ausgelieheneAkteDTO);

        // Using object mapper to convert java object to json
        String akteToBeLent = jsonSerializer.writeValueAsString(akteAusleihenDTO);

        //sending the http request
        MockHttpServletRequestBuilder postRequest = MockMvcRequestBuilders.post(
                baseUrl + "/akte/100/ausleihen").contentType(MediaType.APPLICATION_JSON).content(akteToBeLent);

        // verifying the obtained data
        mockMvc.perform(postRequest).andExpect(status().isCreated())
                .andExpect(MockMvcResultMatchers.jsonPath("$.data.akteId").exists());
    }

    @Test
    public void returnABorrowedAkteSuccessfulTest() throws Exception{
        Mockito.when(aufenthaltsortAenderungenService.zurueckgebenAkten(List.of(1L)))
                .thenReturn(null);

        MockHttpServletRequestBuilder postRequest = MockMvcRequestBuilders.post(
                baseUrl + "/akte/zurueckgeben")
                .contentType(MediaType.APPLICATION_JSON)
                .content(jsonSerializer.writeValueAsString(List.of(1)));

        mockMvc.perform(postRequest)
                .andExpect(status().isCreated())
                .andExpect(jsonPath("$.data").doesNotExist());
    }

    @Test
    public void returnABorrowedAkteErrorAkteNotFoundTest() throws Exception{
        Mockito.when(aufenthaltsortAenderungenService.zurueckgebenAkten(List.of(1L)))
                .thenReturn(List.of(1L));

        MockHttpServletRequestBuilder postRequest = MockMvcRequestBuilders.post(
                        baseUrl + "/akte/zurueckgeben")
                .contentType(MediaType.APPLICATION_JSON)
                .content(jsonSerializer.writeValueAsString(List.of(1)));

        mockMvc.perform(postRequest)
                .andExpect(status().is5xxServerError())
                .andExpect(jsonPath("$.data", Matchers.hasSize(1)))
                .andExpect(jsonPath("$.data[0]").value(1L));
    }

}
