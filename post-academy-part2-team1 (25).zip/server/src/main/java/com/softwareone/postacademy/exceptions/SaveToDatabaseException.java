package com.softwareone.postacademy.exceptions;

public class SaveToDatabaseException extends RuntimeException{

    public SaveToDatabaseException(String message){
        super(message);
    }
}
