import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DeleteAllDataViewComponent } from './delete-all-data-view.component';

describe('DeleteAllDataViewComponent', () => {
  let component: DeleteAllDataViewComponent;
  let fixture: ComponentFixture<DeleteAllDataViewComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ DeleteAllDataViewComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(DeleteAllDataViewComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
