export interface GrundstuecksInformation {
    grundstuecksInformationId: string;
    gemarkung: string;
    flur: string;
    flurStueck: string;
    vertragsBeginn: any;
    laufzeit: string;
    vertragsNummer: string;
    anmerkung: string;
    isEditable: boolean;
}
