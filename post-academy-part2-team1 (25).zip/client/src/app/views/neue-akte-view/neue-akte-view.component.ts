import { Component, HostListener, ViewChild } from '@angular/core';
import { Akte } from 'src/app/interfaces/Akte.interface';
import { GrundstuecksInformation } from 'src/app/interfaces/GrundstuecksInformation.interface';
import { Router } from '@angular/router';
import { NgForm } from '@angular/forms';
import { StorageService } from 'src/app/shared/services/storage.service';
import { AkteService } from 'src/app/shared/services/akte.service';

@Component({
  selector: 'app-neue-akte-view',
  templateUrl: './neue-akte-view.component.html',
  styleUrls: ['./neue-akte-view.component.scss'],
})
export class NeueAkteViewComponent {
  @ViewChild('aktenForm') aktenForm: NgForm = new NgForm([], []);
  allKennziffern: String[] = [];
  allStadtbezirke: String[] = [];

  akte: Akte;

  submitted: boolean = false;

  constructor(
    private akteS: AkteService,
    private router: Router,
    private storageS: StorageService
  ) {
    for (let i = 1; i < 101; i++) {
      this.allKennziffern.push(String(i));
      this.allStadtbezirke.push(String(i));
    }

    this.akte = this.storageS.getSavedAkte('neue-akte');

    this.akteS.getHeftnummer().then((heftnummer) => {
      this.akte.letzteHeftnummer = heftnummer;
      this.akte.neueHeftnummer = heftnummer + 1;
    });
  }

  updateGrundstuecksInformationen(tableData: GrundstuecksInformation[]): void {
    this.akte.allGrundstuecksInformationen = tableData;
  }

  onSubmit() {
    if (this.aktenForm.form.valid) {
      this.akteS.create(this.akte).then((newAkte) => {
        this.router.navigate([
          '/app/akten-verzeichnis',
          newAkte.akteId,
          'informationen',
        ]);
      });
      this.submitted = true;
    }
  }
  @HostListener('window:beforeunload', ['$event']) handleBeforeunload(
    event: Event
  ) {
    this.storageS.saveAkte('neue-akte', this.akte);
  }

  ngOnDestroy() {
    this.storageS.removeSavedAkte('neue-akte');
  }
}
