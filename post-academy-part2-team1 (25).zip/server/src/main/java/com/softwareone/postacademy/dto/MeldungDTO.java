package com.softwareone.postacademy.dto;

import com.softwareone.postacademy.model.Meldung;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.Instant;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class MeldungDTO {

    private Long meldungId;
    private int zustand;
    private String bereich;
    private String nachricht;
    private String gemeldetVon;
    private String bearbeitetDurch;
    private String inBearbeitungVon;
    private Instant gemeldetAm;
    private Long akteId;
    private Long kennZiffer;
    private Long heftnummer;
    private boolean almosenKasten;
    private Long stadtBezirk;

    public MeldungDTO(Meldung meldung){
        this.meldungId=meldung.getMeldungId();
        this.zustand=meldung.getZustand();
        this.bereich= meldung.getBereich();
        this.nachricht=meldung.getNachricht();
        if(meldung.getGemeldetVon()!=null){
            this.gemeldetVon=meldung.getGemeldetVon().getBenutzerName();
        }
        if(meldung.getBearbeitetDurch()!=null){
            this.bearbeitetDurch=meldung.getBearbeitetDurch().getBenutzerName();
        }
        if(meldung.getInBearbeitungVon()!=null){
            this.inBearbeitungVon=meldung.getInBearbeitungVon().getBenutzerName();
        }

        this.gemeldetAm=meldung.getGemeldetAm();
        this.akteId= meldung.getAkte().getAkteId();
        this.kennZiffer=meldung.getAkte().getKennZiffer();
        this.stadtBezirk = meldung.getAkte().getStadtBezirk();
        this.almosenKasten = meldung.getAkte().isAlmosenKasten();
        this.heftnummer= meldung.getAkte().getNeueHeftnummer();
    }
}