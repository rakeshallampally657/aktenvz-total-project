import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { AkteService } from 'src/app/shared/services/akte.service';

@Component({
  selector: 'app-akten-details-view',
  templateUrl: './akten-details-view.component.html',
  styleUrls: ['./akten-details-view.component.scss'],
})
export class AktenDetailsViewComponent implements OnInit {
  constructor(private route: ActivatedRoute, private akteS: AkteService) {
    this.akteS.setAkteId(this.route.snapshot.params.akteId);
  }
  ngOnInit(): void {}
}
