export interface Aenderung {
  aenderungId: number;
  datum: any;
  benutzerName: string;
  aktion: string;
}
