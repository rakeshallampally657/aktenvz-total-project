package com.softwareone.postacademy.dto;

import com.softwareone.postacademy.model.Akte;
import com.softwareone.postacademy.model.GrundstuecksInformation;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.Instant;
import java.util.List;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class AkteVersionierungDTO {
    private Long akteVersionId;
    private Long akteId;
    private Long stadtBezirk;
    private Long kennZiffer;
    private Instant aktenBeginn;
    private Long letzteHeftnummer;
    private Long neueHeftnummer;
    private Long heftnummer;
    private boolean almosenKasten;
    private boolean inPapierkorb;
    private String sonstigeAnmerkungen;
    private String betreff;
    private List<GrundstuecksInformation> allGrundstuecksInformationen;

    public AkteVersionierungDTO(Akte akte, Number versionId) {
        this.akteVersionId = versionId.longValue();
        this.stadtBezirk = akte.getStadtBezirk();
        this.kennZiffer = akte.getKennZiffer();
        this.aktenBeginn = akte.getAktenBeginn();
        this.heftnummer=akte.getNeueHeftnummer();
        this.almosenKasten = akte.isAlmosenKasten();
        this.sonstigeAnmerkungen = akte.getSonstigeAnmerkungen();
        this.allGrundstuecksInformationen = akte.getAllGrundstuecksInformationen();
        this.letzteHeftnummer=akte.getLetzteHeftnummer();
        this.neueHeftnummer= akte.getNeueHeftnummer();
        this.betreff= akte.getBetreff();
        this.akteId=akte.getAkteId();
        this.inPapierkorb = akte.isInPapierKorb();
    }
}