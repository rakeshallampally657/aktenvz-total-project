import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AktenHistorieViewComponent } from './akten-historie-view.component';

describe('AktenHistorieViewComponent', () => {
  let component: AktenHistorieViewComponent;
  let fixture: ComponentFixture<AktenHistorieViewComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AktenHistorieViewComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(AktenHistorieViewComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
