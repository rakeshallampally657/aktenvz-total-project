export interface MeldungShort {
  meldungId: number;
  zustand: number;
  bearbeitetDurch: number;
  gemeldetAm: any;
  gemeldetVon: number;
  kennZiffer: number;
  almosenKasten: number;
  stadtBezirk: number;
  heftnummer: number;
  bereich: string;
  inBearbeitungVon: number;
}
