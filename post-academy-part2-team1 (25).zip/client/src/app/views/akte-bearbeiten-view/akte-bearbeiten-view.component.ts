import { Component, HostListener, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Akte } from 'src/app/interfaces/Akte.interface';
import { GrundstuecksInformation } from 'src/app/interfaces/GrundstuecksInformation.interface';
import { AkteService } from 'src/app/shared/services/akte.service';
import { MapperService } from 'src/app/shared/services/mapper.service';
import { StorageService } from 'src/app/shared/services/storage.service';

@Component({
  selector: 'app-akte-bearbeiten-view',
  templateUrl: './akte-bearbeiten-view.component.html',
  styleUrls: ['./akte-bearbeiten-view.component.scss'],
})
export class AkteBearbeitenViewComponent implements OnInit {
  akte: Akte = this.akteS.getDefaultAkte();
  allKennziffern: String[] = [];
  allStadtbezirke: String[] = [];
  constructor(
    private akteS: AkteService,
    private router: Router,
    private route: ActivatedRoute,
    private storageS: StorageService,
    private mapperS: MapperService
  ) {}

  ngOnInit(): void {
    this.init();
  }

  init = async (): Promise<void> => {
    for (let i = 1; i < 101; i++) {
      this.allKennziffern.push(String(i));
      this.allStadtbezirke.push(String(i));
    }

    const akte = await this.akteS.get(this.route.snapshot.params.akteId);
    akte.kennZiffer = akte.kennZiffer.toString();
    akte.stadtBezirk = akte.stadtBezirk.toString();
    akte.aktenBeginn = this.mapperS.convertStringToDate(akte.aktenBeginn);
    this.akte = akte;
  };

  updateGrundstuecksInformationen(tableData: GrundstuecksInformation[]) {
    this.akte.allGrundstuecksInformationen = tableData;
  }

  onSubmit() {
    this.akte.letzteAenderung = '';
    this.akteS.update(this.akte).then(() => {
      this.router.navigate([
        '/app/akten-verzeichnis',
        this.akte.akteId,
        'informationen',
      ]);
    });
  }

  @HostListener('window:beforeunload', ['$event']) handleBeforeunload(
    event: Event
  ) {
    this.storageS.saveAkte('current-akte', this.akte);
  }
}
