export interface Aufenthaltsort {
    datum: Date;
    aufenthaltsort: string;
    anmerkungAufenthaltsort: string;
}